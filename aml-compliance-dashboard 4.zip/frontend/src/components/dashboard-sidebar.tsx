import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { 
  BarChart3, 
  Users, 
  MapPin, 
  AlertTriangle, 
  FileText, 
  Settings,
  Download,
  GitBranch,
  Shield
} from "lucide-react";

interface NavigationItem {
  icon: any;
  label: string;
  page: string;
}

interface DashboardSidebarProps {
  currentPage: string;
  onPageChange: (page: string) => void;
}

const navigationItems: NavigationItem[] = [
  //{ icon: BarChart3, label: "Dashboard", page: "dashboard" },
  { icon: GitBranch, label: "Work Queue", page: "workflows" },
  { icon: Shield, label: "Risk Assessment", page: "risk-assessment" },
  { icon: Settings, label: "Control Process", page: "control-management" },
  //{ icon: FileText, label: "Reports", page: "reports" },
  { icon: Settings, label: "Settings", page: "settings" }
];

export function DashboardSidebar({ currentPage, onPageChange }: DashboardSidebarProps) {
  return (
    <div className="w-64 bg-sidebar border-r border-sidebar-border p-4 space-y-4">
      <Card className="p-4">
        <div className="space-y-1">
          {navigationItems.map((item, index) => (
            <Button
              key={index}
              variant={currentPage === item.page ? "default" : "ghost"}
              size="sm"
              className="w-full justify-start"
              onClick={() => onPageChange(item.page)}
            >
              <item.icon className="h-4 w-4 mr-2" />
              {item.label}
            </Button>
          ))}
        </div>
      </Card>

      <Card className="p-4">
        <h3 className="font-semibold mb-3">Recent Alerts</h3>
        <div className="space-y-3">
          <div className="text-sm">
            <div className="flex items-center space-x-2 mb-1">
              <AlertTriangle className="h-3 w-3 text-red-500" />
              <span className="font-medium">High Risk Transaction</span>
            </div>
            <p className="text-muted-foreground text-xs">Oceanic Holdings Ltd - $2.5M wire transfer</p>
            <p className="text-muted-foreground text-xs">2 hours ago</p>
          </div>
          
          <div className="text-sm">
            <div className="flex items-center space-x-2 mb-1">
              <AlertTriangle className="h-3 w-3 text-orange-500" />
              <span className="font-medium">KYC Update Required</span>
            </div>
            <p className="text-muted-foreground text-xs">Global Trade Solutions - Documentation expired</p>
            <p className="text-muted-foreground text-xs">4 hours ago</p>
          </div>
          
          <div className="text-sm">
            <div className="flex items-center space-x-2 mb-1">
              <AlertTriangle className="h-3 w-3 text-red-500" />
              <span className="font-medium">PEP Connection Detected</span>
            </div>
            <p className="text-muted-foreground text-xs">Alexander Petrov - New sanctions match</p>
            <p className="text-muted-foreground text-xs">6 hours ago</p>
          </div>
        </div>
      </Card>
    </div>
  );
}