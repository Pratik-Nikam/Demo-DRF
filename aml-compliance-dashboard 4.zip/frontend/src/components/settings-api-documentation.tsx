import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { 
  Code, 
  Database, 
  FileJson, 
  Copy, 
  Check,
  BarChart3,
  Shield,
  Users,
  GitBranch,
  FileText
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface ApiEndpoint {
  name: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  endpoint: string;
  description: string;
  requestParams?: string;
  responseSchema: any;
  widget: string;
}

export function SettingsApiDocumentation() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [copiedEndpoint, setCopiedEndpoint] = useState<string | null>(null);

  const handleCopyJson = (json: any, endpointName: string) => {
    navigator.clipboard.writeText(JSON.stringify(json, null, 2));
    setCopiedEndpoint(endpointName);
    toast.success("JSON schema copied to clipboard");
    setTimeout(() => setCopiedEndpoint(null), 2000);
  };

  const apisByMenu: Record<string, ApiEndpoint[]> = {
/*    dashboard: [
      {
        name: "Risk Overview Metrics",
        method: "GET",
        endpoint: "/api/v1/dashboard/risk-overview",
        description: "Retrieves high-level risk metrics for the dashboard overview cards",
        widget: "Risk Overview Cards",
        responseSchema: {
          data: {
            highRiskClients: {
              value: 247,
              change: "+12%",
              changeType: "increase",
              description: "Clients with risk score > 80"
            },
            activeInvestigations: {
              value: 18,
              change: "-3%",
              changeType: "decrease",
              description: "Ongoing compliance reviews"
            },
            totalClients: {
              value: 12847,
              change: "+5%",
              changeType: "increase",
              description: "All monitored entities"
            },
            highRiskJurisdictions: {
              value: 23,
              change: "+2",
              changeType: "increase",
              description: "Countries with elevated risk"
            }
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Workflow Status Distribution",
        method: "GET",
        endpoint: "/api/v1/dashboard/workflow-distribution",
        description: "Returns case count distribution across workflow statuses for pie chart visualization",
        widget: "Work Queue Distribution",
        responseSchema: {
          data: [
            { status: "Assigned", count: 45, color: "#3b82f6" },
            { status: "In Progress", count: 32, color: "#eab308" },
            { status: "Escalated", count: 18, color: "#f97316" },
            { status: "Returned", count: 12, color: "#ef4444" },
            { status: "Completed", count: 89, color: "#22c55e" }
          ],
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Escalation Trends",
        method: "GET",
        endpoint: "/api/v1/dashboard/escalation-trends",
        description: "Weekly escalation patterns by destination role for trend analysis",
        requestParams: "?weeks=4",
        widget: "Escalation Trends Chart",
        responseSchema: {
          data: [
            { week: "Week 1", toManager: 12, toFLU: 8, toGFC: 4 },
            { week: "Week 2", toManager: 15, toFLU: 11, toGFC: 6 },
            { week: "Week 3", toManager: 18, toFLU: 9, toGFC: 8 },
            { week: "Week 4", toManager: 14, toFLU: 12, toGFC: 5 }
          ],
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Turnaround Time Metrics",
        method: "GET",
        endpoint: "/api/v1/dashboard/turnaround-times",
        description: "Average case processing times by role with target comparisons",
        widget: "Average Turnaround Times",
        responseSchema: {
          data: [
            { role: "HRA Analyst", avgDays: 2.4, target: 3.0, status: "on-target" },
            { role: "HRA Manager", avgDays: 1.8, target: 2.0, status: "on-target" },
            { role: "FLU AML", avgDays: 4.2, target: 5.0, status: "on-target" },
            { role: "GFC", avgDays: 3.6, target: 4.0, status: "on-target" }
          ],
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Recent Workflow Activity",
        method: "GET",
        endpoint: "/api/v1/dashboard/recent-activity",
        description: "Recent case activities and workflow events across all users",
        requestParams: "?limit=10",
        widget: "Recent Workflow Activity",
        responseSchema: {
          data: [
            {
              id: "act-001",
              action: "Case HRA-2024-0156 escalated to Manager",
              user: "Sarah Johnson",
              userId: "USR-001",
              timestamp: "2024-11-10T10:28:00Z",
              status: "escalated",
              caseId: "HRA-2024-0156"
            },
            {
              id: "act-002",
              action: "Case HRA-2024-0143 returned for corrections",
              user: "Michael Chen",
              userId: "USR-002",
              timestamp: "2024-11-10T10:15:00Z",
              status: "returned",
              caseId: "HRA-2024-0143"
            },
            {
              id: "act-003",
              action: "Bulk reassignment: 12 cases to Investment Banking team",
              user: "Manager - David Kim",
              userId: "USR-003",
              timestamp: "2024-11-10T08:30:00Z",
              status: "bulk",
              metadata: { caseCount: 12, lob: "Investment Banking" }
            }
          ],
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Role-Specific Quick Actions",
        method: "GET",
        endpoint: "/api/v1/dashboard/quick-actions",
        description: "Returns action cards with counts based on user role",
        requestParams: "?userRole=hra-analyst",
        widget: "Role-Specific Action Cards",
        responseSchema: {
          data: {
            userRole: "hra-analyst",
            actions: [
              { label: "My Active Cases", count: 24, icon: "Users" },
              { label: "Ready to Escalate", count: 8, icon: "ArrowUpCircle" },
              { label: "Returned for Review", count: 3, icon: "RotateCcw" }
            ]
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Team Capacity Overview",
        method: "GET",
        endpoint: "/api/v1/dashboard/team-capacity",
        description: "Team workload and capacity metrics (Manager and above only)",
        widget: "Team Capacity Widget",
        responseSchema: {
          data: {
            teams: [
              {
                lob: "Investment Banking",
                totalAnalysts: 8,
                activeCases: 156,
                avgCaseload: 19.5,
                capacityUtilization: 78,
                status: "healthy"
              },
              {
                lob: "Commercial Banking",
                totalAnalysts: 6,
                activeCases: 143,
                avgCaseload: 23.8,
                capacityUtilization: 95,
                status: "at-capacity"
              }
            ],
            summary: {
              totalAnalysts: 24,
              totalCases: 587,
              avgUtilization: 82
            }
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      }
    ],*/
    riskAssessment: [
      {
        name: "Company Search",
        method: "GET",
        endpoint: "/api/v1/risk-assessment/companies/search",
        description: "Search companies for risk assessment",
        requestParams: "?query=global&lob=Investment Banking",
        widget: "Company Search",
        responseSchema: {
          data: [
            {
              companyId: "COMP-001",
              legalName: "Global Dynamics Corporation",
              clientId: "CLT-12345",
              jurisdiction: "Cayman Islands",
              lob: "Investment Banking",
              riskRating: "High",
              lastAssessment: "2024-09-15"
            }
          ],
          totalResults: 1,
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Customer Information",
        method: "GET",
        endpoint: "/api/v1/risk-assessment/customer/{clientId}",
        description: "Retrieve detailed customer information for risk assessment",
        widget: "Customer Information Section",
        responseSchema: {
          data: {
            legalName: "Global Dynamics Corporation",
            clientIdentifier: "CLT-12345",
            lob: "Investment Banking",
            jurisdiction: "Cayman Islands",
            clientType: "Corporate",
            relationshipManager: "Emily Rodriguez",
            accountOpenDate: "2018-03-15",
            industry: "Investment Management",
            entityType: "Corporation",
            taxId: "98-7654321",
            businessDescription: "Global investment management firm specializing in alternative investments",
            registeredAddress: "1234 Financial Center, George Town, Cayman Islands"
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "CRR Risk Factors",
        method: "GET",
        endpoint: "/api/v1/risk-assessment/crr-factors/{caseId}",
        description: "Current and previous CRR risk factors comparison",
        widget: "CRR Risk Factors Section",
        responseSchema: {
          data: {
            caseId: "HRA-2024-0001",
            currentFactors: [
              {
                category: "Customer Attributes",
                factor: "Business Type",
                value: "Investment Management",
                impact: "medium",
                score: 15
              },
              {
                category: "Geographic Location",
                factor: "Primary Jurisdiction",
                value: "Cayman Islands",
                impact: "high",
                score: 25
              }
            ],
            previousFactors: [
              {
                category: "Customer Attributes",
                factor: "Business Type",
                value: "Investment Management",
                impact: "medium",
                score: 15
              }
            ],
            newDrivers: 5,
            wasPreviousDriver: true,
            riskDriverCount: 12
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Additional Risk Factors",
        method: "GET",
        endpoint: "/api/v1/risk-assessment/additional-factors/{caseId}",
        description: "CAM, TRMS, and escalation information",
        widget: "Additional Risk Factors Section",
        responseSchema: {
          data: {
            caseId: "HRA-2024-0001",
            cam: {
              hadBreaches: true,
              caseStatus: "Resolved - No Action Required",
              resolutionDate: "2024-08-15",
              description: "Minor KYC documentation gap identified and remediated"
            },
            trms: {
              wasTrmsFiled: true,
              hadTrmsReferrals: true,
              referralCount: 2,
              lastReferralDate: "2024-09-01",
              description: "Two TRMS referrals in Q3 2024 related to cross-border wire transfers"
            },
            escalation: {
              hadEscalations: true,
              escalationCount: 1,
              lastEscalationDate: "2024-07-15",
              description: "Client requested approval for cryptocurrency trading activities"
            }
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Risk Mitigants",
        method: "GET",
        endpoint: "/api/v1/risk-assessment/mitigants/{caseId}",
        description: "Active risk mitigation controls and measures",
        widget: "Risk Mitigants Section",
        responseSchema: {
          data: {
            caseId: "HRA-2024-0001",
            mitigants: [
              {
                id: "MIT-001",
                category: "Enhanced Monitoring",
                control: "Enhanced Transaction Monitoring",
                status: "active",
                implementedDate: "2024-01-15",
                effectiveness: "high",
                description: "Daily review of all transactions exceeding $50,000"
              },
              {
                id: "MIT-002",
                category: "Documentation",
                control: "Annual KYC Refresh",
                status: "active",
                implementedDate: "2024-09-01",
                effectiveness: "medium",
                description: "Full KYC documentation updated annually vs standard 3-year cycle"
              }
            ],
            totalMitigants: 2,
            effectivenessScore: 85
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Risk Summary Assessment",
        method: "POST",
        endpoint: "/api/v1/risk-assessment/summary",
        description: "Submit or retrieve risk summary and final disposition",
        widget: "Risk Summary Section",
        responseSchema: {
          data: {
            caseId: "HRA-2024-0001",
            overallRiskRating: "High",
            riskScore: 82,
            riskJustification: "Elevated risk due to jurisdiction and business model complexity",
            recommendedAction: "Approve with Enhanced Monitoring",
            analystRecommendation: "Continue relationship with quarterly reviews",
            managerApproval: null,
            disposition: "pending",
            submittedBy: "Sarah Johnson",
            submittedDate: "2024-11-10T10:30:00Z"
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      }
    ],
    workflows: [
      {
        name: "My Workbasket",
        method: "GET",
        endpoint: "/api/v1/workflows/workbasket/my-cases",
        description: "Retrieve cases assigned to current user",
        requestParams: "?filter=active&limit=50&offset=0",
        widget: "My Workbasket Table",
        responseSchema: {
          data: [
            {
              caseId: "HRA-2024-0201",
              clientId: "CLT201",
              clientName: "Global Dynamics Corp",
              clientType: "Corporate",
              status: "assigned",
              priority: "high",
              assignedAnalyst: "Sarah Johnson",
              createdDate: "2024-06-15",
              dueDate: "2024-06-25",
              riskRating: "High",
              manualReviewReasons: ["GFC Intelligence is Yes", "Risk drivers >10"],
              jurisdiction: "Cayman Islands",
              lob: "Investment Banking",
              daysInQueue: 2,
              escalationPending: false
            }
          ],
          totalRecords: 24,
          page: 1,
          pageSize: 50,
          filters: {
            active: 18,
            escalations: 8,
            completed: 5,
            returned: 3
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Work Queue",
        method: "GET",
        endpoint: "/api/v1/workflows/work-queue",
        description: "Get unassigned cases in the work queue (Manager view)",
        requestParams: "?lob=Investment Banking&limit=50&offset=0",
        widget: "Work Queue Table",
        responseSchema: {
          data: [
            {
              caseId: "HRA-2024-0280",
              clientId: "CLT280",
              clientName: "Phoenix Energy Corp",
              clientType: "Corporate",
              status: "unassigned",
              priority: "critical",
              createdDate: "2024-11-10",
              dueDate: "2024-11-20",
              riskRating: "High",
              jurisdiction: "United States",
              lob: "Investment Banking",
              daysInQueue: 0,
              assignmentEligible: true
            }
          ],
          totalRecords: 45,
          page: 1,
          pageSize: 50,
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Get Next Case (FIFO)",
        method: "POST",
        endpoint: "/api/v1/workflows/get-next-case",
        description: "Assign next available case to analyst using FIFO logic",
        widget: "Case Assignment - Get Next",
        responseSchema: {
          data: {
            caseId: "HRA-2024-0280",
            clientId: "CLT280",
            clientName: "Phoenix Energy Corp",
            assignedTo: "Sarah Johnson",
            assignedToId: "USR-001",
            assignedDate: "2024-11-10T10:30:00Z",
            dueDate: "2024-11-20T23:59:59Z",
            priority: "critical",
            autoAssigned: true
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Escalate Case",
        method: "POST",
        endpoint: "/api/v1/workflows/escalate",
        description: "Escalate case to Manager, FLU AML, or GFC",
        widget: "Escalation Routing",
        responseSchema: {
          data: {
            escalationId: "ESC-2024-0046",
            caseId: "HRA-2024-0201",
            escalatedFrom: "hra-analyst",
            escalatedTo: "hra-manager",
            escalatedBy: "Sarah Johnson",
            escalatedById: "USR-001",
            escalationDate: "2024-11-10T10:30:00Z",
            reason: "Requires manager approval for high-risk continuation",
            disposition: null,
            status: "pending"
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Return Case",
        method: "POST",
        endpoint: "/api/v1/workflows/return",
        description: "Return case to analyst for corrections",
        widget: "Case Return",
        responseSchema: {
          data: {
            caseId: "HRA-2024-0201",
            returnedBy: "Manager - David Kim",
            returnedById: "USR-003",
            returnedTo: "Sarah Johnson",
            returnedToId: "USR-001",
            returnDate: "2024-11-10T10:30:00Z",
            returnReason: "Additional documentation required for beneficial ownership",
            status: "returned",
            newDueDate: "2024-11-15T23:59:59Z"
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Bulk Reassignment",
        method: "POST",
        endpoint: "/api/v1/workflows/bulk-reassign",
        description: "Reassign multiple cases to different analyst or LOB",
        widget: "Bulk Reassignment",
        responseSchema: {
          data: {
            reassignmentId: "REASS-2024-0012",
            caseIds: ["HRA-2024-0201", "HRA-2024-0203", "HRA-2024-0205"],
            totalCases: 3,
            reassignedFrom: "Sarah Johnson",
            reassignedTo: "Michael Chen",
            reassignedToId: "USR-002",
            reassignmentType: "individual",
            lob: "Investment Banking",
            reassignedBy: "Manager - David Kim",
            reassignedById: "USR-003",
            reassignmentDate: "2024-11-10T10:30:00Z",
            reason: "Workload balancing",
            status: "completed"
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Submit Disposition",
        method: "POST",
        endpoint: "/api/v1/workflows/disposition",
        description: "Submit final disposition for escalated case (Manager/FLU/GFC)",
        widget: "Disposition Submission",
        responseSchema: {
          data: {
            caseId: "HRA-2024-0201",
            escalationId: "ESC-2024-0046",
            disposition: "Approve with Conditions",
            dispositionBy: "Manager - David Kim",
            dispositionById: "USR-003",
            dispositionDate: "2024-11-10T10:30:00Z",
            dispositionNotes: "Approved with enhanced monitoring requirements",
            nextAction: "return-to-analyst",
            status: "completed"
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      }
    ],
    /*reports: [
      {
        name: "Operational Reporting Dashboard",
        method: "GET",
        endpoint: "/api/v1/reports/operational",
        description: "Real-time operational metrics filtered by LOB and date range",
        requestParams: "?lob=Investment Banking&startDate=2024-10-01&endDate=2024-10-31",
        widget: "Operational Reporting Dashboard",
        responseSchema: {
          data: {
            summary: {
              totalCases: 342,
              completedCases: 289,
              pendingCases: 42,
              escalatedCases: 11,
              averageProcessingTime: 3.2,
              complianceRate: 94.7
            },
            by_priority: [
              { priority: "Critical", count: 23, completed: 20, pending: 3 },
              { priority: "High", count: 89, completed: 78, pending: 11 },
              { priority: "Medium", count: 145, completed: 128, pending: 17 },
              { priority: "Low", count: 85, completed: 63, pending: 11 }
            ],
            by_status: [
              { status: "Completed", count: 289 },
              { status: "In Progress", count: 31 },
              { status: "Escalated", count: 11 },
              { status: "Returned", count: 11 }
            ],
            trends: {
              weekly: [
                { week: "Week 1", cases: 78, completed: 65 },
                { week: "Week 2", cases: 92, completed: 81 },
                { week: "Week 3", cases: 85, completed: 72 },
                { week: "Week 4", cases: 87, completed: 71 }
              ]
            }
          },
          filters: {
            lob: "Investment Banking",
            startDate: "2024-10-01",
            endDate: "2024-10-31"
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "SPI Performance Metrics",
        method: "GET",
        endpoint: "/api/v1/reports/spi-performance",
        description: "Service Performance Indicators and process performance metrics",
        requestParams: "?period=monthly&year=2024",
        widget: "SPI/Process Performance Reporting",
        responseSchema: {
          data: {
            period: "monthly",
            year: 2024,
            metrics: [
              {
                metric: "Average Case Processing Time",
                target: 3.0,
                actual: 2.8,
                unit: "days",
                status: "on-target",
                trend: "improving"
              },
              {
                metric: "Cases Completed Within SLA",
                target: 95.0,
                actual: 94.7,
                unit: "percent",
                status: "near-target",
                trend: "stable"
              },
              {
                metric: "Escalation Rate",
                target: 5.0,
                actual: 3.2,
                unit: "percent",
                status: "on-target",
                trend: "improving"
              },
              {
                metric: "Quality Review Pass Rate",
                target: 98.0,
                actual: 97.8,
                unit: "percent",
                status: "on-target",
                trend: "stable"
              }
            ],
            monthly_trends: [
              { month: "Jan", processingTime: 3.1, slaCompliance: 93.5, escalationRate: 4.2 },
              { month: "Feb", processingTime: 2.9, slaCompliance: 94.2, escalationRate: 3.8 },
              { month: "Mar", processingTime: 2.8, slaCompliance: 94.7, escalationRate: 3.2 }
            ]
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "HRA Reports Table",
        method: "GET",
        endpoint: "/api/v1/reports/available-reports",
        description: "List of available generated reports with download links",
        requestParams: "?category=operational&limit=50",
        widget: "HRA Reports Table",
        responseSchema: {
          data: [
            {
              reportId: "RPT-2024-0123",
              reportName: "Monthly HRA Case Summary",
              category: "operational",
              reportType: "PDF",
              generatedDate: "2024-11-01T08:00:00Z",
              generatedBy: "System Scheduler",
              reportPeriod: "October 2024",
              fileSize: "2.3 MB",
              downloadUrl: "/api/v1/reports/download/RPT-2024-0123",
              status: "available"
            },
            {
              reportId: "RPT-2024-0124",
              reportName: "High Risk Client Analysis",
              category: "risk-analysis",
              reportType: "Excel",
              generatedDate: "2024-11-05T14:30:00Z",
              generatedBy: "Sarah Johnson",
              reportPeriod: "Q3 2024",
              fileSize: "5.7 MB",
              downloadUrl: "/api/v1/reports/download/RPT-2024-0124",
              status: "available"
            }
          ],
          totalReports: 45,
          page: 1,
          pageSize: 50,
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Generate Custom Report",
        method: "POST",
        endpoint: "/api/v1/reports/generate",
        description: "Generate a custom report based on parameters",
        widget: "Custom Report Generation",
        responseSchema: {
          data: {
            reportId: "RPT-2024-0125",
            reportName: "Custom Case Analysis Report",
            requestedBy: "Sarah Johnson",
            requestedById: "USR-001",
            requestedDate: "2024-11-10T10:30:00Z",
            parameters: {
              lob: ["Investment Banking", "Commercial Banking"],
              dateRange: { start: "2024-10-01", end: "2024-10-31" },
              includeMetrics: ["processing-time", "escalation-rate", "completion-rate"]
            },
            status: "generating",
            estimatedCompletionTime: "2024-11-10T10:35:00Z"
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Client Type Analysis",
        method: "GET",
        endpoint: "/api/v1/reports/client-type-analysis",
        description: "Client distribution and risk analysis by client type",
        widget: "Client Type Analysis Chart",
        responseSchema: {
          data: {
            clientTypes: [
              { type: "Retail", total: 8420, highRisk: 89, mediumRisk: 234, lowRisk: 8097 },
              { type: "Corporate", total: 2847, highRisk: 127, mediumRisk: 456, lowRisk: 2264 },
              { type: "Investment", total: 1234, highRisk: 45, mediumRisk: 178, lowRisk: 1011 },
              { type: "Banking", total: 346, highRisk: 12, mediumRisk: 67, lowRisk: 267 }
            ],
            riskDistribution: [
              { name: "Low Risk", value: 11727, color: "#3b82f6", percentage: 91.3 },
              { name: "Medium Risk", value: 855, color: "#60a5fa", percentage: 6.7 },
              { name: "High Risk", value: 265, color: "#1e3a8a", percentage: 2.0 }
            ],
            totalClients: 12847
          },
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      },
      {
        name: "Jurisdiction Risk Map",
        method: "GET",
        endpoint: "/api/v1/reports/jurisdiction-risk",
        description: "Geographic risk distribution by jurisdiction",
        widget: "Jurisdiction Risk Map",
        responseSchema: {
          data: [
            {
              country: "United States",
              riskLevel: "Low",
              clients: 4234,
              highRiskClients: 23,
              riskScore: 15,
              riskFactors: ["Low regulatory risk", "Established market"]
            },
            {
              country: "Cayman Islands",
              riskLevel: "High",
              clients: 234,
              highRiskClients: 45,
              riskScore: 78,
              riskFactors: ["Offshore jurisdiction", "Complex structures", "Limited transparency"]
            }
          ],
          totalJurisdictions: 45,
          highRiskJurisdictions: 23,
          timestamp: "2024-11-10T10:30:00Z",
          status: "success"
        }
      }
    ]*/
  };

  const renderJsonSchema = (endpoint: ApiEndpoint) => {
    return (
      <Card key={endpoint.endpoint} className="mb-6">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <CardTitle className="flex items-center space-x-2 mb-2">
                <Database className="h-5 w-5 text-primary" />
                <span>{endpoint.name}</span>
                <Badge variant={
                  endpoint.method === 'GET' ? 'secondary' : 
                  endpoint.method === 'POST' ? 'default' :
                  endpoint.method === 'PUT' ? 'outline' : 'destructive'
                }>
                  {endpoint.method}
                </Badge>
              </CardTitle>
              <p className="text-sm text-muted-foreground mb-2">{endpoint.description}</p>
              <div className="flex items-center space-x-4">
                <code className="text-sm bg-muted px-3 py-1 rounded">
                  {endpoint.endpoint}{endpoint.requestParams || ''}
                </code>
                <Badge variant="outline" className="text-xs">
                  {endpoint.widget}
                </Badge>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleCopyJson(endpoint.responseSchema, endpoint.endpoint)}
              className="ml-4"
            >
              {copiedEndpoint === endpoint.endpoint ? (
                <Check className="h-4 w-4 text-green-600" />
              ) : (
                <Copy className="h-4 w-4" />
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="bg-slate-950 text-slate-50 p-4 rounded-lg overflow-x-auto">
            <pre className="text-xs">
              <code>{JSON.stringify(endpoint.responseSchema, null, 2)}</code>
            </pre>
          </div>
        </CardContent>
      </Card>
    );
  };

  const getMenuIcon = (menuKey: string) => {
    switch (menuKey) {
      case 'dashboard': return <BarChart3 className="h-4 w-4" />;
      case 'riskAssessment': return <Shield className="h-4 w-4" />;
      case 'population': return <Shield className="h-4 w-4" />;
      case 'caseCreation': return <Users className="h-4 w-4" />;
      case 'workflows': return <GitBranch className="h-4 w-4" />;
      case 'reports': return <FileText className="h-4 w-4" />;
      default: return <FileJson className="h-4 w-4" />;
    }
  };

  const getMenuLabel = (menuKey: string) => {
    switch (menuKey) {
      case 'dashboard': return 'Dashboard';
      case 'riskAssessment': return 'Risk Assessment';
      case 'population': return 'Population Identification';
      case 'caseCreation': return 'Case Creation';
      case 'workflows': return 'Work Queue';
      case 'reports': return 'Reports';
      default: return menuKey;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-medium text-primary">API Documentation</h2>
        <p className="text-muted-foreground">
          Comprehensive API inventory and expected JSON structures for all widgets across the AML High Risk Assessment Tool
        </p>
      </div>

      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="pt-6">
          <div className="flex items-start space-x-3">
            <Code className="h-5 w-5 text-blue-600 mt-0.5" />
            <div>
              <h3 className="font-medium text-blue-900 mb-1">API Documentation Overview</h3>
              <p className="text-sm text-blue-700">
                This documentation provides a complete inventory of all REST API endpoints required to support the 
                AML HRA application. Each endpoint includes the HTTP method, URL path, description, expected JSON 
                response schema, and the widget/component it powers. All endpoints follow RESTful conventions and 
                return responses in JSON format.
              </p>
              <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-blue-600">
                <div>• Base URL: <code className="bg-blue-100 px-1 rounded">https://api.bofa.com/aml-hra</code></div>
                <div>• API Version: <code className="bg-blue-100 px-1 rounded">v1</code></div>
                <div>• Authentication: <code className="bg-blue-100 px-1 rounded">OAuth 2.0 Bearer Token</code></div>
                <div>• Total Endpoints: <code className="bg-blue-100 px-1 rounded">{Object.values(apisByMenu).flat().length}</code></div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          {Object.keys(apisByMenu).map((menuKey) => (
            <TabsTrigger key={menuKey} value={menuKey} className="flex items-center space-x-2">
              {getMenuIcon(menuKey)}
              <span className="hidden lg:inline">{getMenuLabel(menuKey)}</span>
            </TabsTrigger>
          ))}
        </TabsList>

        {Object.entries(apisByMenu).map(([menuKey, endpoints]) => (
          <TabsContent key={menuKey} value={menuKey} className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  {getMenuIcon(menuKey)}
                  <span>{getMenuLabel(menuKey)} APIs</span>
                  <Badge variant="secondary">{endpoints.length} endpoints</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-muted/50 p-4 rounded-lg">
                    <div className="text-2xl font-semibold text-primary mb-1">{endpoints.length}</div>
                    <div className="text-sm text-muted-foreground">Total Endpoints</div>
                  </div>
                  <div className="bg-muted/50 p-4 rounded-lg">
                    <div className="text-2xl font-semibold text-green-600 mb-1">
                      {endpoints.filter(e => e.method === 'GET').length}
                    </div>
                    <div className="text-sm text-muted-foreground">GET Requests</div>
                  </div>
                  <div className="bg-muted/50 p-4 rounded-lg">
                    <div className="text-2xl font-semibold text-blue-600 mb-1">
                      {endpoints.filter(e => e.method === 'POST').length}
                    </div>
                    <div className="text-sm text-muted-foreground">POST Requests</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-6">
              {endpoints.map(endpoint => renderJsonSchema(endpoint))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}