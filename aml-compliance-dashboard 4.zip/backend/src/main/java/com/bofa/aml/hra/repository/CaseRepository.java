package com.bofa.aml.hra.repository;

import com.bofa.aml.hra.model.CaseEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface CaseRepository extends MongoRepository<CaseEntity, String> {

    // Simple derived queries
    Page<CaseEntity> findByAssignedAnalyst(String assignedAnalyst, Pageable pageable);

    Page<CaseEntity> findByAssignedAnalystAndStatus(String assignedAnalyst, String status, Pageable pageable);

    Page<CaseEntity> findByAssignedAnalystAndStatusIn(String assignedAnalyst, List<String> statuses, Pageable pageable);

    List<CaseEntity> findByStatus(String status);

    Optional<CaseEntity> findByCaseId(String caseId);

    // Find by LOB (used for work queue filtering)
    Page<CaseEntity> findByLob(String lob, Pageable pageable);

    // FIFO selection of the oldest unassigned case(s).
    // derived query: (assignedAnalyst is null) OR status == 'unassigned', ordered by createdAt asc
    List<CaseEntity> findByAssignedAnalystIsNullOrStatusOrderByCreatedAtAsc(String status, Pageable pageable);

    // Escalation candidates: assignedAnalyst + (non-empty escalationReason OR manualReviewReasons contains any keyword)
    @Query("{ 'assignedAnalyst': ?0, $or: [ { 'escalationReason': { $exists: true, $ne: '' } }, " +
           "{ 'manualReviewReasons': { $regex: ?1, $options: 'i' } }, " +
           "{ 'manualReviewReasons': { $regex: ?2, $options: 'i' } }, " +
           "{ 'manualReviewReasons': { $regex: ?3, $options: 'i' } }, " +
           "{ 'manualReviewReasons': { $regex: ?4, $options: 'i' } } ] }")
    Page<CaseEntity> findEscalationCandidates(String assignedAnalyst,
                                              String kw1,
                                              String kw2,
                                              String kw3,
                                              String kw4,
                                              Pageable pageable);

    // Completed cases for an analyst within a datetime range (start inclusive, end exclusive)
    @Query("{ 'assignedAnalyst': ?0, 'status': 'completed', 'completedDate': { $gte: ?1, $lt: ?2 } }")
    Page<CaseEntity> findCompletedToday(String assignedAnalyst, LocalDateTime startOfDay, LocalDateTime endOfDay, Pageable pageable);

    // Full-text-ish search across notable fields (case-insensitive regex)
    @Query("{ $or: [ { 'caseId': { $regex: ?0, $options: 'i' } }, { 'clientName': { $regex: ?0, $options: 'i' } }, { 'clientId': { $regex: ?0, $options: 'i' } } ] }")
    Page<CaseEntity> searchByText(String q, Pageable pageable);

    /* --- Added for bulk reassignment --- */

    /**
     * Bulk lookup by business caseId values.
     */
    List<CaseEntity> findByCaseIdIn(List<String> caseIds);
}