package com.bofa.aml.hra.service;

import com.bofa.aml.hra.dto.request.*;
import com.bofa.aml.hra.dto.response.*;
import com.bofa.aml.hra.model.CaseEntity;
import com.bofa.aml.hra.repository.CaseRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * WorkflowService - now maps CaseEntity -> WorkItem DTO aligned to frontend expectations.
 * Uses repository methods for DB-side filtering & paging for production readiness.
 * Clock is injected to allow deterministic date behaviour in tests.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class WorkflowService {

    private final CaseRepository caseRepository;
    private final Clock clock;
    private static final DateTimeFormatter ISO_DATE = DateTimeFormatter.ISO_DATE_TIME;
    private static final ObjectMapper MAPPER = new ObjectMapper();

    // Updated signature: include assignee and filter
    public WorkbasketResponse getMyWorkbasket(String assignee, String filter, int limit, int offset) {
        log.debug("getMyWorkbasket assignee={} filter={} limit={} offset={}", assignee, filter, limit, offset);

        // Keep mock fallback for rapid dev when DB empty
        if (caseRepository.count() == 0) {
            List<WorkItem> items = generateMockItems(offset, limit, assignee);
            return WorkbasketResponse.builder()
                    .items(items)
                    .total(200)
                    .page(Math.max(0, offset / Math.max(1, limit)))
                    .size(limit)
                    .build();
        }

        int page = Math.max(0, offset / Math.max(1, limit));
        Pageable pageable = PageRequest.of(page, Math.max(1, limit), Sort.by(Sort.Direction.DESC, "createdAt"));

        Page<CaseEntity> pageResult;

        switch (filter == null ? "all" : filter) {
            case "active":
                pageResult = caseRepository.findByAssignedAnalystAndStatusIn(
                        assignee,
                        List.of("assigned", "in-progress"),
                        pageable
                );
                break;
            case "escalations":
                // Keywords matched against manualReviewReasons (lowercased). Keep list in sync with frontend.
                pageResult = caseRepository.findEscalationCandidates(
                        assignee,
                        "gfc intelligence",
                        "risk drivers",
                        "client escalation",
                        "trms referral",
                        pageable
                );
                break;
            case "completed":
                LocalDateTime startOfDay = LocalDate.now(clock).atStartOfDay();
                LocalDateTime endOfDay = startOfDay.plusDays(1);
                pageResult = caseRepository.findCompletedToday(assignee, startOfDay, endOfDay, pageable);
                break;
            case "returned":
                pageResult = caseRepository.findByAssignedAnalystAndStatus(assignee, "returned", pageable);
                break;
            case "all":
            default:
                pageResult = caseRepository.findByAssignedAnalyst(assignee, pageable);
                break;
        }

        List<WorkItem> mapped = pageResult.stream()
                .map(this::mapCaseEntityToWorkItem)
                .collect(Collectors.toList());

        return WorkbasketResponse.builder()
                .items(mapped)
                .total(pageResult.getTotalElements())
                .page(pageResult.getNumber())
                .size(pageResult.getSize())
                .build();
    }

    public WorkQueueResponse getWorkQueue(String lob, int limit, int offset) {
        log.debug("getWorkQueue lob={} limit={} offset={}", lob, limit, offset);

        // Fallback to mock if DB empty for rapid dev
        if (caseRepository.count() == 0) {
            List<WorkItem> items = generateMockItems(offset, limit, "unassigned");
            return WorkQueueResponse.builder()
                    .items(items)
                    .total(500)
                    .page(offset)
                    .size(limit)
                    .build();
        }

        int page = Math.max(0, offset / Math.max(1, limit));
        Pageable pageable = PageRequest.of(page, Math.max(1, limit), Sort.by(Sort.Direction.DESC, "createdAt"));

        // If no LOB filter requested, return all paged; otherwise use derived query by LOB
        Page<CaseEntity> pageResult;
        String lobFilter = (lob == null || lob.isBlank()) ? "" : lob;
        if (lobFilter.isEmpty()) {
            pageResult = caseRepository.findAll(pageable);
        } else {
            pageResult = caseRepository.findByLob(lobFilter, pageable);
        }

        List<WorkItem> mapped = pageResult.stream()
                .map(this::mapCaseEntityToWorkItem)
                .collect(Collectors.toList());

        return WorkQueueResponse.builder()
                .items(mapped)
                .total(pageResult.getTotalElements())
                .page(page)
                .size(pageable.getPageSize())
                .build();
    }

    /**
     * Assign the next FIFO unassigned case to the provided assignee.
     * If DB is empty, returns a mock assignment for rapid dev.
     */
    public CaseAssignmentResponse getNextCase(String assignee) {
        log.debug("getNextCase() assignee={}", assignee);
        String targetAssignee = (assignee == null || assignee.isBlank()) ? "assigned-user" : assignee;

        // Mock fallback when DB empty
        if (caseRepository.count() == 0) {
            String caseId = "HRA-" + UUID.randomUUID().toString().substring(0, 8);
            return CaseAssignmentResponse.builder()
                    .assignmentId(UUID.randomUUID().toString())
                    .caseId(caseId)
                    .assignedTo(targetAssignee)
                    .message("Assigned next available case using FIFO (mock)")
                    .build();
        }

        // Use repository FIFO query to get the oldest unassigned case
        Pageable one = PageRequest.of(0, 1, Sort.by(Sort.Direction.ASC, "createdAt"));
        List<CaseEntity> candidates = caseRepository.findByAssignedAnalystIsNullOrStatusOrderByCreatedAtAsc("unassigned", one);

        if (candidates == null || candidates.isEmpty()) {
            return CaseAssignmentResponse.builder()
                    .assignmentId(null)
                    .caseId(null)
                    .assignedTo(targetAssignee)
                    .message("No unassigned cases available")
                    .build();
        }

        CaseEntity toAssign = candidates.get(0);
        toAssign.setAssignedAnalyst(targetAssignee);
        toAssign.setStatus("assigned");
        CaseEntity saved = caseRepository.save(toAssign);

        return CaseAssignmentResponse.builder()
                .assignmentId(UUID.randomUUID().toString())
                .caseId(saved.getCaseId())
                .assignedTo(saved.getAssignedAnalyst())
                .message("Assigned case to " + saved.getAssignedAnalyst())
                .build();
    }

    /**
     * Persist escalation: mark case as escalated, persist escalation reason and assign to escalation group.
     * Throws 404 if case not found.
     */
    @Transactional
    public EscalationResponse escalateCase(EscalateRequest request) {
        log.debug("escalateCase request={}", request);

        if (request == null || request.getCaseId() == null || request.getCaseId().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "caseId is required");
        }

        CaseEntity entity = caseRepository.findByCaseId(request.getCaseId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Case not found"));

        // Set status and record escalation details.
        entity.setStatus("escalated");

        // assign escalatedTo into assignedAnalyst so manager/FLU/GFC can pick it up in their flows.
        String escalatedTo = request.getEscalateTo() == null || request.getEscalateTo().isBlank()
                ? "Manager"
                : request.getEscalateTo();
        entity.setAssignedAnalyst(escalatedTo);

        // Build escalationReason from optional UI fields when present; otherwise use default.
        StringBuilder reasonBuilder = new StringBuilder();
        if (request.getEscalationReasons() != null && !request.getEscalationReasons().isEmpty()) {
            reasonBuilder.append("Reasons: ").append(String.join(", ", request.getEscalationReasons()));
        }
        if (request.getNotes() != null && !request.getNotes().isBlank()) {
            if (reasonBuilder.length() > 0) reasonBuilder.append(" | ");
            reasonBuilder.append("Notes: ").append(request.getNotes().trim());
        }
        String reason = reasonBuilder.length() > 0 ? reasonBuilder.toString() : "Escalated to " + escalatedTo;
        entity.setEscalationReason(reason);

        CaseEntity saved = caseRepository.save(entity);

        return EscalationResponse.builder()
                .caseId(saved.getCaseId())
                .escalatedTo(escalatedTo)
                .status(saved.getStatus())
                .message("Case escalated successfully")
                .build();
    }

    /**
     * Persist return: mark case as returned, persist return reason and keep assigned analyst if present.
     * Throws 404 if case not found.
     */
    @Transactional
    public ReturnCaseResponse returnCase(ReturnCaseRequest request) {
        log.debug("returnCase request={}", request);

        if (request == null || request.getCaseId() == null || request.getCaseId().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "caseId is required");
        }

        CaseEntity entity = caseRepository.findByCaseId(request.getCaseId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Case not found"));

        // Mark returned and persist comment
        entity.setStatus("returned");
        entity.setReturnReason(request.getComments() == null ? "" : request.getComments().trim());

        CaseEntity saved = caseRepository.save(entity);

        return ReturnCaseResponse.builder()
                .caseId(saved.getCaseId())
                .returnedTo(Optional.ofNullable(saved.getAssignedAnalyst()).orElse("Unassigned"))
                .status(saved.getStatus())
                .message("Case returned to analyst with comments")
                .build();
    }

    /**
     * Bulk reassign multiple cases. Accepts a request with caseIds and optional newAssignee and/or newLob.
     * Returns counts of updated and failed items.
     */
    @Transactional
    public BulkReassignmentResponse bulkReassign(BulkReassignRequest request) {
        log.debug("bulkReassign request size={} newAssignee={} newLob={}",
                request.getCaseIds() != null ? request.getCaseIds().size() : 0,
                request.getNewAssignee(), request.getNewLob());

        if (request == null || request.getCaseIds() == null || request.getCaseIds().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "caseIds must be provided");
        }

        List<String> requestedIds = request.getCaseIds().stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());

        if (requestedIds.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "caseIds must contain at least one valid id");
        }

        // Lookup existing cases in a single query
        List<CaseEntity> foundCases = caseRepository.findByCaseIdIn(requestedIds);
        Map<String, CaseEntity> foundMap = foundCases.stream()
                .collect(Collectors.toMap(c -> Optional.ofNullable(c.getCaseId()).orElse(c.getId()), c -> c));

        List<CaseEntity> toSave = new ArrayList<>();
        int failedCount = 0;
        int updatedCount = 0;

        for (String cid : requestedIds) {
            CaseEntity entity = foundMap.get(cid);
            if (entity == null) {
                // case not found
                log.warn("bulkReassign: caseId not found: {}", cid);
                failedCount++;
                continue;
            }

            boolean changed = false;

            // Apply new assignee if provided
            if (request.getNewAssignee() != null && !request.getNewAssignee().isBlank()) {
                String newAssignee = request.getNewAssignee().trim();
                if (!Objects.equals(entity.getAssignedAnalyst(), newAssignee)) {
                    entity.setAssignedAnalyst(newAssignee);
                    changed = true;
                }
            }

            // Apply new LOB if provided
            if (request.getNewLob() != null && !request.getNewLob().isBlank()) {
                String newLob = request.getNewLob().trim();
                if (!Objects.equals(entity.getLob(), newLob)) {
                    entity.setLob(newLob);
                    changed = true;
                }
            }

            if (changed) {
                toSave.add(entity);
                updatedCount++;
            } else {
                // nothing to change � count as updated (idempotent) or skip? we treat as no-op (not incrementing updated).
                log.debug("bulkReassign: no-op for caseId {}", cid);
            }
        }

        if (!toSave.isEmpty()) {
            caseRepository.saveAll(toSave);
        }

        return BulkReassignmentResponse.builder()
                .updatedCount(updatedCount)
                .failedCount(failedCount)
                .message(String.format("Processed %d requested, updated=%d, failed=%d",
                        requestedIds.size(), updatedCount, failedCount))
                .build();
    }

    public DispositionResponse submitDisposition(DispositionRequest request) {
        log.debug("submitDisposition request={}", request);

        if (request == null || request.getCaseId() == null || request.getCaseId().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "caseId is required");
        }

        CaseEntity entity = caseRepository.findByCaseId(request.getCaseId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Case not found"));

        // Persist disposition and update status accordingly
        String disposition = request.getDisposition().trim();
        entity.setDisposition(disposition);

        // If disposition indicates final completion, mark completed and set timestamp.
        // Accept common tokens (completed, close, closed, retain->keep in system => set retained).
        String normalized = disposition.toLowerCase();
        if (normalized.equals("completed") || normalized.equals("close") || normalized.equals("closed")) {
            entity.setStatus("completed");
            entity.setCompletedDate(LocalDateTime.now(clock));
        } else if (normalized.startsWith("return") || normalized.contains("return")) {
            // e.g. "return_to_analyst" -> mark returned
            entity.setStatus("returned");
        } else {
            // record disposition verbatim as status for traceability (fallback)
            entity.setStatus(disposition);
        }

        // Save optional comments into escalationReason for auditability (keeps schema stable)
        if (request.getComments() != null && !request.getComments().isBlank()) {
            String existing = entity.getEscalationReason() == null ? "" : entity.getEscalationReason() + " | ";
            entity.setEscalationReason(existing + "Disposition comments: " + request.getComments().trim());
        }

        CaseEntity saved = caseRepository.save(entity);

        return DispositionResponse.builder()
                .caseId(saved.getCaseId())
                .disposition(saved.getDisposition())
                .status(saved.getStatus())
                .message("Disposition recorded")
                .build();
    }

    // Map persisted CaseEntity -> WorkItem DTO expected by frontend
    private WorkItem mapCaseEntityToWorkItem(CaseEntity c) {
        // Parse manualReviewReasons JSON stored as text into List<String>
        List<String> reasons = parseManualReviewReasons(c.getManualReviewReasons());

        String createdDateIso = c.getCreatedAt() != null ? c.getCreatedAt().format(ISO_DATE) : null;
        String dueDateStr = c.getDueDate() != null ? c.getDueDate().toString() : null;
        String completedDateIso = c.getCompletedDate() != null ? c.getCompletedDate().format(ISO_DATE) : null;

        // Compute daysInQueue from createdAt to "today" (clock)
        Integer daysInQueue = null;
        if (c.getCreatedAt() != null) {
            daysInQueue = (int) ChronoUnit.DAYS.between(c.getCreatedAt().toLocalDate(), LocalDate.now(clock));
            if (daysInQueue < 0) daysInQueue = 0;
        }

        return WorkItem.builder()
                .caseId(Optional.ofNullable(c.getCaseId()).orElse(c.getId()))
                .clientId(c.getClientId())
                .clientName(c.getClientName())
                .clientType(c.getClientType())
                .status(c.getStatus())
                .priority(c.getPriority())
                .assignedAnalyst(Optional.ofNullable(c.getAssignedAnalyst()).orElse("Unassigned"))
                .createdDate(createdDateIso)
                .dueDate(dueDateStr)
                .completedDate(completedDateIso)
                .riskRating(c.getRiskRating())
                .manualReviewReasons(reasons)
                .jurisdiction(c.getJurisdiction())
                .lob(c.getLob())
                .daysInQueue(daysInQueue)
                .escalationReason(c.getEscalationReason())
                .returnReason(c.getReturnReason())
                .build();
    }

    private List<String> parseManualReviewReasons(String raw) {
        if (raw == null || raw.isBlank()) return Collections.emptyList();

        // Attempt JSON parse, else fallback to splitting by comma
        try {
            return MAPPER.readValue(raw, new TypeReference<List<String>>() {});
        } catch (Exception ex) {
            log.debug("manualReviewReasons not valid JSON, splitting by comma. raw={}", raw);
            return Arrays.stream(raw.split(","))
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .collect(Collectors.toList());
        }
    }

    // Existing mock generator retained for rapid dev/fallback
    private List<WorkItem> generateMockItems(int offset, int limit, String assignee) {
        return IntStream.range(0, limit)
                .mapToObj(i -> {
                    String caseId = "HRA-" + UUID.randomUUID().toString().substring(0, 8);
                    List<String> mockReasons = List.of("Mock reason " + (i + 1));
                    return WorkItem.builder()
                            .caseId(caseId)
                            .clientId("C-" + (offset + i + 1000))
                            .clientName("Client " + (offset + i + 1))
                            .clientType(i % 3 == 0 ? "Investment" : "Corporate")
                            .status(i % 3 == 0 ? "in-progress" : (i % 3 == 1 ? "unassigned" : "completed"))
                            .priority(i % 4 == 0 ? "critical" : (i % 4 == 1 ? "high" : "medium"))
                            .assignedAnalyst(assignee == null || assignee.isBlank() ? "Unassigned" : assignee)
                            .lob(i % 2 == 0 ? "Investment Banking" : "Commercial Banking")
                            .riskRating(i % 3 == 0 ? "High" : (i % 3 == 1 ? "Medium" : "Low"))
                            .manualReviewReasons(mockReasons)
                            .createdDate(java.time.Instant.now().minusSeconds(3600L * i).toString())
                            .dueDate(java.time.Instant.now().plusSeconds(86400L * (i % 7)).toString())
                            .daysInQueue(i)
                            .build();
                })
                .collect(Collectors.toList());
    }
}