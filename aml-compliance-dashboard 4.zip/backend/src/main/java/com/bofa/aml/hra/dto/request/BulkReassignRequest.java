package com.bofa.aml.hra.dto.request;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BulkReassignRequest {
    @NotEmpty(message = "At least one caseId is required")
    private List<String> caseIds;

    // Either assignee or lob can be supplied depending on reassign type
    private String newAssignee;

    private String newLob;
}