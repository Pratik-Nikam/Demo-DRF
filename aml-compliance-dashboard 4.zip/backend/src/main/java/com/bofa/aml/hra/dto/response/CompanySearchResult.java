package com.bofa.aml.hra.dto.response;

public class CompanySearchResult {
    // placeholder
}