package com.bofa.aml.hra.dto.response;

public class RiskMitigantsResponse {
    // placeholder
}