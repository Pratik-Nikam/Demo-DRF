package com.bofa.aml.hra.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Builder.Default;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Persisted Mongo document for case records used by workflow APIs.
 * - Primary key `id` is generated if not provided (UUID string).
 * - `caseId` is the business-facing identifier (e.g. HRA-2024-0101).
 * - `manualReviewReasons` is stored as TEXT (JSON array or CSV) to keep schema simple for now.
 */
@Document(collection = "cases")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CaseEntity {

    @Id
    @Default
    private String id = UUID.randomUUID().toString();

    private String caseId;

    private String clientId;

    private String clientName;

    private String clientType; // e.g. Individual|Corporate|Investment|Banking

    private String status; // e.g. new, unassigned, assigned, in-progress, escalated, returned, completed

    private String priority; // low|medium|high|critical

    private String assignedAnalyst;

    private String lob;

    private String riskRating; // Low|Medium|High

    private String manualReviewReasons; // JSON array or CSV string

    private String jurisdiction;

    private String escalationReason;

    private String returnReason;

    // NEW: persisted disposition recorded by manager / FLU / GFC
    private String disposition;

    @Default
    private LocalDateTime createdAt = LocalDateTime.now();

    private LocalDate dueDate;

    private LocalDateTime completedDate;
}