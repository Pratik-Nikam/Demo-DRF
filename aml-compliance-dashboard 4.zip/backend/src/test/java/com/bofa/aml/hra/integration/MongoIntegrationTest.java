package com.bofa.aml.hra.integration;

import com.bofa.aml.hra.model.CaseEntity;
import com.bofa.aml.hra.repository.CaseRepository;
import org.junit.jupiter.api.Test;
import org.testcontainers.containers.MongoDBContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration test using Testcontainers to provide a throwaway MongoDB instance.
 * Requires Docker to be available on the host running the tests.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@Testcontainers
public class MongoIntegrationTest {

    @Container
    private static final MongoDBContainer mongo = new MongoDBContainer("mongo:6.0.10");

    @DynamicPropertySource
    static void registerProperties(DynamicPropertyRegistry registry) {
        // Provide Testcontainers Mongo URI to Spring
        registry.add("spring.data.mongodb.uri", mongo::getReplicaSetUrl);
    }

    @Autowired
    private CaseRepository caseRepository;

    @Test
    void repositorySaveAndFind_byCaseId_shouldPersistAndRetrieve() {
        // Arrange: create a test CaseEntity
        CaseEntity testCase = CaseEntity.builder()
                .caseId("IT-CASE-1")
                .clientId("IT-CLIENT-1")
                .clientName("Integration Test Corp")
                .clientType("Corporate")
                .status("unassigned")
                .priority("medium")
                .assignedAnalyst(null)
                .lob("Integration Testing")
                .riskRating("Low")
                .manualReviewReasons("[]")
                .jurisdiction("Testland")
                .createdAt(LocalDateTime.now())
                .dueDate(LocalDate.now().plusDays(7))
                .build();

        // Act: save and retrieve
        CaseEntity saved = caseRepository.save(testCase);

        // Assert: persisted id and fields are present
        assertNotNull(saved, "Saved entity should not be null");
        assertNotNull(saved.getId(), "Saved entity must have an id");
        Optional<CaseEntity> fetched = caseRepository.findByCaseId("IT-CASE-1");
        assertTrue(fetched.isPresent(), "Should find saved case by caseId");
        assertEquals("IT-CLIENT-1", fetched.get().getClientId());
        assertEquals("Integration Test Corp", fetched.get().getClientName());

        // Cleanup: remove test document
        caseRepository.deleteById(saved.getId());
        assertFalse(caseRepository.findByCaseId("IT-CASE-1").isPresent(), "Test document should be removed");
    }
}