package com.bofa.aml.hra.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class WorkflowControllerIT {

    @Autowired
    private MockMvc mockMvc;

    @Value("${spring.security.user.name}")
    private String adminUser;

    @Value("${spring.security.user.password}")
    private String adminPassword;

    @Test
    void getWorkQueue_returnsApiResponse_withDataItems() throws Exception {
        int limit = 5;

        mockMvc.perform(get("/v1/workflows/work-queue")
                        .param("limit", String.valueOf(limit))
                        .param("offset", "0")
                        .with(httpBasic(adminUser, adminPassword))
                        .accept("application/json"))
                .andDo(print())
                .andExpect(status().isOk())
                // ApiResponse uses a string status field; assert that instead of a boolean 'success'
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.data.items").isArray())
                .andExpect(jsonPath("$.data.items.length()").value(limit));
    }
}