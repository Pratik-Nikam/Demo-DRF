package com.bofa.aml.hra.controller;

import com.bofa.aml.hra.model.CaseEntity;
import com.bofa.aml.hra.repository.CaseRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
class WorkflowControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private CaseRepository caseRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        // Ensure a clean collection for each test run
        caseRepository.deleteAll();
    }

    @Test
    void bulkReassign_shouldUpdateCases_andReturnCounts() throws Exception {
        // Arrange - create two persisted cases with known caseId values
        CaseEntity c1 = CaseEntity.builder()
                .caseId("HRA-TEST-001")
                .clientId("C-1001")
                .clientName("Test Client 1")
                .clientType("Corporate")
                .status("assigned")
                .priority("medium")
                .assignedAnalyst("alice")
                .lob("Investment Banking")
                .createdAt(LocalDateTime.now())
                .dueDate(LocalDate.now().plusDays(7))
                .build();

        CaseEntity c2 = CaseEntity.builder()
                .caseId("HRA-TEST-002")
                .clientId("C-1002")
                .clientName("Test Client 2")
                .clientType("Investment")
                .status("in-progress")
                .priority("high")
                .assignedAnalyst("bob")
                .lob("Commercial Banking")
                .createdAt(LocalDateTime.now())
                .dueDate(LocalDate.now().plusDays(3))
                .build();

        caseRepository.saveAll(List.of(c1, c2));

        // Prepare request payload: update assignee and lob for both caseIds
        Map<String, Object> payload = Map.of(
                "caseIds", List.of("HRA-TEST-001", "HRA-TEST-002"),
                "newAssignee", "charlie",
                "newLob", "Wealth Management"
        );
        String json = objectMapper.writeValueAsString(payload);

        // Act & Assert - call endpoint and verify response wrapper counts
        mockMvc.perform(post("/v1/workflows/bulk-reassign")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                // ApiResponse wrapper -> data.updatedCount / data.failedCount
                .andExpect(jsonPath("$.data.updatedCount").value(2))
                .andExpect(jsonPath("$.data.failedCount").value(0));

        // Verify persisted changes
        List<CaseEntity> saved = caseRepository.findByCaseIdIn(List.of("HRA-TEST-001", "HRA-TEST-002"));
        assertThat(saved).hasSize(2);

        saved.forEach(c -> {
            assertThat(c.getAssignedAnalyst()).isEqualTo("charlie");
            assertThat(c.getLob()).isEqualTo("Wealth Management");
        });
    }
}