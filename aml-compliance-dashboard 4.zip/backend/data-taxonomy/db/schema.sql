-- DDL for `cases` table (PostgreSQL)
CREATE TABLE cases (
    id VARCHAR(36) PRIMARY KEY,                                  -- UUID string (36 chars)
    case_id VARCHAR(64) NOT NULL UNIQUE,                         -- business-facing id (HRA-...)
    client_id VARCHAR(64) NOT NULL,
    client_name VARCHAR(255),
    client_type VARCHAR(50),
    status VARCHAR(50),
    priority VARCHAR(20),
    assigned_analyst VARCHAR(100),
    lob VARCHAR(100),
    risk_rating VARCHAR(20),
    manual_review_reasons TEXT,                                  -- stored JSON array or CSV
    jurisdiction VARCHAR(100),
    escalation_reason TEXT,
    return_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    due_date DATE,
    completed_date TIMESTAMPTZ
);

-- Helpful indexes to support repository queries and searches
CREATE INDEX idx_cases_assigned_analyst ON cases (assigned_analyst);
CREATE INDEX idx_cases_lob ON cases (lob);
CREATE INDEX idx_cases_status ON cases (status);
CREATE INDEX idx_cases_created_at ON cases (created_at);
CREATE INDEX idx_cases_assigned_status ON cases (assigned_analyst, status);

-- Lowercase expression indexes to accelerate case-insensitive search used by repository
CREATE INDEX idx_cases_caseid_lower ON cases (LOWER(case_id));
CREATE INDEX idx_cases_clientname_lower ON cases (LOWER(client_name));
CREATE INDEX idx_cases_clientid_lower ON cases (LOWER(client_id));

-- Additional recommended indexes from repository taxonomy
-- Index for completed_date range queries
CREATE INDEX IF NOT EXISTS idx_cases_completed_date ON cases (completed_date);

-- Index to speed detection of explicit escalation_reason
CREATE INDEX IF NOT EXISTS idx_cases_escalation_reason ON cases (escalation_reason);

-- Enable trigram extension to suppo    rt fast substring search (used for LIKE/regex style queries)
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Trigram GIN indexes to improve performance of contains/regex searches on text fields
CREATE INDEX IF NOT EXISTS idx_cases_caseid_trgm ON cases USING gin (case_id gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_cases_clientname_trgm ON cases USING gin (client_name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_cases_clientid_trgm ON cases USING gin (client_id gin_trgm_ops);

-- Optional: index manual_review_reasons as trigram to accelerate keyword scans
CREATE INDEX IF NOT EXISTS idx_cases_manualreview_trgm ON cases USING gin (manual_review_reasons gin_trgm_ops);