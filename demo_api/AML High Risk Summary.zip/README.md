
  # AML High Risk Summary

  This is a code bundle for AML High Risk Summary. The original project is available at https://www.figma.com/design/IjqYipVfvTPINRR3ieGR5j/AML-High-Risk-Summary.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  