import { useState } from 'react';
import { SummaryCard } from './components/SummaryCard';
import { CaseTable, CaseData } from './components/CaseTable';
import { CaseDetailView } from './components/CaseDetailView';
import { ControlProcessManagement } from './components/ControlProcessManagement';
import { BulkOperationsDialog } from './components/bulk-operations-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Button } from './components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './components/ui/dropdown-menu';
import {
  Folder,
  AlertCircle,
  CheckCircle,
  RotateCcw,
  Users,
  Home,
  User,
  Download,
  Settings,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  ClipboardList,
  ChevronDown,
  Check,
  Eye,
  Building,
  UserRound,
  Info,
  X,
  Target,
} from 'lucide-react';

import { Badge } from './components/ui/badge';
import { Toaster } from './components/ui/sonner';

// Mock data
const mockCases: CaseData[] = [
  {
    id: '1',
    caseId: 'HRA-2024-67201',
    client: 'Global Transfers Inc',
    clientCompany: 'Corporate',
    status: 'Assigned',
    priority: 'High',
    lob: 'Investment Banking',
    daysInQueue: 3,
    dueDate: '2024-06-23',
  },
  {
    id: '2',
    caseId: 'HRA-2024-67203',
    client: 'Alexander Petrov',
    clientCompany: 'Individual',
    status: 'In Progress',
    priority: 'Critical',
    lob: 'Retail Banking',
    daysInQueue: 5,
    dueDate: '2024-06-24',
  },
  {
    id: '3',
    caseId: 'HRA-2024-67206',
    client: 'Meridian Investments',
    clientCompany: 'Hedge Fund',
    status: 'Manual Review',
    priority: 'Medium',
    lob: 'Wealth Management',
    daysInQueue: 4,
    dueDate: '2024-06-23',
  },
  {
    id: '4',
    caseId: 'HRA-2024-67207',
    client: 'Pacific Trade Solutions',
    clientCompany: 'Corporate',
    status: 'Returned',
    priority: 'High',
    lob: 'Commercial Banking',
    daysInQueue: 5,
    dueDate: '2024-06-22',
  },
  {
    id: '5',
    caseId: 'HRA-2024-67209',
    client: 'Sterling Financial Services',
    clientCompany: 'Banking',
    status: 'Assigned',
    priority: 'Medium',
    lob: 'Investment Banking',
    daysInQueue: 6,
    dueDate: '2024-06-21',
  },
  {
    id: '6',
    caseId: 'HRA-2024-67211',
    client: 'Euro Mining Corp',
    clientCompany: 'Corporate',
    status: 'In Progress',
    priority: 'Low',
    lob: 'Commercial Banking',
    daysInQueue: 7,
    dueDate: '2024-06-20',
  },
  {
    id: '7',
    caseId: 'HRA-2024-67213',
    client: 'Alpine Holdings Ltd',
    clientCompany: 'Investment',
    status: 'Completed',
    priority: 'Medium',
    lob: 'Private Banking',
    daysInQueue: 10,
    dueDate: '2024-06-15',
  },
  {
    id: '8',
    caseId: 'HRA-2024-67215',
    client: 'Phoenix Energy Group',
    clientCompany: 'Corporate',
    status: 'Completed',
    priority: 'High',
    lob: 'Investment Banking',
    daysInQueue: 8,
    dueDate: '2024-06-18',
  },
  {
    id: '9',
    caseId: 'HRA-2024-67217',
    client: 'Quantum Investments',
    clientCompany: 'Investment',
    status: 'Manual Review',
    priority: 'Critical',
    lob: 'Investment Banking',
    daysInQueue: 1,
    dueDate: '2024-06-26',
  },
  {
    id: '10',
    caseId: 'HRA-2024-67219',
    client: 'Global Trade Network',
    clientCompany: 'Corporate',
    status: 'Assigned',
    priority: 'High',
    lob: 'Commercial Banking',
    daysInQueue: 2,
    dueDate: '2024-06-25',
  },
  {
    id: '11',
    caseId: 'HRA-2024-67221',
    client: 'Marina Bay Securities',
    clientCompany: 'Banking',
    status: 'Completed',
    priority: 'Low',
    lob: 'Wealth Management',
    daysInQueue: 12,
    dueDate: '2024-06-19',
  },
];

export default function App() {
  const [selectedCases, setSelectedCases] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(30);
  const [selectedCaseData, setSelectedCaseData] = useState<CaseData | null>(null);
  const [showCaseDetail, setShowCaseDetail] = useState(false);
  const [showControlProcess, setShowControlProcess] = useState(false);
  const [selectedRole, setSelectedRole] = useState<string>('HRS Manager');
  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  const [selectedCaseId, setSelectedCaseId] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<'table' | 'detail' | 'control'>('table');
  const [bulkOperationsOpen, setBulkOperationsOpen] = useState(false);

  const handleSelectCase = (caseId: string) => {
    setSelectedCases((prev) =>
      prev.includes(caseId) ? prev.filter((id) => id !== caseId) : [...prev, caseId]
    );
  };

  const handleSelectAll = (selected: boolean) => {
    setSelectedCases(selected ? mockCases.map((c) => c.id) : []);
  };

  const handleCaseClick = (caseData: CaseData) => {
    setSelectedCaseData(caseData);
    setShowCaseDetail(true);
    setShowControlProcess(false);
    setCurrentView('detail');
  };

  const handleBackToList = () => {
    setShowCaseDetail(false);
    setSelectedCaseData(null);
    setShowControlProcess(false);
    setCurrentView('table');
  };

  const handleSettingsClick = () => {
    setShowControlProcess(true);
    setShowCaseDetail(false);
    setSelectedCaseData(null);
    setCurrentView('control');
  };

  const handleExport = () => {
    // Convert cases to CSV format
    const headers = ['Case ID', 'Client', 'Client Company', 'Status', 'Priority', 'LOB', 'Days in Queue', 'Due Date'];
    const csvContent = [
      headers.join(','),
      ...mockCases.map(case_ => [
        case_.caseId,
        `\"${case_.client}\"`,
        `\"${case_.clientCompany}\"`,
        case_.status,
        case_.priority,
        `\"${case_.lob}\"`,
        case_.daysInQueue,
        case_.dueDate
      ].join(','))
    ].join('\n');

    // Create blob and download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'my-workbasket-export.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filter cases based on active filter
  const filteredCases = activeFilter === 'active' 
    ? mockCases.filter(c => c.status === 'In Progress' || c.status === 'Manual Review')
    : activeFilter === 'returned'
    ? mockCases.filter(c => c.status === 'Returned')
    : activeFilter === 'completed'
    ? mockCases.filter(c => c.status === 'Completed')
    : activeFilter === 'escalations'
    ? mockCases.filter(c => 
        (c.priority === 'High' || c.priority === 'Critical') && 
        (c.status === 'Assigned' || c.status === 'Manual Review')
      )
    : mockCases;

  const totalPages = Math.ceil(filteredCases.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = Math.min(startIndex + pageSize, filteredCases.length);
  const currentCases = filteredCases.slice(startIndex, endIndex);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="max-w-[1920px] mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex flex-col gap-0.5">
                <div className="flex items-center gap-1">
                  <div className="w-2 h-8 bg-red-600 rounded"></div>
                  <div className="w-2 h-8 bg-red-500 rounded"></div>
                  <div className="w-2 h-8 bg-red-400 rounded"></div>
                </div>
              </div>
              <div>
                <h1 className="text-blue-900">AML High Risk Summary Tool</h1>
                <p className="text-sm text-gray-600">Risk Management & Monitoring</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-2 text-sm text-gray-700 hover:text-gray-900 border rounded-md px-3 py-2.5 bg-gray-100 hover:bg-gray-200">
                    <UserRound className="h-4 w-4" />
                    {selectedRole}
                    <ChevronDown className="h-4 w-4" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-56">
                  <DropdownMenuItem 
                    onClick={() => setSelectedRole('HRS Analyst')}
                    className="flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2">
                      <UserRound className="h-4 w-4" />
                      HRS Analyst
                    </div>
                    {selectedRole === 'HRS Analyst' && <Check className="h-4 w-4" />}
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => setSelectedRole('HRS Manager')}
                    className="flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2">
                      <UserRound className="h-4 w-4" />
                      HRS Manager
                    </div>
                    {selectedRole === 'HRS Manager' && <Check className="h-4 w-4" />}
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => setSelectedRole('FLU AML Representative')}
                    className="flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2">
                      <Building className="h-4 w-4" />
                      FLU AML Representative
                    </div>
                    {selectedRole === 'FLU AML Representative' && <Check className="h-4 w-4" />}
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => setSelectedRole('View Only')}
                    className="flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2">
                      <Eye className="h-4 w-4" />
                      View Only
                    </div>
                    {selectedRole === 'View Only' && <Check className="h-4 w-4" />}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <button 
                className="p-2 hover:bg-gray-100 rounded-lg"
                onClick={() => {
                  setSelectedCaseId(null);
                  setCurrentView('table');
                  setShowCaseDetail(false);
                  setShowControlProcess(false);
                  setSelectedCaseData(null);
                }}
              >
                <Home className="h-5 w-5 text-gray-600" />
              </button>
              <button 
                className="p-2 hover:bg-gray-100 rounded-lg"
                onClick={handleSettingsClick}
              >
                <Settings className="h-5 w-5 text-gray-600" />
              </button>
              <div className="text-right">
                <div className="text-sm">Sarah Johnson</div>
                <div className="text-xs text-gray-500">Investment Banking</div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="w-full mx-auto px-6 py-6 flex flex-col h-[calc(100vh-80px)]">
        {/* Conditional rendering: show case detail, control process, or table list */}
        {showCaseDetail && selectedCaseData ? (
          <CaseDetailView
            caseId={selectedCaseData.caseId}
            client={selectedCaseData.client}
            clientCompany={selectedCaseData.clientCompany}
            status={selectedCaseData.status}
            priority={selectedCaseData.priority}
            lob={selectedCaseData.lob}
            dueDate={selectedCaseData.dueDate}
            onBack={handleBackToList}
            userRole={selectedRole}
          />
        ) : showControlProcess ? (
          <ControlProcessManagement onBack={handleBackToList} />
        ) : (
          <div className="flex flex-col h-full w-full">
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6 flex-shrink-0 w-full">
              <SummaryCard
                title="My Active Cases"
                count={mockCases.filter(c => c.status === 'In Progress' || c.status === 'Manual Review').length}
                icon={Folder}
                iconColor="text-blue-600"
                iconBgColor="bg-blue-50"
                onClick={() => {
                  setActiveFilter('active');
                  setCurrentPage(1);
                }}
              />
              <SummaryCard
                title="Pending Escalations"
                count={mockCases.filter(c => 
                  (c.priority === 'High' || c.priority === 'Critical') && 
                  (c.status === 'Assigned' || c.status === 'Manual Review')
                ).length}
                icon={AlertCircle}
                iconColor="text-orange-600"
                iconBgColor="bg-orange-50"
                onClick={() => {
                  setActiveFilter('escalations');
                  setCurrentPage(1);
                }}
              />
              <SummaryCard
                title="Completed Today"
                count={mockCases.filter(c => c.status === 'Completed').length}
                icon={CheckCircle}
                iconColor="text-green-600"
                iconBgColor="bg-green-50"
                onClick={() => {
                  setActiveFilter('completed');
                  setCurrentPage(1);
                }}
              />
              <SummaryCard
                title="Returned Cases"
                count={mockCases.filter(c => c.status === 'Returned').length}
                icon={RotateCcw}
                iconColor="text-red-600"
                iconBgColor="bg-red-50"
                onClick={() => {
                  setActiveFilter('returned');
                  setCurrentPage(1);
                }}
              />
            </div>

            {/* Filter Banner */}
            {activeFilter && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg px-4 py-3 mb-4 flex items-center justify-between flex-shrink-0">
                <div className="flex items-center gap-2">
                  <Info className="h-4 w-4 text-blue-600" />
                  <span className="text-sm text-blue-900">
                    {activeFilter === 'active' 
                      ? 'Filtering by: Active Cases (assigned & in-progress)'
                      : activeFilter === 'completed'
                      ? 'Filtering by: Completed Cases'
                      : activeFilter === 'returned'
                      ? 'Filtering by: Returned Cases'
                      : 'Filtering by: Pending Escalations'}
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setActiveFilter(null);
                    setCurrentPage(1);
                  }}
                  className="text-blue-600 hover:text-blue-700 hover:bg-blue-100"
                >
                  Clear Filter
                </Button>
              </div>
            )}

            {/* Tabs */}
            <Tabs defaultValue="workbasket" className="flex flex-col flex-1 space-y-4">
              <TabsList className="flex-shrink-0 w-full">
                <TabsTrigger 
                  value="workbasket" 
                  className="data-[state=active]:bg-card dark:data-[state=active]:text-foreground focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:outline-ring dark:data-[state=active]:border-input dark:data-[state=active]:bg-input/30 text-foreground dark:text-muted-foreground h-[calc(100%-1px)] flex-1 justify-center gap-1.5 rounded-xl border border-transparent px-4 py-1 text-sm font-medium whitespace-nowrap transition-[color,box-shadow] focus-visible:ring-[3px] focus-visible:outline-1 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 flex items-center min-w-48"
                >
                  <Users className="h-4 w-4" />
                  My Workbasket
                </TabsTrigger>
                <TabsTrigger value="queue" className="flex items-center gap-2">
                  <ClipboardList className="h-4 w-4" />
                  Work Queue
                </TabsTrigger>
              </TabsList>

              <TabsContent value="workbasket" className="flex flex-col flex-1 space-y-0 m-0 data-[state=active]:flex">
                {/* Table Container with flex layout */}
                <div className="bg-white rounded-lg border p-4 flex flex-col flex-1">
                  <div className="flex items-center justify-between mb-4 flex-shrink-0">
                    <h2 className="text-gray-900">My Workbasket ({mockCases.length} cases)</h2>
                    <div className="flex items-center gap-2">
                      {selectedRole === 'HRS Analyst' && (
                        <Button className="bg-blue-900 hover:bg-blue-950 text-white flex items-center gap-2 px-4 py-2 rounded-lg">
                          <Target className="h-4 w-4" />
                          Get Next
                        </Button>
                      )}
                      <Button 
                        variant="outline" 
                        disabled={selectedCases.length === 0}
                        onClick={() => setBulkOperationsOpen(true)}
                      >
                        Bulk Operations
                        {selectedCases.length > 0 && (
                          <Badge variant="secondary" className="ml-2 px-1.5 py-0 text-xs bg-blue-100 text-blue-700">
                            {selectedCases.length}
                          </Badge>
                        )}
                      </Button>
                      <Button variant="outline">
                        <Download className="h-4 w-4 mr-2" />
                        Export
                      </Button>
                      <Button variant="outline">
                        <Settings className="h-4 w-4 mr-2" />
                        Reset Columns
                      </Button>
                    </div>
                  </div>

                  {/* Table - fills remaining space */}
                  <div className="flex-1 min-h-0">
                    <CaseTable
                      cases={currentCases}
                      selectedCases={selectedCases}
                      onSelectCase={handleSelectCase}
                      onSelectAll={handleSelectAll}
                      onCaseClick={handleCaseClick}
                    />
                  </div>

                  {/* Pagination */}
                  <div className="flex items-center justify-between mt-4 flex-shrink-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-600">Page Size</span>
                      <Select
                        value={pageSize.toString()}
                        onValueChange={(value) => {
                          setPageSize(Number(value));
                          setCurrentPage(1);
                        }}
                      >
                        <SelectTrigger className="w-20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="10">10</SelectItem>
                          <SelectItem value="20">20</SelectItem>
                          <SelectItem value="30">30</SelectItem>
                          <SelectItem value="50">50</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-600">
                        {startIndex + 1} to {endIndex} of {mockCases.length}
                      </span>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setCurrentPage(1)}
                          disabled={currentPage === 1}
                        >
                          <ChevronsLeft className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                          disabled={currentPage === 1}
                        >
                          <ChevronLeft className="h-4 w-4" />
                        </Button>
                        <span className="text-sm px-2">
                          Page {currentPage} of {totalPages}
                        </span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                          disabled={currentPage === totalPages}
                        >
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setCurrentPage(totalPages)}
                          disabled={currentPage === totalPages}
                        >
                          <ChevronsRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="queue" className="flex flex-col flex-1 space-y-0 m-0 data-[state=active]:flex">
                <div className="bg-white rounded-lg border p-8 text-center flex flex-col items-center justify-center flex-1">
                  <Folder className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-gray-900 mb-2">Work Queue</h3>
                  <p className="text-gray-600">
                    The work queue view will display all available cases for the team.
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>

      {/* Bulk Operations Dialog */}
      <BulkOperationsDialog 
        open={bulkOperationsOpen} 
        onOpenChange={(open) => {
          setBulkOperationsOpen(open);
          if (!open) {
            setSelectedCases([]);
          }
        }}
        userRole={
          selectedRole === 'HRS Analyst' ? 'hrs-analyst' : 
          selectedRole === 'HRS Manager' ? 'hrs-manager' : 
          selectedRole === 'FLU AML Representative' ? 'flu-aml' : 
          'view-only'
        }
        currentUser={{ name: 'Sarah Johnson', role: selectedRole }}
        tableType="workbasket"
        selectedCases={selectedCases.map(id => {
          const caseData = mockCases.find(c => c.id === id);
          return caseData?.caseId || id;
        })}
      />

      {/* Toast Notifications */}
      <Toaster />
    </div>
  );
}