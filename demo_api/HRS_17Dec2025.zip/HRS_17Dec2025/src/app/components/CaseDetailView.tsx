/**
 * CaseDetailView - Legacy Export
 * 
 * This file maintains backward compatibility by re-exporting
 * from the refactored case-detail module.
 * 
 * The component has been refactored into a modular structure
 * located in ./case-detail/ for better maintainability.
 * 
 * @deprecated Import directly from './case-detail' for new code
 */

export { CaseDetailView } from './case-detail';
export type { CaseDetailViewProps } from './case-detail';
