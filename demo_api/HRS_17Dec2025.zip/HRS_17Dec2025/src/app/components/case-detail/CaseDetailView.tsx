/**
 * CaseDetailView Component
 * 
 * Main component for displaying detailed case information with multiple sections.
 * Provides a comprehensive view of case data including customer information,
 * risk factors, mitigants, and summary with role-based access controls.
 * 
 * Architecture:
 * - Separated into sub-components for better maintainability
 * - Uses accordion pattern for collapsible sections
 * - Implements role-based permissions for editing
 * - Responsive design for various screen sizes
 * 
 * @module CaseDetailView
 */

import { Button } from '../ui/button';
import { Accordion } from '../ui/accordion';
import { ArrowLeft, User, AlertTriangle, FileText, Shield, CheckCircle } from 'lucide-react';

// Type definitions
import type { CaseDetailViewProps, UserRole, CaseData } from './types';

// Utility functions
import { convertUserRole, canUserEdit } from './utils';

// Sub-components
import { CaseInfoCard } from './CaseInfoCard';
import { SummaryCardsGrid } from './SummaryCardsGrid';
import { RiskAccordionSection } from './RiskAccordionSection';

// Section components
import { CustomerInformationSection } from '../customer-information-section';
import { CrrRiskFactorsSection } from '../crr-risk-factors-section';
import { RiskFactorsAnalysis } from '../risk-factors-analysis';
import { RiskMitigantsSection } from '../risk-mitigants-section';
import { RiskSummarySection } from '../risk-summary-section';

/**
 * Main Case Detail View Component
 * 
 * Displays complete case information with the following sections:
 * 1. Customer Information (read-only)
 * 2. CRR Risk Factors (editable based on role)
 * 3. Additional Risk Factors (read-only)
 * 4. Risk Mitigants (editable based on role)
 * 5. Risk Summary (editable based on role)
 * 
 * @param props - Component properties
 * @returns Rendered case detail view
 */
export function CaseDetailView({
  caseId,
  client,
  clientCompany,
  status,
  priority,
  lob,
  dueDate,
  onBack,
  userRole = 'HRS Manager',
}: CaseDetailViewProps) {
  // ==========================================
  // DATA PREPARATION
  // ==========================================
  
  /**
   * Convert display role to normalized internal format
   * Example: 'HRS Analyst' -> 'hrs-analyst'
   */
  const normalizedRole: UserRole = convertUserRole(userRole);
  
  /**
   * Determine if current user has edit permissions
   * View-only users cannot edit any section
   */
  const hasEditPermission = canUserEdit(normalizedRole);
  
  /**
   * Case data object passed to all child sections
   * Centralized data structure for consistency
   */
  const caseData: CaseData = {
    caseId,
    client,
    clientCompany,
    status,
    priority,
    lob,
    dueDate,
  };

  // ==========================================
  // EVENT HANDLERS
  // ==========================================
  
  /**
   * Handle data changes in child components
   * Currently logs to console, can be extended for API calls
   */
  const handleDataChange = () => {
    console.log('Case data changed');
    // TODO: Implement save to backend
  };

  // ==========================================
  // RENDER
  // ==========================================

  return (
    <div className="bg-white">
      <div className="w-full min-h-screen px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
        
        {/* ==================== NAVIGATION ==================== */}
        <Button
          variant="ghost"
          className="mb-4 -ml-2"
          onClick={onBack}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Go Back to Work Queue
        </Button>

        {/* ==================== PAGE HEADER ==================== */}
        <div>
          <h2 className="text-2xl text-blue-900 mb-2">High Risk Summary Tool</h2>
          <p className="text-gray-600 mb-4">
            Comprehensive risk summary for high-risk clients with role-based access controls
          </p>

          {/* ==================== CASE INFO CARD ==================== */}
          <CaseInfoCard
            caseId={caseId}
            client={client}
            clientCompany={clientCompany}
            priority={priority}
            lob={lob}
            dueDate={dueDate}
            status={status}
          />
        </div>

        {/* ==================== SUMMARY CARDS ==================== */}
        <SummaryCardsGrid />

        {/* ==================== ACCORDION SECTIONS ==================== */}
        <div>
          <Accordion type="single" collapsible className="space-y-3">
            
            {/* Section 1: Customer Information (Always Read-Only) */}
            <RiskAccordionSection
              value="customer-info"
              title="Customer Information"
              icon={User}
              iconColor="text-blue-600"
              isEditable={hasEditPermission}
              forceReadOnly={true} // Customer info is always read-only
            >
              <CustomerInformationSection
                caseData={caseData}
                userRole={normalizedRole}
                canEdit={false}
                onDataChange={handleDataChange}
              />
            </RiskAccordionSection>

            {/* Section 2: CRR Risk Factors (Editable) */}
            <RiskAccordionSection
              value="cri-risk"
              title="CRR Risk Factors"
              icon={AlertTriangle}
              iconColor="text-orange-600"
              isEditable={hasEditPermission}
            >
              <CrrRiskFactorsSection
                caseData={caseData}
                userRole={normalizedRole}
                canEdit={hasEditPermission}
                onDataChange={handleDataChange}
              />
            </RiskAccordionSection>

            {/* Section 3: Additional Risk Factors (Read-Only) */}
            <RiskAccordionSection
              value="additional-risk"
              title="Additional Risk Factors"
              icon={FileText}
              iconColor="text-gray-600"
              isEditable={hasEditPermission}
              forceReadOnly={true} // Additional factors are read-only
            >
              <RiskFactorsAnalysis />
            </RiskAccordionSection>

            {/* Section 4: Risk Mitigants (Editable) */}
            <RiskAccordionSection
              value="risk-mitigants"
              title="Risk Mitigants"
              icon={Shield}
              iconColor="text-blue-600"
              isEditable={hasEditPermission}
            >
              <RiskMitigantsSection
                caseData={caseData}
                userRole={normalizedRole}
                canEdit={hasEditPermission}
                onDataChange={handleDataChange}
              />
            </RiskAccordionSection>

            {/* Section 5: Risk Summary (Editable) */}
            <RiskAccordionSection
              value="risk-summary"
              title="Risk Summary"
              icon={CheckCircle}
              iconColor="text-gray-600"
              isEditable={hasEditPermission}
            >
              <RiskSummarySection
                caseData={caseData}
                userRole={normalizedRole}
                canEdit={hasEditPermission}
                onDataChange={handleDataChange}
              />
            </RiskAccordionSection>
            
          </Accordion>
        </div>
      </div>
    </div>
  );
}
