# Case Detail View - Architecture Documentation

## Table of Contents
1. [Component Structure](#component-structure)
2. [Data Flow](#data-flow)
3. [File Organization](#file-organization)
4. [Dependency Graph](#dependency-graph)
5. [Refactoring Benefits](#refactoring-benefits)

---

## Component Structure

### Visual Component Tree

```
┌─────────────────────────────────────────────────────────────────┐
│                       CaseDetailView.tsx                        │
│                    (Main Orchestrator)                          │
└─────────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌──────────────┐    ┌──────────────────┐    ┌──────────────┐
│ Back Button  │    │  Page Header     │    │  Case Info   │
│   (Nav)      │    │   (Title +       │    │     Card     │
│              │    │ Description)     │    │              │
└──────────────┘    └──────────────────┘    └──────────────┘
                                                    │
                              ┌─────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌──────────────┐    ┌──────────────────┐    ┌──────────────┐
│   Summary    │    │   Accordion      │    │   Future     │
│    Cards     │    │   Sections       │    │   Features   │
│    Grid      │    │  (5 sections)    │    │              │
└──────────────┘    └──────────────────┘    └──────────────┘
```

### Detailed Accordion Structure

```
Accordion (Collapsible Sections)
│
├── Section 1: Customer Information [READ ONLY]
│   ├── Header: User Icon + Title + "Read Only" Badge
│   └── Content: CustomerInformationSection Component
│
├── Section 2: CRR Risk Factors [EDITABLE*]
│   ├── Header: AlertTriangle Icon + Title + Permission Badge
│   └── Content: CrrRiskFactorsSection Component
│
├── Section 3: Additional Risk Factors [READ ONLY]
│   ├── Header: FileText Icon + Title + "Read Only" Badge
│   └── Content: RiskFactorsAnalysis Component
│
├── Section 4: Risk Mitigants [EDITABLE*]
│   ├── Header: Shield Icon + Title + Permission Badge
│   └── Content: RiskMitigantsSection Component
│
└── Section 5: Risk Summary [EDITABLE*]
    ├── Header: CheckCircle Icon + Title + Permission Badge
    └── Content: RiskSummarySection Component

* Editable based on user role (view-only users cannot edit)
```

---

## Data Flow

### User Role Conversion Flow

```
User Input (Display Role)
        │
        │ "HRS Analyst"
        │
        ▼
┌──────────────────────┐
│  convertUserRole()   │  ◄── utils.ts
│   (Utility Func)     │
└──────────────────────┘
        │
        │ "hrs-analyst"
        │
        ▼
┌──────────────────────┐
│   canUserEdit()      │  ◄── utils.ts
│   (Check Perms)      │
└──────────────────────┘
        │
        │ true/false
        │
        ▼
┌──────────────────────┐
│  getEditBadgeConfig()│  ◄── utils.ts
│  (Badge Display)     │
└──────────────────────┘
        │
        │ { text, className }
        │
        ▼
   UI Rendering
```

### Case Data Flow

```
Props Input
    │
    ├── caseId
    ├── client
    ├── clientCompany
    ├── status
    ├── priority
    ├── lob
    └── dueDate
        │
        ▼
┌──────────────────────┐
│  CaseData Object     │  ◄── Centralized in CaseDetailView
│   (Normalized)       │
└──────────────────────┘
        │
        └─────────────┬─────────────┬─────────────┬─────────────┐
                      │             │             │             │
                      ▼             ▼             ▼             ▼
              ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐
              │Customer  │  │CRR Risk  │  │Risk      │  │Risk      │
              │Info      │  │Factors   │  │Mitigants │  │Summary   │
              │Section   │  │Section   │  │Section   │  │Section   │
              └──────────┘  └──────────┘  └──────────┘  └──────────┘
```

### Color Resolution Flow

```
Status/Priority Value
        │
        │ "High"
        │
        ▼
┌──────────────────────┐
│  getStatusColor()    │  ◄── utils.ts
│  getPriorityColor()  │
└──────────────────────┘
        │
        │ Lookup in constants
        │
        ▼
┌──────────────────────┐
│  STATUS_COLORS       │  ◄── constants.ts
│  PRIORITY_COLORS     │
└──────────────────────┘
        │
        │ "bg-red-100 text-red-700"
        │
        ▼
┌──────────────────────┐
│  Tailwind Classes    │
│  Applied to Badge    │
└──────────────────────┘
```

---

## File Organization

### Module Structure

```
/src/app/components/
├── CaseDetailView.tsx              [Legacy Export - Backward Compat]
│
└── case-detail/                    [New Refactored Module]
    │
    ├── index.ts                    [Barrel Exports]
    │   ├── Export: CaseDetailView
    │   ├── Export: Sub-components
    │   ├── Export: Types
    │   ├── Export: Utils
    │   └── Export: Constants
    │
    ├── types.ts                    [Type Definitions]
    │   ├── UserRole
    │   ├── CaseData
    │   ├── CaseDetailViewProps
    │   ├── SummaryCardConfig
    │   └── AccordionSectionConfig
    │
    ├── constants.ts                [Configuration & Constants]
    │   ├── STATUS_COLORS
    │   ├── PRIORITY_COLORS
    │   ├── STATUS_DOT_COLORS
    │   ├── SUMMARY_CARDS
    │   └── USER_ROLE_MAP
    │
    ├── utils.ts                    [Helper Functions]
    │   ├── getStatusColor()
    │   ├── getPriorityColor()
    │   ├── getStatusDotColor()
    │   ├── convertUserRole()
    │   ├── canUserEdit()
    │   └── getEditBadgeConfig()
    │
    ├── CaseDetailView.tsx          [Main Component]
    │   └── Orchestrates all sub-components
    │
    ├── CaseInfoCard.tsx            [Sub-Component]
    │   └── Displays case header info
    │
    ├── SummaryCardsGrid.tsx        [Sub-Component]
    │   └── Displays summary cards
    │
    ├── RiskAccordionSection.tsx    [Reusable Component]
    │   └── Template for accordion sections
    │
    ├── README.md                   [Documentation]
    │   └── Usage guide & API docs
    │
    └── ARCHITECTURE.md             [This File]
        └── Architecture overview
```

---

## Dependency Graph

### Import Dependencies

```
CaseDetailView.tsx
    │
    ├── Imports from types.ts
    │   ├── CaseDetailViewProps
    │   ├── UserRole
    │   └── CaseData
    │
    ├── Imports from utils.ts
    │   ├── convertUserRole()
    │   └── canUserEdit()
    │
    ├── Imports from Sub-Components
    │   ├── CaseInfoCard
    │   ├── SummaryCardsGrid
    │   └── RiskAccordionSection
    │
    └── Imports from Section Components (external)
        ├── CustomerInformationSection
        ├── CrrRiskFactorsSection
        ├── RiskFactorsAnalysis
        ├── RiskMitigantsSection
        └── RiskSummarySection
```

```
CaseInfoCard.tsx
    │
    ├── Imports from utils.ts
    │   ├── getPriorityColor()
    │   └── getStatusDotColor()
    │
    └── Imports from UI components
        └── Badge
```

```
SummaryCardsGrid.tsx
    │
    ├── Imports from constants.ts
    │   └── SUMMARY_CARDS
    │
    └── Imports from UI components
        └── Card
```

```
RiskAccordionSection.tsx
    │
    ├── Imports from utils.ts
    │   └── getEditBadgeConfig()
    │
    └── Imports from UI components
        ├── Badge
        ├── AccordionItem
        ├── AccordionTrigger
        └── AccordionContent
```

```
utils.ts
    │
    └── Imports from constants.ts
        ├── STATUS_COLORS
        ├── PRIORITY_COLORS
        ├── STATUS_DOT_COLORS
        ├── USER_ROLE_MAP
        └── Default color constants
```

---

## Refactoring Benefits

### Before Refactoring

```
CaseDetailView.tsx (305 lines)
├── 100+ lines of JSX
├── Inline color logic
├── Inline role conversion
├── Repeated accordion patterns
├── No type safety
└── Hard to test
```

**Problems:**
- ❌ 305 lines in single file
- ❌ Mixed concerns (logic + presentation)
- ❌ Repeated code patterns
- ❌ Hard to review in pull requests
- ❌ Difficult to unit test
- ❌ No documentation

### After Refactoring

```
case-detail/ (Multiple focused files)
│
├── types.ts (70 lines)          ✅ Type definitions
├── constants.ts (100 lines)     ✅ Configuration
├── utils.ts (90 lines)          ✅ Pure functions (testable)
├── CaseDetailView.tsx (150 lines) ✅ Main logic
├── CaseInfoCard.tsx (80 lines)  ✅ Isolated component
├── SummaryCardsGrid.tsx (50 lines) ✅ Isolated component
├── RiskAccordionSection.tsx (70 lines) ✅ Reusable template
├── README.md                    ✅ Documentation
└── ARCHITECTURE.md              ✅ Architecture docs
```

**Benefits:**
- ✅ Single Responsibility Principle
- ✅ Easy to locate and modify code
- ✅ Testable utility functions
- ✅ Reusable components
- ✅ Type-safe with comprehensive types
- ✅ Documented with examples
- ✅ Easier code reviews
- ✅ Better onboarding for new devs

---

## Code Review Checklist

When reviewing changes to this module, check:

### ✅ Type Safety
- [ ] All new functions have proper TypeScript types
- [ ] Props interfaces are defined in `types.ts`
- [ ] No `any` types without justification

### ✅ Organization
- [ ] New utilities added to `utils.ts`
- [ ] New constants added to `constants.ts`
- [ ] New types added to `types.ts`
- [ ] Exports updated in `index.ts`

### ✅ Documentation
- [ ] JSDoc comments for new functions
- [ ] README updated for new features
- [ ] Examples provided for complex functionality

### ✅ Testing
- [ ] Unit tests for utility functions
- [ ] Integration tests for components
- [ ] Edge cases covered

### ✅ Consistency
- [ ] Follows existing naming conventions
- [ ] Uses established patterns
- [ ] Consistent code formatting

---

## Performance Considerations

### Optimizations Applied

1. **Memoization Opportunities**
   ```typescript
   // Utils are pure functions - can be memoized if needed
   const color = useMemo(() => getStatusColor(status), [status]);
   ```

2. **Component Splitting**
   - Each sub-component can be lazy-loaded if needed
   - Reduces initial bundle size

3. **Constant References**
   - Color mappings are constant objects
   - No runtime computation needed

4. **Type Checking at Compile Time**
   - TypeScript catches errors before runtime
   - No runtime type checking overhead

---

## Migration Path

### For Existing Code

**Step 1:** Update imports
```typescript
// Old
import { CaseDetailView } from './components/CaseDetailView';

// New
import { CaseDetailView } from './components/case-detail';
```

**Step 2:** No other changes needed!
- All props remain the same
- All functionality preserved
- Backward compatible

### For New Features

**Step 1:** Add types to `types.ts`
```typescript
export interface NewFeatureProps {
  // ...
}
```

**Step 2:** Add constants to `constants.ts`
```typescript
export const NEW_FEATURE_CONFIG = {
  // ...
};
```

**Step 3:** Add utilities to `utils.ts`
```typescript
export function getNewFeatureValue() {
  // ...
}
```

**Step 4:** Create component file
```typescript
// new-feature.tsx
export function NewFeature() {
  // ...
}
```

**Step 5:** Export from `index.ts`
```typescript
export { NewFeature } from './new-feature';
```

---

## Summary

This refactoring transforms a monolithic 305-line component into a well-organized, maintainable module with:

- 📁 **8 focused files** instead of 1 large file
- 🎯 **Clear separation of concerns**
- 🧪 **Testable utility functions**
- 🔄 **Reusable components**
- 📝 **Comprehensive documentation**
- ✅ **Full backward compatibility**
- 🚀 **Scalable architecture**

The result is **professional, enterprise-grade code** that's easy to understand, modify, and extend! 🎉
