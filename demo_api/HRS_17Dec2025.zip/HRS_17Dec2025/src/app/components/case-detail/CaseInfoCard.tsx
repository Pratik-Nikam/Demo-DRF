/**
 * CaseInfoCard Component
 * 
 * Displays the header card with case identification and key metrics.
 * Shows case ID, client name, company, risk rating, jurisdiction, LOB, due date, and status.
 */

import { Badge } from '../ui/badge';
import { FileCheck } from 'lucide-react';
import { getPriorityColor, getStatusDotColor } from './utils';

interface CaseInfoCardProps {
  caseId: string;
  client: string;
  clientCompany: string;
  priority: string;
  lob: string;
  dueDate: string;
  status: string;
  jurisdiction?: string;
}

/**
 * Info field component for displaying labeled data
 */
function InfoField({ label, value, badge }: { label: string; value?: string; badge?: React.ReactNode }) {
  return (
    <div className="text-center">
      <div className="text-xs text-gray-600 mb-1">{label}</div>
      {badge || <div className="text-sm text-gray-900">{value}</div>}
    </div>
  );
}

/**
 * Status field with colored indicator dot
 */
function StatusField({ status }: { status: string }) {
  return (
    <div className="text-center">
      <div className="text-xs text-gray-600 mb-1">Status</div>
      <div className="flex items-center gap-2 text-sm text-gray-900">
        <div className={`w-2 h-2 rounded-full ${getStatusDotColor(status)}`} />
        {status.toLowerCase()}
      </div>
    </div>
  );
}

export function CaseInfoCard({
  caseId,
  client,
  clientCompany,
  priority,
  lob,
  dueDate,
  status,
  jurisdiction = 'Cayman Islands',
}: CaseInfoCardProps) {
  return (
    <div className="bg-white border rounded-lg p-4 mb-6">
      <div className="flex items-center justify-between gap-6">
        {/* Case Identification */}
        <div className="flex items-center gap-3">
          <FileCheck className="h-5 w-5 text-gray-600" />
          <span className="text-gray-900">
            {caseId} • {client} <span className="text-gray-500">({clientCompany})</span>
          </span>
        </div>

        {/* Case Metrics */}
        <div className="flex items-center gap-8">
          <InfoField
            label="Risk Rating"
            badge={
              <Badge variant="secondary" className={getPriorityColor(priority)}>
                {priority}
              </Badge>
            }
          />
          
          <InfoField label="Jurisdiction" value={jurisdiction} />
          <InfoField label="LOB" value={lob} />
          <InfoField label="Due Date" value={dueDate} />
          <StatusField status={status} />
        </div>
      </div>
    </div>
  );
}
