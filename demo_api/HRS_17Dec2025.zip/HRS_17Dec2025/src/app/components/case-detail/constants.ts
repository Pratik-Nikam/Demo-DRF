/**
 * Constants for Case Detail View
 * 
 * This file contains all constant values, color mappings, and configuration
 * used throughout the case detail view components.
 */

import {
  User,
  AlertTriangle,
  FileText,
  Shield,
  CheckCircle,
} from 'lucide-react';
import type { SummaryCardConfig } from './types';

/**
 * Color mappings for case status badges
 * Maps status string to Tailwind CSS classes
 */
export const STATUS_COLORS: Record<string, string> = {
  'Assigned': 'bg-blue-100 text-blue-700',
  'In Progress': 'bg-orange-100 text-orange-700',
  'Manual Review': 'bg-yellow-100 text-yellow-700',
  'Retired': 'bg-purple-100 text-purple-700',
  'Completed': 'bg-green-100 text-green-700',
};

/**
 * Color mappings for priority badges
 * Maps priority string to Tailwind CSS classes
 */
export const PRIORITY_COLORS: Record<string, string> = {
  'Low': 'bg-green-100 text-green-700',
  'Medium': 'bg-orange-100 text-orange-700',
  'High': 'bg-red-100 text-red-700',
  'Critical': 'bg-red-200 text-red-800',
};

/**
 * Color mappings for status indicator dots
 * Maps status string to Tailwind CSS background color classes
 */
export const STATUS_DOT_COLORS: Record<string, string> = {
  'Assigned': 'bg-blue-500',
  'In Progress': 'bg-orange-500',
  'Completed': 'bg-green-500',
  'Manual Review': 'bg-yellow-500',
  'Retired': 'bg-purple-500',
};

/**
 * Default color fallback for unknown statuses
 */
export const DEFAULT_STATUS_COLOR = 'bg-gray-100 text-gray-700';

/**
 * Default color fallback for unknown priorities
 */
export const DEFAULT_PRIORITY_COLOR = 'bg-gray-100 text-gray-700';

/**
 * Default status dot color for unknown statuses
 */
export const DEFAULT_STATUS_DOT_COLOR = 'bg-gray-500';

/**
 * Configuration for summary cards displayed at the top of case detail
 * Each card represents a major section of the case
 */
export const SUMMARY_CARDS: SummaryCardConfig[] = [
  {
    id: 'customer-info',
    icon: User,
    title: 'Customer Information',
    subtitle: '12 attributes',
    bgColor: 'bg-green-50',
    borderColor: 'border-green-200',
    iconColor: 'text-green-700',
    textColor: 'text-green-900',
  },
  {
    id: 'crr-risk',
    icon: AlertTriangle,
    title: 'CRR Risk Factors',
    subtitle: '9 factors tracked',
    bgColor: 'bg-orange-50',
    borderColor: 'border-orange-200',
    iconColor: 'text-orange-700',
    textColor: 'text-orange-900',
  },
  {
    id: 'additional-risk',
    icon: FileText,
    title: 'Additional Risk Factors',
    subtitle: '7 factors',
    bgColor: 'bg-gray-50',
    borderColor: 'border-gray-200',
    iconColor: 'text-gray-700',
    textColor: 'text-gray-900',
  },
  {
    id: 'risk-mitigants',
    icon: Shield,
    title: 'Risk Mitigants',
    subtitle: '4 controls',
    bgColor: 'bg-gray-50',
    borderColor: 'border-gray-200',
    iconColor: 'text-gray-700',
    textColor: 'text-gray-900',
  },
  {
    id: 'risk-summary',
    icon: CheckCircle,
    title: 'Risk Summary',
    subtitle: '3.2 risk score',
    bgColor: 'bg-gray-50',
    borderColor: 'border-gray-200',
    iconColor: 'text-gray-700',
    textColor: 'text-gray-900',
  },
];

/**
 * User role mapping from display names to normalized internal values
 */
export const USER_ROLE_MAP: Record<string, 'hrs-analyst' | 'hrs-manager' | 'flu-aml' | 'view-only'> = {
  'HRS Analyst': 'hrs-analyst',
  'HRS Manager': 'hrs-manager',
  'FLU AML Representative': 'flu-aml',
  'View Only': 'view-only',
};
