/**
 * Utility functions for Case Detail View
 * 
 * This file contains helper functions for data transformation,
 * color determination, and role conversion.
 */

import type { UserRole, DisplayUserRole } from './types';
import {
  STATUS_COLORS,
  PRIORITY_COLORS,
  STATUS_DOT_COLORS,
  DEFAULT_STATUS_COLOR,
  DEFAULT_PRIORITY_COLOR,
  DEFAULT_STATUS_DOT_COLOR,
  USER_ROLE_MAP,
} from './constants';

/**
 * Get Tailwind CSS classes for status badge based on status value
 * 
 * @param status - The case status string
 * @returns Tailwind CSS classes for background and text color
 * 
 * @example
 * getStatusColor('Assigned') // returns 'bg-blue-100 text-blue-700'
 */
export function getStatusColor(status: string): string {
  return STATUS_COLORS[status] || DEFAULT_STATUS_COLOR;
}

/**
 * Get Tailwind CSS classes for priority badge based on priority value
 * 
 * @param priority - The case priority string
 * @returns Tailwind CSS classes for background and text color
 * 
 * @example
 * getPriorityColor('High') // returns 'bg-red-100 text-red-700'
 */
export function getPriorityColor(priority: string): string {
  return PRIORITY_COLORS[priority] || DEFAULT_PRIORITY_COLOR;
}

/**
 * Get Tailwind CSS background color class for status indicator dot
 * 
 * @param status - The case status string
 * @returns Tailwind CSS background color class
 * 
 * @example
 * getStatusDotColor('In Progress') // returns 'bg-orange-500'
 */
export function getStatusDotColor(status: string): string {
  return STATUS_DOT_COLORS[status] || DEFAULT_STATUS_DOT_COLOR;
}

/**
 * Convert display user role to normalized internal role format
 * 
 * @param role - Display-friendly role name
 * @returns Normalized role value used internally
 * 
 * @example
 * convertUserRole('HRS Analyst') // returns 'hrs-analyst'
 */
export function convertUserRole(role: string): UserRole {
  return USER_ROLE_MAP[role] || 'view-only';
}

/**
 * Determine if a user role has edit permissions
 * 
 * @param role - Normalized user role
 * @returns true if user can edit, false otherwise
 * 
 * @example
 * canUserEdit('hrs-analyst') // returns true
 * canUserEdit('view-only') // returns false
 */
export function canUserEdit(role: UserRole): boolean {
  return role !== 'view-only';
}

/**
 * Get edit permission badge configuration
 * 
 * @param canEdit - Whether the user can edit
 * @returns Object with badge text and CSS classes
 * 
 * @example
 * getEditBadgeConfig(true) 
 * // returns { text: 'Editable', className: 'bg-blue-100 text-blue-700' }
 */
export function getEditBadgeConfig(canEdit: boolean): { text: string; className: string } {
  return canEdit
    ? { text: 'Editable', className: 'bg-blue-100 text-blue-700' }
    : { text: 'Read Only', className: 'bg-gray-100 text-gray-700' };
}
