# Case Detail View - Code Walkthrough Guide

## 🎯 Purpose

This guide walks you through the refactored Case Detail View module step-by-step, perfect for code reviews, onboarding, and understanding the architecture.

---

## 🗺️ Quick Navigation

### Start Here
1. 📋 [types.ts](#1-typests---the-contract) - Understand data structures
2. 🎨 [constants.ts](#2-constantsts---the-configuration) - See all config values
3. 🛠️ [utils.ts](#3-utilsts---the-toolbox) - Learn helper functions
4. 📦 [Components](#4-components) - Explore UI components
5. 🧪 [Testing](#testing-examples) - See how to test

### Documentation
- 📖 [README.md](./README.md) - Usage guide & API
- 🏗️ [ARCHITECTURE.md](./ARCHITECTURE.md) - Architecture diagrams
- 📊 [REFACTORING_SUMMARY.md](./REFACTORING_SUMMARY.md) - Before/after comparison

---

## 📚 File-by-File Walkthrough

### 1. types.ts - The Contract

**What it does:** Defines all TypeScript interfaces and types

**Start here because:** Types are the "contract" - they tell you what data flows through the system

#### Key Types:

```typescript
// User roles that determine permissions
type UserRole = 'hrs-analyst' | 'hrs-manager' | 'flu-aml' | 'view-only';

// Core case data passed to all sections
interface CaseData {
  caseId: string;
  client: string;
  clientCompany: string;
  status: string;
  priority: string;
  lob: string;
  dueDate: string;
}

// Main component props
interface CaseDetailViewProps {
  caseId: string;
  client: string;
  clientCompany: string;
  status: string;
  priority: string;
  lob: string;
  dueDate: string;
  onBack: () => void;
  userRole?: string;
}
```

**Review Checklist:**
- [ ] All props clearly defined
- [ ] Type names are descriptive
- [ ] Comments explain purpose
- [ ] No `any` types

---

### 2. constants.ts - The Configuration

**What it does:** Central configuration for all constant values

**Why separate:** Easy to modify colors/config without touching logic

#### Key Constants:

```typescript
// Status badge colors
const STATUS_COLORS = {
  'Assigned': 'bg-blue-100 text-blue-700',
  'In Progress': 'bg-orange-100 text-orange-700',
  'Completed': 'bg-green-100 text-green-700',
  // ...
};

// Priority badge colors
const PRIORITY_COLORS = {
  'Low': 'bg-green-100 text-green-700',
  'High': 'bg-red-100 text-red-700',
  // ...
};

// Summary cards configuration
const SUMMARY_CARDS = [
  {
    id: 'customer-info',
    icon: User,
    title: 'Customer Information',
    subtitle: '12 attributes',
    bgColor: 'bg-green-50',
    // ...
  },
  // ... 4 more cards
];
```

**Review Checklist:**
- [ ] All colors follow design system
- [ ] No magic strings in code
- [ ] Easy to add new values
- [ ] Well-documented

---

### 3. utils.ts - The Toolbox

**What it does:** Pure utility functions for data transformation

**Why separate:** Testable, reusable, single responsibility

#### Key Functions:

```typescript
// Get status badge color
function getStatusColor(status: string): string {
  return STATUS_COLORS[status] || DEFAULT_STATUS_COLOR;
}

// Get priority badge color
function getPriorityColor(priority: string): string {
  return PRIORITY_COLORS[priority] || DEFAULT_PRIORITY_COLOR;
}

// Convert user role
function convertUserRole(role: string): UserRole {
  return USER_ROLE_MAP[role] || 'view-only';
}

// Check edit permission
function canUserEdit(role: UserRole): boolean {
  return role !== 'view-only';
}
```

**Why this is great:**
✅ Pure functions (no side effects)
✅ Easy to test
✅ Reusable across app
✅ Clear single purpose

**Example Test:**
```typescript
test('getStatusColor returns correct color', () => {
  expect(getStatusColor('Assigned')).toBe('bg-blue-100 text-blue-700');
});
```

**Review Checklist:**
- [ ] Functions are pure (no side effects)
- [ ] All functions have JSDoc
- [ ] Default values for edge cases
- [ ] Type-safe parameters

---

### 4. Components

Now let's walk through each component...

---

#### 4.1 CaseInfoCard.tsx

**Purpose:** Display case header with key information

**Visual:**
```
┌─────────────────────────────────────────────────────────┐
│ 📄 CASE-001 • John Smith (Acme Corp)                    │
│                                                          │
│   Risk Rating    Jurisdiction    LOB         Due Date   │
│   [High]         Cayman Islands  Banking     12/31/24   │
└─────────────────────────────────────────────────────────┘
```

**Code Structure:**
```typescript
export function CaseInfoCard({
  caseId, client, clientCompany, priority, lob, dueDate, status
}) {
  return (
    <div className="border rounded-lg p-4">
      {/* Case Identification */}
      <FileCheck icon + caseId + client + company />
      
      {/* Metrics */}
      <InfoField label="Risk Rating" badge={priority} />
      <InfoField label="Jurisdiction" value="Cayman Islands" />
      <InfoField label="LOB" value={lob} />
      <InfoField label="Due Date" value={dueDate} />
      <StatusField status={status} />
    </div>
  );
}
```

**Sub-components:**
- `InfoField` - Labeled value display
- `StatusField` - Status with colored dot

**Review Checklist:**
- [ ] All metrics displayed correctly
- [ ] Colors match design system
- [ ] Responsive layout
- [ ] Clear prop naming

---

#### 4.2 SummaryCardsGrid.tsx

**Purpose:** Display grid of 5 summary cards

**Visual:**
```
┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐
│ 👤      │ │ ⚠️      │ │ 📄      │ │ 🛡️      │ │ ✅      │
│ Customer │ │ CRR Risk │ │ Add'l    │ │ Risk     │ │ Risk     │
│ Info     │ │ Factors  │ │ Risk     │ │ Mitigants│ │ Summary  │
│          │ │          │ │          │ │          │ │          │
│ 12 attrs │ │ 9 factors│ │ 7 factors│ │ 4 ctrls  │ │ 3.2 score│
└──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘
```

**Code Structure:**
```typescript
export function SummaryCardsGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
      {SUMMARY_CARDS.map(card => (
        <SummaryCard
          key={card.id}
          icon={card.icon}
          title={card.title}
          subtitle={card.subtitle}
          colors={card.colors}
        />
      ))}
    </div>
  );
}
```

**Benefits:**
- Configuration-driven (easy to add cards)
- Responsive grid
- Consistent styling

**Review Checklist:**
- [ ] All 5 cards render
- [ ] Responsive breakpoints work
- [ ] Colors consistent
- [ ] Icons display correctly

---

#### 4.3 RiskAccordionSection.tsx

**Purpose:** Reusable template for accordion sections

**Visual:**
```
┌─────────────────────────────────────────────────────────┐
│ ▼ 👤 Customer Information                   [Read Only] │ ← Header
├─────────────────────────────────────────────────────────┤
│                                                          │
│              (Section Content Here)                      │ ← Content
│                                                          │
└─────────────────────────────────────────────────────────┘
```

**Code Structure:**
```typescript
export function RiskAccordionSection({
  value,      // Unique ID
  title,      // Display title
  icon,       // Lucide icon
  iconColor,  // Icon color class
  isEditable, // Can user edit?
  children,   // Section content
  forceReadOnly = false
}) {
  const canEdit = isEditable && !forceReadOnly;
  const badge = getEditBadgeConfig(canEdit);

  return (
    <AccordionItem value={value}>
      <AccordionTrigger>
        <Icon color={iconColor} />
        <span className="hover:underline cursor-pointer">
          {title}
        </span>
        <Badge className={badge.className}>
          {badge.text}
        </Badge>
      </AccordionTrigger>
      <AccordionContent>
        {children}
      </AccordionContent>
    </AccordionItem>
  );
}
```

**Benefits:**
- DRY principle (used 5 times)
- Consistent styling
- Edit permission logic centralized

**Review Checklist:**
- [ ] Hover effect works
- [ ] Badge shows correct permission
- [ ] Icon colors correct
- [ ] Content renders properly

---

#### 4.4 CaseDetailView.tsx (Main)

**Purpose:** Orchestrate all components and manage data flow

**Code Structure (Simplified):**
```typescript
export function CaseDetailView(props) {
  // ===== DATA PREPARATION =====
  const normalizedRole = convertUserRole(props.userRole);
  const hasEditPermission = canUserEdit(normalizedRole);
  const caseData = { /* aggregate props */ };

  // ===== EVENT HANDLERS =====
  const handleDataChange = () => {
    console.log('Data changed');
    // TODO: Save to backend
  };

  // ===== RENDER =====
  return (
    <div>
      {/* Navigation */}
      <Button onClick={props.onBack}>
        <ArrowLeft /> Go Back
      </Button>

      {/* Header */}
      <h2>High Risk Summary Tool</h2>
      <p>Comprehensive risk summary...</p>

      {/* Case Info Card */}
      <CaseInfoCard {...props} />

      {/* Summary Cards */}
      <SummaryCardsGrid />

      {/* Accordion Sections */}
      <Accordion>
        {/* 1. Customer Info (read-only) */}
        <RiskAccordionSection
          value="customer-info"
          title="Customer Information"
          icon={User}
          isEditable={hasEditPermission}
          forceReadOnly={true}
        >
          <CustomerInformationSection {...} />
        </RiskAccordionSection>

        {/* 2. CRR Risk Factors (editable) */}
        <RiskAccordionSection
          value="crr-risk"
          title="CRR Risk Factors"
          icon={AlertTriangle}
          isEditable={hasEditPermission}
        >
          <CrrRiskFactorsSection {...} />
        </RiskAccordionSection>

        {/* 3-5. Other sections... */}
      </Accordion>
    </div>
  );
}
```

**Flow Diagram:**
```
Props Input
    ↓
convertUserRole()    ← utils.ts
    ↓
canUserEdit()        ← utils.ts
    ↓
Render Components
    ├─ CaseInfoCard        ← sub-component
    ├─ SummaryCardsGrid    ← sub-component
    └─ RiskAccordionSection × 5  ← reusable template
```

**Review Checklist:**
- [ ] Data preparation is clear
- [ ] Event handlers defined
- [ ] All sections rendered
- [ ] Props passed correctly
- [ ] Comments explain sections

---

## 🧪 Testing Examples

### Unit Test (utils.ts)

```typescript
import { getStatusColor, convertUserRole, canUserEdit } from './utils';

describe('Color Utilities', () => {
  test('getStatusColor with valid status', () => {
    expect(getStatusColor('Assigned')).toBe('bg-blue-100 text-blue-700');
  });

  test('getStatusColor with unknown status', () => {
    expect(getStatusColor('Unknown')).toBe('bg-gray-100 text-gray-700');
  });
});

describe('Role Utilities', () => {
  test('convertUserRole with valid role', () => {
    expect(convertUserRole('HRS Analyst')).toBe('hrs-analyst');
  });

  test('canUserEdit returns false for view-only', () => {
    expect(canUserEdit('view-only')).toBe(false);
  });

  test('canUserEdit returns true for hrs-analyst', () => {
    expect(canUserEdit('hrs-analyst')).toBe(true);
  });
});
```

### Component Test (CaseInfoCard.tsx)

```typescript
import { render, screen } from '@testing-library/react';
import { CaseInfoCard } from './CaseInfoCard';

describe('CaseInfoCard', () => {
  const mockProps = {
    caseId: 'CASE-001',
    client: 'John Smith',
    clientCompany: 'Acme Corp',
    priority: 'High',
    lob: 'Investment Banking',
    dueDate: '2024-12-31',
    status: 'Assigned',
  };

  test('renders case ID', () => {
    render(<CaseInfoCard {...mockProps} />);
    expect(screen.getByText('CASE-001')).toBeInTheDocument();
  });

  test('renders client name', () => {
    render(<CaseInfoCard {...mockProps} />);
    expect(screen.getByText('John Smith')).toBeInTheDocument();
  });

  test('renders priority badge', () => {
    render(<CaseInfoCard {...mockProps} />);
    expect(screen.getByText('High')).toBeInTheDocument();
  });
});
```

### Integration Test (CaseDetailView.tsx)

```typescript
import { render, screen, fireEvent } from '@testing-library/react';
import { CaseDetailView } from './CaseDetailView';

describe('CaseDetailView Integration', () => {
  const mockProps = {
    caseId: 'CASE-001',
    client: 'John Smith',
    clientCompany: 'Acme Corp',
    status: 'Assigned',
    priority: 'High',
    lob: 'Investment Banking',
    dueDate: '2024-12-31',
    onBack: jest.fn(),
    userRole: 'HRS Manager',
  };

  test('renders all main sections', () => {
    render(<CaseDetailView {...mockProps} />);
    
    expect(screen.getByText('High Risk Summary Tool')).toBeInTheDocument();
    expect(screen.getByText('Customer Information')).toBeInTheDocument();
    expect(screen.getByText('CRR Risk Factors')).toBeInTheDocument();
  });

  test('calls onBack when back button clicked', () => {
    render(<CaseDetailView {...mockProps} />);
    
    const backButton = screen.getByText('Go Back to Work Queue');
    fireEvent.click(backButton);
    
    expect(mockProps.onBack).toHaveBeenCalled();
  });

  test('shows editable badge for manager role', () => {
    render(<CaseDetailView {...mockProps} />);
    
    expect(screen.getAllByText('Editable').length).toBeGreaterThan(0);
  });

  test('shows read-only badge for view-only role', () => {
    render(<CaseDetailView {...mockProps} userRole="View Only" />);
    
    expect(screen.getAllByText('Read Only').length).toBe(5);
  });
});
```

---

## 🔍 Code Review Checklist

Use this checklist when reviewing changes to this module:

### General
- [ ] All new files follow the established pattern
- [ ] File names are clear and descriptive
- [ ] Imports are organized (types, utils, components)
- [ ] No unused imports or variables

### Type Safety
- [ ] All functions have TypeScript types
- [ ] Props interfaces defined in types.ts
- [ ] No `any` types without justification
- [ ] Type exports added to index.ts

### Organization
- [ ] New utilities added to utils.ts
- [ ] New constants added to constants.ts
- [ ] New types added to types.ts
- [ ] Exports updated in index.ts

### Documentation
- [ ] JSDoc comments for new functions
- [ ] Complex logic explained
- [ ] README updated if API changed
- [ ] Examples provided for new features

### Testing
- [ ] Unit tests for utility functions
- [ ] Component tests for UI components
- [ ] Integration tests for user flows
- [ ] Edge cases covered

### Consistency
- [ ] Follows naming conventions
- [ ] Uses established patterns
- [ ] Consistent code formatting
- [ ] Tailwind classes match design system

---

## 🎓 Learning Path

### For New Team Members

**Day 1: Understanding**
1. Read this walkthrough
2. Review types.ts (understand data)
3. Review constants.ts (see configuration)
4. Review utils.ts (learn helpers)

**Day 2: Components**
1. Study CaseInfoCard.tsx (simple component)
2. Study SummaryCardsGrid.tsx (config-driven)
3. Study RiskAccordionSection.tsx (reusable template)
4. Study CaseDetailView.tsx (orchestrator)

**Day 3: Practice**
1. Write unit tests for utils.ts
2. Add a new status color
3. Add a new summary card
4. Modify an existing component

### For Code Reviewers

**Quick Review (5 min)**
1. Check file organization
2. Verify types in types.ts
3. Scan for code smells
4. Ensure tests included

**Thorough Review (15 min)**
1. Understand the change purpose
2. Verify logic correctness
3. Check edge cases
4. Review test coverage
5. Ensure documentation updated

---

## 💡 Common Questions

### Q: Where do I add a new status color?
**A:** Add to `STATUS_COLORS` in `constants.ts`

### Q: How do I add a new section?
**A:** Use `<RiskAccordionSection>` template in `CaseDetailView.tsx`

### Q: How do I test utility functions?
**A:** Import from `utils.ts` and write unit tests

### Q: Where is the role conversion logic?
**A:** `convertUserRole()` function in `utils.ts`

### Q: How do I know what props a component needs?
**A:** Check interfaces in `types.ts`

### Q: Can I use these utilities in other components?
**A:** Yes! Import from `./case-detail/utils`

---

## 🚀 Next Steps

After understanding this module:

1. **Explore Related Components**
   - CustomerInformationSection
   - CrrRiskFactorsSection
   - RiskMitigantsSection
   - RiskSummarySection

2. **Try Modifications**
   - Add a new status
   - Create a new utility function
   - Customize a component

3. **Write Tests**
   - Unit tests for utils
   - Component tests for UI
   - Integration tests for flows

4. **Read Documentation**
   - [README.md](./README.md) for usage
   - [ARCHITECTURE.md](./ARCHITECTURE.md) for architecture
   - [REFACTORING_SUMMARY.md](./REFACTORING_SUMMARY.md) for context

---

## 📞 Need Help?

- **Understanding types?** → Read types.ts + comments
- **Color questions?** → Check constants.ts
- **Logic questions?** → Review utils.ts
- **Component questions?** → See component files
- **Architecture questions?** → Read ARCHITECTURE.md

Happy coding! 🎉
