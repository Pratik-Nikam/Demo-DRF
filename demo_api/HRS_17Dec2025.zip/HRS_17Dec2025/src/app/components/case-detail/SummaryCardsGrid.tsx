/**
 * SummaryCardsGrid Component
 * 
 * Displays a grid of summary cards showing high-level overview of each case section.
 * Each card represents a collapsible section with metrics (e.g., number of attributes, factors).
 */

import { Card } from '../ui/card';
import { SUMMARY_CARDS } from './constants';

/**
 * Individual summary card component
 */
function SummaryCard({
  icon: Icon,
  title,
  subtitle,
  bgColor,
  borderColor,
  iconColor,
  textColor,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  subtitle: string;
  bgColor: string;
  borderColor: string;
  iconColor: string;
  textColor: string;
}) {
  return (
    <div className="flex flex-col items-center">
      <Card className={`p-4 ${bgColor} ${borderColor} w-full`}>
        <div className="flex flex-col items-center text-center">
          <Icon className={`h-6 w-6 ${iconColor} mb-2`} />
          <span className={`text-sm ${textColor}`}>{title}</span>
        </div>
      </Card>
      <div className="text-sm text-gray-600 mt-2">{subtitle}</div>
    </div>
  );
}

/**
 * Grid container for all summary cards
 */
export function SummaryCardsGrid() {
  return (
    <div className="mb-6 border rounded-lg p-4 bg-white">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {SUMMARY_CARDS.map((card) => (
          <SummaryCard
            key={card.id}
            icon={card.icon}
            title={card.title}
            subtitle={card.subtitle}
            bgColor={card.bgColor}
            borderColor={card.borderColor}
            iconColor={card.iconColor}
            textColor={card.textColor}
          />
        ))}
      </div>
    </div>
  );
}
