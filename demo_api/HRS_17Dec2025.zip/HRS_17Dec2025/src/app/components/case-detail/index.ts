/**
 * Case Detail Module
 * 
 * Barrel export file for all case detail components and utilities.
 * Provides a clean API for importing case detail functionality.
 * 
 * Usage:
 * ```typescript
 * import { CaseDetailView } from './components/case-detail';
 * ```
 */

// Main component
export { CaseDetailView } from './CaseDetailView';

// Sub-components (for advanced usage)
export { CaseInfoCard } from './CaseInfoCard';
export { SummaryCardsGrid } from './SummaryCardsGrid';
export { RiskAccordionSection } from './RiskAccordionSection';

// Types
export type {
  CaseDetailViewProps,
  CaseData,
  UserRole,
  DisplayUserRole,
  CaseStatus,
  CasePriority,
  SummaryCardConfig,
  AccordionSectionConfig,
} from './types';

// Utilities (for testing or advanced usage)
export {
  getStatusColor,
  getPriorityColor,
  getStatusDotColor,
  convertUserRole,
  canUserEdit,
  getEditBadgeConfig,
} from './utils';

// Constants (for reference or testing)
export {
  STATUS_COLORS,
  PRIORITY_COLORS,
  STATUS_DOT_COLORS,
  SUMMARY_CARDS,
  USER_ROLE_MAP,
} from './constants';
