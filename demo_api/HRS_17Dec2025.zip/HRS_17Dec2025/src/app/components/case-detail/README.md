# Case Detail View Module

## Overview

The Case Detail View module provides a comprehensive, role-based interface for viewing and editing high-risk case information. This module has been refactored into a clean, maintainable architecture with separated concerns.

## Architecture

```
case-detail/
├── types.ts                    # TypeScript type definitions
├── constants.ts                # Configuration and color mappings
├── utils.ts                    # Helper functions
├── CaseDetailView.tsx          # Main component
├── CaseInfoCard.tsx            # Case header card component
├── SummaryCardsGrid.tsx        # Summary cards grid component
├── RiskAccordionSection.tsx    # Reusable accordion section
├── index.ts                    # Barrel exports
└── README.md                   # This file
```

## Component Hierarchy

```
CaseDetailView
├── Navigation (Back Button)
├── Page Header
├── CaseInfoCard
│   ├── Case Identification
│   └── Case Metrics (Risk Rating, Jurisdiction, LOB, Due Date, Status)
├── SummaryCardsGrid
│   ├── Customer Information Card
│   ├── CRR Risk Factors Card
│   ├── Additional Risk Factors Card
│   ├── Risk Mitigants Card
│   └── Risk Summary Card
└── Accordion Sections
    ├── RiskAccordionSection (Customer Information)
    ├── RiskAccordionSection (CRR Risk Factors)
    ├── RiskAccordionSection (Additional Risk Factors)
    ├── RiskAccordionSection (Risk Mitigants)
    └── RiskAccordionSection (Risk Summary)
```

## Usage

### Basic Usage

```typescript
import { CaseDetailView } from './components/case-detail';

function MyComponent() {
  return (
    <CaseDetailView
      caseId="CASE-2024-001"
      client="John Smith"
      clientCompany="Acme Corp"
      status="In Progress"
      priority="High"
      lob="Investment Banking"
      dueDate="2024-12-31"
      onBack={() => console.log('Go back')}
      userRole="HRS Manager"
    />
  );
}
```

### Role-Based Permissions

The component supports four user roles with different permissions:

| Role | Value | Edit Permission |
|------|-------|----------------|
| HRS Analyst | `hrs-analyst` | ✅ Yes |
| HRS Manager | `hrs-manager` | ✅ Yes |
| FLU AML Representative | `flu-aml` | ✅ Yes |
| View Only | `view-only` | ❌ No |

### Section Permissions

| Section | Editable for Permitted Roles |
|---------|------------------------------|
| Customer Information | ❌ Always Read-Only |
| CRR Risk Factors | ✅ Yes |
| Additional Risk Factors | ❌ Always Read-Only |
| Risk Mitigants | ✅ Yes |
| Risk Summary | ✅ Yes |

## File Descriptions

### types.ts

Contains all TypeScript interfaces and type definitions:
- `UserRole`: Normalized user role types
- `CaseData`: Core case data structure
- `CaseDetailViewProps`: Main component props
- `SummaryCardConfig`: Summary card configuration
- `AccordionSectionConfig`: Accordion section configuration

### constants.ts

Contains all constant values and configurations:
- `STATUS_COLORS`: Color mappings for status badges
- `PRIORITY_COLORS`: Color mappings for priority badges
- `STATUS_DOT_COLORS`: Color mappings for status indicators
- `SUMMARY_CARDS`: Configuration for summary cards
- `USER_ROLE_MAP`: User role conversion mapping

### utils.ts

Contains helper functions:
- `getStatusColor()`: Get status badge colors
- `getPriorityColor()`: Get priority badge colors
- `getStatusDotColor()`: Get status indicator dot color
- `convertUserRole()`: Convert display role to internal format
- `canUserEdit()`: Check if user has edit permissions
- `getEditBadgeConfig()`: Get edit badge configuration

### CaseDetailView.tsx

Main component that orchestrates all sub-components. Handles:
- User role conversion
- Permission determination
- Data preparation
- Event handling
- Layout structure

### CaseInfoCard.tsx

Displays the case header with:
- Case ID and client identification
- Risk rating badge
- Jurisdiction, LOB, due date
- Status indicator with colored dot

### SummaryCardsGrid.tsx

Displays a responsive grid of summary cards showing:
- Customer Information (12 attributes)
- CRR Risk Factors (9 factors tracked)
- Additional Risk Factors (7 factors)
- Risk Mitigants (4 controls)
- Risk Summary (3.2 risk score)

### RiskAccordionSection.tsx

Reusable accordion section component with:
- Consistent header styling
- Icon and title display
- Edit permission badge
- Hover effects for interactivity
- Collapsible content area

## Color System

### Status Colors

```typescript
'Assigned'       → bg-blue-100 text-blue-700
'In Progress'    → bg-orange-100 text-orange-700
'Manual Review'  → bg-yellow-100 text-yellow-700
'Retired'        → bg-purple-100 text-purple-700
'Completed'      → bg-green-100 text-green-700
```

### Priority Colors

```typescript
'Low'      → bg-green-100 text-green-700
'Medium'   → bg-orange-100 text-orange-700
'High'     → bg-red-100 text-red-700
'Critical' → bg-red-200 text-red-800
```

### Status Dot Colors

```typescript
'Assigned'       → bg-blue-500
'In Progress'    → bg-orange-500
'Manual Review'  → bg-yellow-500
'Completed'      → bg-green-500
'Retired'        → bg-purple-500
```

## Testing Guidelines

### Unit Testing

```typescript
import { getStatusColor, getPriorityColor, convertUserRole } from './utils';

describe('CaseDetailView Utils', () => {
  test('getStatusColor returns correct color', () => {
    expect(getStatusColor('Assigned')).toBe('bg-blue-100 text-blue-700');
  });

  test('getPriorityColor returns correct color', () => {
    expect(getPriorityColor('High')).toBe('bg-red-100 text-red-700');
  });

  test('convertUserRole converts correctly', () => {
    expect(convertUserRole('HRS Analyst')).toBe('hrs-analyst');
  });
});
```

### Integration Testing

```typescript
import { render, screen } from '@testing-library/react';
import { CaseDetailView } from './CaseDetailView';

describe('CaseDetailView Integration', () => {
  test('renders case information correctly', () => {
    render(
      <CaseDetailView
        caseId="CASE-001"
        client="Test Client"
        clientCompany="Test Corp"
        status="Assigned"
        priority="High"
        lob="Investment Banking"
        dueDate="2024-12-31"
        onBack={() => {}}
        userRole="HRS Manager"
      />
    );

    expect(screen.getByText('CASE-001')).toBeInTheDocument();
    expect(screen.getByText('Test Client')).toBeInTheDocument();
  });
});
```

## Benefits of Refactoring

### ✅ Improved Maintainability
- Each file has a single, clear responsibility
- Easy to locate and modify specific functionality
- Reduced cognitive load when reviewing code

### ✅ Better Testability
- Utility functions can be unit tested independently
- Components can be tested in isolation
- Mock dependencies easily with clear interfaces

### ✅ Enhanced Reusability
- `RiskAccordionSection` can be reused for new sections
- `CaseInfoCard` can be used in other case views
- Utility functions available across the application

### ✅ Type Safety
- Comprehensive TypeScript types in dedicated file
- Improved IDE autocomplete and error detection
- Self-documenting code through types

### ✅ Easier Onboarding
- New developers can understand structure quickly
- Clear separation of concerns
- Comprehensive documentation

### ✅ Scalability
- Easy to add new sections or features
- Consistent patterns for future development
- Modular architecture supports growth

## Future Enhancements

### Potential Improvements

1. **API Integration**: Connect `handleDataChange` to backend
2. **Loading States**: Add loading indicators for async operations
3. **Error Handling**: Implement comprehensive error boundaries
4. **Optimistic Updates**: Update UI before backend confirmation
5. **Audit Trail**: Track and display edit history
6. **Export Functionality**: Add PDF/Excel export capabilities
7. **Search**: Add search within accordion sections
8. **Keyboard Navigation**: Enhance accessibility with keyboard shortcuts

## Contributing

When adding new features:

1. **Add types** in `types.ts`
2. **Add constants** in `constants.ts`
3. **Add utilities** in `utils.ts`
4. **Update components** as needed
5. **Export** from `index.ts`
6. **Document** changes in this README

## Migration Guide

### From Old CaseDetailView

The old `CaseDetailView.tsx` has been preserved as a legacy export for backward compatibility.

#### Before (Old Import)
```typescript
import { CaseDetailView } from './components/CaseDetailView';
```

#### After (New Import)
```typescript
import { CaseDetailView } from './components/case-detail';
```

All props remain the same, so no code changes are required beyond updating imports.

## Support

For questions or issues:
1. Check this README
2. Review inline code comments
3. Examine type definitions in `types.ts`
4. Contact the development team
