/**
 * Type definitions for Case Detail View components
 * 
 * This file contains all TypeScript interfaces and types used across
 * the case detail view and its sub-components.
 */

/**
 * Normalized user role types that determine access permissions
 */
export type UserRole = 'hrs-analyst' | 'hrs-manager' | 'flu-aml' | 'view-only';

/**
 * Display-friendly user role names (as shown in UI)
 */
export type DisplayUserRole = 'HRS Analyst' | 'HRS Manager' | 'FLU AML Representative' | 'View Only';

/**
 * Case status values
 */
export type CaseStatus = 'Assigned' | 'In Progress' | 'Manual Review' | 'Retired' | 'Completed';

/**
 * Case priority levels
 */
export type CasePriority = 'Low' | 'Medium' | 'High' | 'Critical';

/**
 * Core case data structure shared across all sections
 */
export interface CaseData {
  caseId: string;
  client: string;
  clientCompany: string;
  status: string;
  priority: string;
  lob: string;
  dueDate: string;
}

/**
 * Props for the main CaseDetailView component
 */
export interface CaseDetailViewProps {
  caseId: string;
  client: string;
  clientCompany: string;
  status: string;
  priority: string;
  lob: string;
  dueDate: string;
  onBack: () => void;
  userRole?: string;
}

/**
 * Configuration for summary card display
 */
export interface SummaryCardConfig {
  id: string;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  subtitle: string;
  bgColor: string;
  borderColor: string;
  iconColor: string;
  textColor: string;
}

/**
 * Configuration for accordion section
 */
export interface AccordionSectionConfig {
  id: string;
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  iconColor: string;
  isEditable: boolean;
  component: React.ComponentType<any>;
  componentProps?: Record<string, any>;
}
