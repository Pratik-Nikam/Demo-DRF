/**
 * RiskAccordionSection Component
 * 
 * Reusable accordion section component for displaying risk-related information.
 * Provides consistent styling and behavior across all accordion sections.
 */

import { Badge } from '../ui/badge';
import { AccordionItem, AccordionTrigger, AccordionContent } from '../ui/accordion';
import { getEditBadgeConfig } from './utils';

interface RiskAccordionSectionProps {
  /** Unique identifier for the accordion section */
  value: string;
  
  /** Display title of the section */
  title: string;
  
  /** Lucide icon component to display */
  icon: React.ComponentType<{ className?: string }>;
  
  /** Tailwind CSS color classes for the icon */
  iconColor: string;
  
  /** Whether this section can be edited by the current user */
  isEditable: boolean;
  
  /** Content to display when accordion is expanded */
  children: React.ReactNode;
  
  /** Optional: Override edit permission (e.g., Customer Info is always read-only) */
  forceReadOnly?: boolean;
}

/**
 * Reusable accordion section for risk information display
 * 
 * Features:
 * - Consistent header styling with icon, title, and edit badge
 * - Hover effect on title to indicate interactivity
 * - Role-based edit permission display
 * - Collapsible content area
 */
export function RiskAccordionSection({
  value,
  title,
  icon: Icon,
  iconColor,
  isEditable,
  children,
  forceReadOnly = false,
}: RiskAccordionSectionProps) {
  // Determine final edit permission
  const canEdit = isEditable && !forceReadOnly;
  const badgeConfig = getEditBadgeConfig(canEdit);

  return (
    <AccordionItem value={value} className="border rounded-lg px-4">
      <AccordionTrigger className="hover:no-underline">
        <div className="flex items-center gap-3">
          {/* Section Icon */}
          <Icon className={`h-5 w-5 ${iconColor}`} />
          
          {/* Section Title - with hover underline effect */}
          <span className="hover:underline cursor-pointer">{title}</span>
          
          {/* Edit Permission Badge */}
          <Badge variant="secondary" className={badgeConfig.className}>
            {badgeConfig.text}
          </Badge>
        </div>
      </AccordionTrigger>
      
      {/* Section Content */}
      <AccordionContent className="pt-4">
        {children}
      </AccordionContent>
    </AccordionItem>
  );
}
