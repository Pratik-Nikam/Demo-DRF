import { LucideIcon } from 'lucide-react';
import { Card } from './ui/card';

interface SummaryCardProps {
  title: string;
  count: number;
  icon: LucideIcon;
  iconColor: string;
  iconBgColor: string;
  onClick?: () => void;
}

export function SummaryCard({ title, count, icon: Icon, iconColor, iconBgColor, onClick }: SummaryCardProps) {
  return (
    <Card 
      className={`p-4 flex items-start gap-3 ${onClick ? 'cursor-pointer hover:shadow-md transition-shadow' : ''}`}
      onClick={onClick}
    >
      <div className={`p-2 rounded-full ${iconBgColor}`}>
        <Icon className={`h-5 w-5 ${iconColor}`} />
      </div>
      <div className="flex-1">
        <p className="text-gray-600 text-sm">{title}</p>
        <p className="text-2xl mt-1">{count}</p>
      </div>
    </Card>
  );
}