import { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { 
  MoreVertical, 
  ChevronUp, 
  ChevronDown, 
  Calendar, 
  GripVertical,
  UserRound,
  Activity,
  TriangleAlert,
  RefreshCcw,
  CheckCircle,
  CircleAlert,
  CornerUpLeft,
  Filter
} from 'lucide-react';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';

export interface CaseData {
  id: string;
  caseId: string;
  client: string;
  clientCompany: string;
  status: 'Assigned' | 'In Progress' | 'Manual Review' | 'Returned' | 'Completed';
  priority: 'High' | 'Critical' | 'Medium' | 'Low';
  lob: string;
  daysInQueue: number;
  dueDate: string;
}

interface CaseTableProps {
  cases: CaseData[];
  selectedCases: string[];
  onSelectCase: (caseId: string) => void;
  onSelectAll: (selected: boolean) => void;
  onCaseClick: (caseData: CaseData) => void;
}

interface ColumnConfig {
  id: string;
  label: string;
  width: number;
}

const DraggableTableHead = ({ 
  column, 
  index, 
  moveColumn, 
  children,
  onResize
}: { 
  column: ColumnConfig;
  index: number;
  moveColumn: (dragIndex: number, hoverIndex: number) => void;
  children: React.ReactNode;
  onResize: (columnId: string, width: number) => void;
}) => {
  const [{ isDragging }, drag, preview] = useDrag({
    type: 'column',
    item: { index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const [, drop] = useDrop({
    accept: 'column',
    hover: (item: { index: number }) => {
      if (item.index !== index) {
        moveColumn(item.index, index);
        item.index = index;
      }
    },
  });

  const handleMouseDown = (e: React.MouseEvent) => {
    const startX = e.clientX;
    const startWidth = column.width;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const diff = moveEvent.clientX - startX;
      const newWidth = Math.max(80, startWidth + diff);
      onResize(column.id, newWidth);
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  return (
    <th
      ref={(node) => drag(preview(drop(node)))}
      style={{ 
        width: column.width,
        opacity: isDragging ? 0.5 : 1,
        position: 'relative',
        userSelect: 'none',
        cursor: 'move'
      }}
      className="relative bg-white h-14"
    >
      <div className="flex items-center gap-2">
        <GripVertical className="h-4 w-4 text-gray-400" />
        {children}
        <div
          onMouseDown={handleMouseDown}
          className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500"
          style={{ zIndex: 10 }}
        />
      </div>
    </th>
  );
};

function CaseTableInner({ cases, selectedCases, onSelectCase, onSelectAll, onCaseClick }: CaseTableProps) {
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [dueDateFilter, setDueDateFilter] = useState('');
  const [showDatePicker, setShowDatePicker] = useState(false);
  
  // Filter states for each column
  const [filters, setFilters] = useState<Record<string, string>>({});
  
  const [columns, setColumns] = useState<ColumnConfig[]>([
    { id: 'checkbox', label: '', width: 50 },
    { id: 'caseId', label: 'Case ID', width: 150 },
    { id: 'client', label: 'Client', width: 200 },
    { id: 'status', label: 'Status', width: 150 },
    { id: 'priority', label: 'Priority', width: 120 },
    { id: 'lob', label: 'LOB', width: 180 },
    { id: 'daysInQueue', label: 'Days in Queue', width: 140 },
    { id: 'dueDate', label: 'Due Date', width: 180 },
    { id: 'actions', label: 'Actions', width: 100 },
  ]);

  const allSelected = cases.length > 0 && selectedCases.length === cases.length;

  const moveColumn = (dragIndex: number, hoverIndex: number) => {
    const newColumns = [...columns];
    const [removed] = newColumns.splice(dragIndex, 1);
    newColumns.splice(hoverIndex, 0, removed);
    setColumns(newColumns);
  };

  const handleResize = (columnId: string, width: number) => {
    setColumns(prev => prev.map(col => 
      col.id === columnId ? { ...col, width } : col
    ));
  };

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  const SortIcon = ({ column }: { column: string }) => {
    if (sortColumn !== column) {
      return <ChevronDown className="h-4 w-4 text-gray-400" />;
    }
    return sortDirection === 'asc' ? (
      <ChevronUp className="h-4 w-4 text-blue-600" />
    ) : (
      <ChevronDown className="h-4 w-4 text-blue-600" />
    );
  };

  const getStatusColor = (status: CaseData['status']) => {
    const colors = {
      Assigned: 'bg-blue-50 text-blue-700 border-blue-200',
      'In Progress': 'bg-orange-50 text-orange-700 border-orange-200',
      'Manual Review': 'bg-yellow-50 text-yellow-700 border-yellow-200',
      Returned: 'bg-purple-50 text-purple-700 border-purple-200',
      Completed: 'bg-green-50 text-green-700 border-green-200',
    };
    return colors[status];
  };

  const getPriorityColor = (priority: CaseData['priority']) => {
    const colors = {
      High: 'bg-red-50 text-red-700 border-red-200',
      Critical: 'bg-red-50 text-red-700 border-red-200',
      Medium: 'bg-yellow-50 text-yellow-700 border-yellow-200',
      Low: 'bg-green-50 text-green-700 border-green-200',
    };
    return colors[priority];
  };

  const getStatusIcon = (status: CaseData['status']) => {
    const icons = {
      Assigned: <UserRound className="h-3.5 w-3.5" />,
      'In Progress': <Activity className="h-3.5 w-3.5" />,
      'Manual Review': <TriangleAlert className="h-3.5 w-3.5" />,
      Returned: <CornerUpLeft className="h-3.5 w-3.5" />,
      Completed: <CheckCircle className="h-3.5 w-3.5" />,
    };
    return icons[status];
  };

  const getPriorityIcon = (priority: CaseData['priority']) => {
    const icons = {
      High: <TriangleAlert className="h-3.5 w-3.5" />,
      Critical: <TriangleAlert className="h-3.5 w-3.5" />,
      Medium: <CircleAlert className="h-3.5 w-3.5" />,
      Low: <CheckCircle className="h-3.5 w-3.5" />,
    };
    return icons[priority];
  };

  const getDaysColor = (days: number) => {
    if (days >= 10) return 'text-red-600';
    if (days >= 5) return 'text-orange-600';
    return 'text-gray-900';
  };

  // Filter cases based on filter inputs
  const filteredCases = cases.filter((case_) => {
    // Check each filter
    for (const [columnId, filterValue] of Object.entries(filters)) {
      if (!filterValue) continue; // Skip empty filters
      
      const filterLower = filterValue.toLowerCase();
      
      switch (columnId) {
        case 'caseId':
          if (!case_.caseId.toLowerCase().includes(filterLower)) return false;
          break;
        case 'client':
          if (!case_.client.toLowerCase().includes(filterLower) && 
              !case_.clientCompany.toLowerCase().includes(filterLower)) return false;
          break;
        case 'status':
          if (!case_.status.toLowerCase().includes(filterLower)) return false;
          break;
        case 'priority':
          if (!case_.priority.toLowerCase().includes(filterLower)) return false;
          break;
        case 'lob':
          if (!case_.lob.toLowerCase().includes(filterLower)) return false;
          break;
        case 'daysInQueue':
          if (!case_.daysInQueue.toString().includes(filterValue)) return false;
          break;
      }
    }
    
    // Check due date filter - support both formats
    if (dueDateFilter) {
      // Convert case due date (YYYY-MM-DD) to MM/DD/YYYY for comparison
      const caseDateParts = case_.dueDate.split('-');
      const formattedCaseDate = `${caseDateParts[1]}/${caseDateParts[2]}/${caseDateParts[0]}`;
      
      // Check if filter is in YYYY-MM-DD format (from date picker)
      if (dueDateFilter.includes('-')) {
        if (!case_.dueDate.includes(dueDateFilter)) return false;
      } 
      // Check if filter is in MM/DD/YYYY format (from text input)
      else if (!formattedCaseDate.includes(dueDateFilter)) {
        return false;
      }
    }
    
    return true;
  });

  const renderHeaderCell = (column: ColumnConfig, index: number) => {
    if (column.id === 'checkbox') {
      return (
        <th key={column.id} style={{ width: column.width }} className="bg-white h-14 text-left align-middle">
          <div className="flex items-center h-full px-4">
            <Checkbox
              checked={allSelected}
              onCheckedChange={onSelectAll}
            />
          </div>
        </th>
      );
    }

    if (column.id === 'actions') {
      return (
        <DraggableTableHead
          key={column.id}
          column={column}
          index={index}
          moveColumn={moveColumn}
          onResize={handleResize}
        >
          <span>Actions</span>
        </DraggableTableHead>
      );
    }

    return (
      <DraggableTableHead
        key={column.id}
        column={column}
        index={index}
        moveColumn={moveColumn}
        onResize={handleResize}
      >
        <button
          className="flex items-center gap-1 hover:text-gray-900"
          onClick={() => handleSort(column.id)}
        >
          {column.label}
        </button>
      </DraggableTableHead>
    );
  };

  const renderFilterCell = (column: ColumnConfig) => {
    if (column.id === 'checkbox' || column.id === 'actions') {
      return (
        <TableHead key={`filter-${column.id}`} className="h-10 bg-white" style={{ width: column.width }}>
          {/* Empty cell */}
        </TableHead>
      );
    }

    if (column.id === 'dueDate') {
      return (
        <TableHead key={`filter-${column.id}`} className="h-10 bg-white relative" style={{ width: column.width }}>
          <div className="flex items-center gap-1 relative">
            <div className="relative flex-1">
              <Input 
                type="text" 
                placeholder="mm/dd/yyyy" 
                className="h-8 text-xs bg-white border border-gray-300 pr-8"
                value={dueDateFilter ? (() => {
                  // If filter is in YYYY-MM-DD format, convert to MM/DD/YYYY for display
                  if (dueDateFilter.includes('-') && dueDateFilter.split('-').length === 3) {
                    const parts = dueDateFilter.split('-');
                    return `${parts[1]}/${parts[2]}/${parts[0]}`;
                  }
                  return dueDateFilter;
                })() : ''}
                onChange={(e) => setDueDateFilter(e.target.value)}
                onFocus={() => setShowDatePicker(false)}
              />
              <Calendar 
                className="h-3.5 w-3.5 text-gray-400 absolute right-2 top-1/2 -translate-y-1/2 cursor-pointer hover:text-gray-600" 
                onClick={() => setShowDatePicker(!showDatePicker)} 
              />
            </div>
            {showDatePicker && (
              <div className="absolute top-full left-0 mt-1 z-50">
                <input
                  type="date"
                  className="border rounded p-2 bg-white shadow-lg text-sm"
                  onChange={(e) => {
                    setDueDateFilter(e.target.value);
                    setShowDatePicker(false);
                  }}
                  onBlur={() => setTimeout(() => setShowDatePicker(false), 200)}
                  autoFocus
                />
              </div>
            )}
          </div>
        </TableHead>
      );
    }

    const filterValue = filters[column.id] || '';

    return (
      <TableHead key={`filter-${column.id}`} className="h-10 bg-white" style={{ width: column.width }}>
        <div className="flex items-center gap-1">
          <Input 
            type="text" 
            placeholder="" 
            className="h-8 text-xs bg-white border border-gray-300 flex-1"
            value={filterValue}
            onChange={(e) => {
              setFilters({ ...filters, [column.id]: e.target.value });
            }}
          />
        </div>
      </TableHead>
    );
  };

  const renderDataCell = (column: ColumnConfig, case_: CaseData) => {
    const isSelected = selectedCases.includes(case_.id);

    switch (column.id) {
      case 'checkbox':
        return (
          <TableCell key={`${case_.id}-${column.id}`} style={{ width: column.width }}>
            <Checkbox
              checked={isSelected}
              onCheckedChange={() => onSelectCase(case_.id)}
            />
          </TableCell>
        );
      
      case 'caseId':
        return (
          <TableCell key={`${case_.id}-${column.id}`} style={{ width: column.width }}>
            <span className="text-blue-600 hover:underline cursor-pointer" onClick={() => onCaseClick(case_)}>
              {case_.caseId}
            </span>
          </TableCell>
        );
      
      case 'client':
        return (
          <TableCell key={`${case_.id}-${column.id}`} style={{ width: column.width }}>
            <div>
              <div>{case_.client}</div>
              <div className="text-sm text-gray-500">{case_.clientCompany}</div>
            </div>
          </TableCell>
        );
      
      case 'status':
        return (
          <TableCell key={`${case_.id}-${column.id}`} style={{ width: column.width }}>
            <Badge variant="secondary" className={`${getStatusColor(case_.status)} border`}>
              {getStatusIcon(case_.status)}
              {case_.status}
            </Badge>
          </TableCell>
        );
      
      case 'priority':
        return (
          <TableCell key={`${case_.id}-${column.id}`} style={{ width: column.width }}>
            <Badge variant="secondary" className={`${getPriorityColor(case_.priority)} border`}>
              {getPriorityIcon(case_.priority)}
              {case_.priority}
            </Badge>
          </TableCell>
        );
      
      case 'lob':
        return (
          <TableCell key={`${case_.id}-${column.id}`} style={{ width: column.width }}>
            {case_.lob}
          </TableCell>
        );
      
      case 'daysInQueue':
        return (
          <TableCell key={`${case_.id}-${column.id}`} style={{ width: column.width }}>
            <span className={getDaysColor(case_.daysInQueue)}>
              {case_.daysInQueue} days
            </span>
          </TableCell>
        );
      
      case 'dueDate':
        return (
          <TableCell key={`${case_.id}-${column.id}`} style={{ width: column.width }}>
            {case_.dueDate}
          </TableCell>
        );
      
      case 'actions':
        return (
          <TableCell key={`${case_.id}-${column.id}`} style={{ width: column.width }}>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <MoreVertical className="h-4 w-4" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>View Details</DropdownMenuItem>
                <DropdownMenuItem>Edit Case</DropdownMenuItem>
                <DropdownMenuItem>Assign To</DropdownMenuItem>
                <DropdownMenuItem>Export</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </TableCell>
        );
      
      default:
        return <TableCell key={`${case_.id}-${column.id}`} style={{ width: column.width }} />;
    }
  };

  return (
    <div className="border rounded-lg overflow-hidden h-full flex flex-col">
      <div className="overflow-auto flex-1">
        <Table>
          <TableHeader className="sticky top-0 z-10">
            <TableRow className="bg-gray-50">
              {columns.map((column, index) => renderHeaderCell(column, index))}
            </TableRow>
            {/* Filter Row */}
            <TableRow className="bg-white border-b sticky top-[40px] z-10">
              {columns.map((column) => renderFilterCell(column))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredCases.map((case_) => {
              const isSelected = selectedCases.includes(case_.id);
              return (
                <TableRow 
                  key={case_.id} 
                  className={isSelected ? 'bg-blue-50' : ''}
                >
                  {columns.map((column) => renderDataCell(column, case_))}
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

export function CaseTable(props: CaseTableProps) {
  return (
    <DndProvider backend={HTML5Backend}>
      <CaseTableInner {...props} />
    </DndProvider>
  );
}