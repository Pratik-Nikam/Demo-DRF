import { useMemo, useCallback, useRef } from 'react';
import { AgGridReact } from 'ag-grid-react';
import type { ColDef, ICellRendererParams, GridReadyEvent, GridApi } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import {
  MoreVertical,
  UserRound,
  Activity,
  TriangleAlert,
  CornerUpLeft,
  CheckCircle,
  CircleAlert,
} from 'lucide-react';
import { AGGridWrapper } from './ag-grid-wrapper';
import { getAGGridIconsConfig } from './ag-grid-icons';

export interface CaseData {
  id: string;
  caseId: string;
  client: string;
  clientCompany: string;
  status: 'Assigned' | 'In Progress' | 'Manual Review' | 'Return' | 'Completed';
  priority: 'High' | 'Critical' | 'Medium' | 'Low';
  lob: string;
  daysInQueue: number;
  dueDate: string;
}

interface AGGridCaseTableProps {
  cases: CaseData[];
  selectedCases: string[];
  onSelectCase: (caseId: string) => void;
  onSelectAll: (selected: boolean) => void;
  onCaseClick: (caseData: CaseData) => void;
}

// Status cell renderer
const StatusCellRenderer = (props: ICellRendererParams<CaseData>) => {
  const status = props.value as CaseData['status'];
  
  const getStatusColor = (status: CaseData['status']) => {
    const colors = {
      Assigned: 'bg-blue-50 text-blue-700 border-blue-200',
      'In Progress': 'bg-orange-50 text-orange-700 border-orange-200',
      'Manual Review': 'bg-yellow-50 text-yellow-700 border-yellow-200',
      Return: 'bg-purple-50 text-purple-700 border-purple-200',
      Completed: 'bg-green-50 text-green-700 border-green-200',
    };
    return colors[status];
  };

  const getStatusIcon = (status: CaseData['status']) => {
    const icons = {
      Assigned: <UserRound className="h-3.5 w-3.5" />,
      'In Progress': <Activity className="h-3.5 w-3.5" />,
      'Manual Review': <TriangleAlert className="h-3.5 w-3.5" />,
      Return: <CornerUpLeft className="h-3.5 w-3.5" />,
      Completed: <CheckCircle className="h-3.5 w-3.5" />,
    };
    return icons[status];
  };

  return (
    <Badge variant="secondary" className={`${getStatusColor(status)} border`}>
      {getStatusIcon(status)}
      {status}
    </Badge>
  );
};

// Priority cell renderer
const PriorityCellRenderer = (props: ICellRendererParams<CaseData>) => {
  const priority = props.value as CaseData['priority'];
  
  const getPriorityColor = (priority: CaseData['priority']) => {
    const colors = {
      High: 'bg-red-50 text-red-700 border-red-200',
      Critical: 'bg-red-50 text-red-700 border-red-200',
      Medium: 'bg-yellow-50 text-yellow-700 border-yellow-200',
      Low: 'bg-green-50 text-green-700 border-green-200',
    };
    return colors[priority];
  };

  const getPriorityIcon = (priority: CaseData['priority']) => {
    const icons = {
      High: <TriangleAlert className="h-3.5 w-3.5" />,
      Critical: <TriangleAlert className="h-3.5 w-3.5" />,
      Medium: <CircleAlert className="h-3.5 w-3.5" />,
      Low: <CheckCircle className="h-3.5 w-3.5" />,
    };
    return icons[priority];
  };

  return (
    <Badge variant="secondary" className={`${getPriorityColor(priority)} border`}>
      {getPriorityIcon(priority)}
      {priority}
    </Badge>
  );
};

// Case ID cell renderer with click handler
const CaseIdCellRenderer = (props: ICellRendererParams<CaseData>) => {
  const handleClick = () => {
    if (props.data) {
      (props as any).context.onCaseClick(props.data);
    }
  };

  return (
    <span 
      className="text-blue-600 hover:underline cursor-pointer"
      onClick={handleClick}
    >
      {props.value}
    </span>
  );
};

// Client cell renderer with company
const ClientCellRenderer = (props: ICellRendererParams<CaseData>) => {
  return (
    <div>
      <div>{props.value}</div>
      <div className="text-sm text-gray-500">{props.data?.clientCompany}</div>
    </div>
  );
};

// Days in queue cell renderer with color coding
const DaysInQueueCellRenderer = (props: ICellRendererParams<CaseData>) => {
  const days = props.value as number;
  
  const getDaysColor = (days: number) => {
    if (days >= 10) return 'text-red-600 font-semibold';
    if (days >= 5) return 'text-orange-600 font-semibold';
    return 'text-gray-900';
  };

  return (
    <span className={getDaysColor(days)}>
      {days} days
    </span>
  );
};

// Actions cell renderer
const ActionsCellRenderer = (props: ICellRendererParams<CaseData>) => {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
          <MoreVertical className="h-4 w-4" />
          <span className="sr-only">Open menu</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem>View Details</DropdownMenuItem>
        <DropdownMenuItem>Edit Case</DropdownMenuItem>
        <DropdownMenuItem>Assign To</DropdownMenuItem>
        <DropdownMenuItem>Export</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export function AGGridCaseTable({
  cases,
  selectedCases,
  onSelectCase,
  onSelectAll,
  onCaseClick,
}: AGGridCaseTableProps) {
  const gridRef = useRef<AgGridReact>(null);
  const gridApiRef = useRef<GridApi | null>(null);

  // Column definitions
  const columnDefs = useMemo<ColDef<CaseData>[]>(() => [
    {
      field: 'id',
      headerName: '',
      checkboxSelection: true,
      headerCheckboxSelection: true,
      width: 50,
      minWidth: 50,
      maxWidth: 50,
      resizable: false,
      filter: false,
      sortable: false,
      pinned: 'left',
      lockPosition: true,
      suppressMovable: true,
    },
    {
      field: 'caseId',
      headerName: 'Case ID',
      width: 150,
      cellRenderer: CaseIdCellRenderer,
      filter: 'agTextColumnFilter',
      floatingFilter: true,
    },
    {
      field: 'client',
      headerName: 'Client',
      width: 200,
      cellRenderer: ClientCellRenderer,
      filter: 'agTextColumnFilter',
      floatingFilter: true,
      valueGetter: (params) => {
        // For filtering, combine client and company
        return `${params.data?.client} ${params.data?.clientCompany}`;
      },
    },
    {
      field: 'status',
      headerName: 'Status',
      width: 150,
      cellRenderer: StatusCellRenderer,
      filter: 'agTextColumnFilter',
      floatingFilter: true,
    },
    {
      field: 'priority',
      headerName: 'Priority',
      width: 120,
      cellRenderer: PriorityCellRenderer,
      filter: 'agTextColumnFilter',
      floatingFilter: true,
    },
    {
      field: 'lob',
      headerName: 'LOB',
      width: 180,
      filter: 'agTextColumnFilter',
      floatingFilter: true,
    },
    {
      field: 'daysInQueue',
      headerName: 'Days in Queue',
      width: 140,
      cellRenderer: DaysInQueueCellRenderer,
      filter: 'agNumberColumnFilter',
      floatingFilter: true,
      comparator: (valueA, valueB) => valueA - valueB,
    },
    {
      field: 'dueDate',
      headerName: 'Due Date',
      width: 180,
      filter: 'agDateColumnFilter',
      floatingFilter: true,
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 100,
      cellRenderer: ActionsCellRenderer,
      filter: false,
      sortable: false,
      resizable: false,
      suppressMovable: true,
    },
  ], []);

  // Default column definition
  const defaultColDef = useMemo<ColDef>(() => ({
    sortable: true,
    resizable: true,
    filter: true,
    floatingFilter: true,
    suppressMovable: false, // Allow column reordering
  }), []);

  // Handle grid ready
  const onGridReady = useCallback((params: GridReadyEvent) => {
    gridApiRef.current = params.api;
  }, []);

  // Handle row selection
  const onSelectionChanged = useCallback(() => {
    if (!gridApiRef.current) return;
    
    const selectedRows = gridApiRef.current.getSelectedRows();
    const selectedIds = selectedRows.map(row => row.id);
    
    // Check if all rows are selected
    if (selectedIds.length === cases.length && cases.length > 0) {
      onSelectAll(true);
    } else if (selectedIds.length === 0) {
      onSelectAll(false);
    } else {
      // Handle individual selections
      selectedIds.forEach(id => {
        if (!selectedCases.includes(id)) {
          onSelectCase(id);
        }
      });
    }
  }, [cases.length, selectedCases, onSelectCase, onSelectAll]);

  // Row class rules for highlighting selected rows
  const rowClassRules = useMemo(() => ({
    'ag-row-selected': (params: any) => {
      return selectedCases.includes(params.data?.id);
    },
  }), [selectedCases]);

  // Context for cell renderers
  const context = useMemo(() => ({
    onCaseClick,
  }), [onCaseClick]);

  return (
    <AGGridWrapper>
      <div 
        className="ag-theme-alpine border rounded-lg overflow-hidden w-full h-full min-h-[600px]" 
        style={{ width: '100%', height: '100%' }}
      >
        <AgGridReact<CaseData>
          ref={gridRef}
          rowData={cases}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          rowSelection="multiple"
          suppressRowClickSelection={true}
          onGridReady={onGridReady}
          onSelectionChanged={onSelectionChanged}
          rowClassRules={rowClassRules}
          context={context}
          enableCellTextSelection={true}
          ensureDomOrder={true}
          animateRows={true}
          pagination={true}
          paginationPageSize={20}
          paginationPageSizeSelector={[10, 20, 50, 100]}
          icons={getAGGridIconsConfig().iconMap}
          headerHeight={40}
          floatingFiltersHeight={40}
          rowHeight={60}
          domLayout="normal"
        />
      </div>
    </AGGridWrapper>
  );
}