// Workbasket filter types and helper functions

export type WorkbasketFilter = 
  | 'all' 
  | 'active' 
  | 'escalations' 
  | 'completed' 
  | 'returned'
  | 'my-cases'
  | 'assigned'
  | 'in-progress'
  | 'manual-review';

export interface WorkItem {
  caseId: string;
  clientId?: string;
  clientName?: string;
  clientType?: string;
  assignedAnalyst?: string;
  status?: string;
  priority?: string;
  lob?: string;
  daysInQueue?: number;
  dueDate?: string;
  completedDate?: string | null;
  escalationReason?: string | null;
  manualReviewReasons?: string[] | null;
}

/**
 * Helper function to determine if a case matches the widget filter
 */
export function matchesWidgetFilter(caseRecord: WorkItem, filter: WorkbasketFilter): boolean {
  switch (filter) {
    case 'all':
      return true;
    
    case 'active':
      return caseRecord.status === 'in-progress' || caseRecord.status === 'manual-review';
    
    case 'escalations':
      return (
        (caseRecord.priority === 'high' || caseRecord.priority === 'critical') && 
        (caseRecord.status === 'assigned' || caseRecord.status === 'manual-review')
      );
    
    case 'completed':
      return caseRecord.status === 'completed';
    
    case 'returned':
      return caseRecord.status === 'returned';
    
    case 'my-cases':
      // Filter for cases assigned to current user - this is handled by backend
      return true;
    
    case 'assigned':
      return caseRecord.status === 'assigned';
    
    case 'in-progress':
      return caseRecord.status === 'in-progress';
    
    case 'manual-review':
      return caseRecord.status === 'manual-review';
    
    default:
      return true;
  }
}

/**
 * Get the display label for a filter
 */
export function getFilterLabel(filter: WorkbasketFilter): string {
  switch (filter) {
    case 'all':
      return 'All Cases';
    case 'active':
      return 'Active Cases';
    case 'escalations':
      return 'Pending Escalations';
    case 'completed':
      return 'Completed';
    case 'returned':
      return 'Returned Cases';
    case 'my-cases':
      return 'My Cases';
    case 'assigned':
      return 'Assigned';
    case 'in-progress':
      return 'In Progress';
    case 'manual-review':
      return 'Manual Review';
    default:
      return 'All Cases';
  }
}

/**
 * Get the count of cases matching a filter
 */
export function getFilterCount(cases: WorkItem[], filter: WorkbasketFilter): number {
  return cases.filter(c => matchesWidgetFilter(c, filter)).length;
}
