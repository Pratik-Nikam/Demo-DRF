import { useState, useMemo, useCallback, useEffect } from "react";
import { AgGridReact } from "ag-grid-react@32.2.2";
import type { ColDef, GridApi, GridReadyEvent } from "ag-grid-community@32.2.2";
import { getAGGridIconsConfig } from "./ag-grid-icons";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { BulkOperationsDialog } from "./bulk-operations-dialog";
import { 
  Search, 
  Filter, 
  Eye, 
  Edit, 
  RotateCcw,
  Download,
  AlertTriangle,
  CheckCircle,
  Clock,
  User,
  Building,
  Calendar,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  MoreVertical,
  Pin,
  PinOff,
  ScanLine,
  Settings,
  UserCheck,
  ArrowUpCircle,
  Activity,
  UserPlus,
  PlayCircle,
  ArrowRight,
  Shield,
  UsersRound
} from "lucide-react";
import { toast } from "sonner@2.0.3";
import { matchesWidgetFilter, WorkbasketFilter } from "./workbasket-data";

// AG-Grid styles are imported globally in globals.css

interface MyWorkbasketTableProps {
  userRole: 'hra-analyst' | 'hra-manager' | 'flu-aml' | 'gfc' | 'view-only' | 'hrs-analyst' | 'hrs-manager';
  currentUser: string; // now a username/ID string that will be sent as X-User-Id
  widgetFilter?: WorkbasketFilter;
}

interface WorkItem {
  caseId: string;
  clientId?: string;
  clientName?: string;
  clientType?: string;
  assignedAnalyst?: string;
  status?: string;
  priority?: string;
  lob?: string;
  daysInQueue?: number;
  dueDate?: string;
  completedDate?: string | null;
  escalationReason?: string | null;
  manualReviewReasons?: string[] | null;
  // etc.
}

// Custom cell renderers
const StatusCellRenderer = (params: any) => {
  const status = params.value;
  const getStatusStyle = () => {
    switch (status) {
      case 'assigned':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'in-progress':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'returned':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'manual-review':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'escalated':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'assigned':
        return <UserCheck className="h-3 w-3" />;
      case 'in-progress':
        return <Activity className="h-3 w-3" />;
      case 'returned':
        return <RotateCcw className="h-3 w-3" />;
      case 'manual-review':
        return <AlertTriangle className="h-3 w-3" />;
      case 'completed':
        return <CheckCircle className="h-3 w-3" />;
      case 'escalated':
        return <ArrowUpCircle className="h-3 w-3" />;
      default:
        return <Clock className="h-3 w-3" />;
    }
  };

  return (
    <Badge variant="outline" className={`${getStatusStyle()} capitalize flex items-center space-x-1`}>
      {getStatusIcon()}
      <span>{status.replace('-', ' ')}</span>
    </Badge>
  );
};

const PriorityCellRenderer = (params: any) => {
  const priority = params.value;
  const getPriorityIcon = () => {
    switch (priority) {
      case 'critical':
        return <AlertTriangle className="h-3 w-3 text-red-600" />;
      case 'high':
        return <AlertTriangle className="h-3 w-3 text-orange-600" />;
      case 'medium':
        return <Clock className="h-3 w-3 text-yellow-600" />;
      case 'low':
        return <CheckCircle className="h-3 w-3 text-green-600" />;
      default:
        return null;
    }
  };

  const getPriorityStyle = () => {
    switch (priority) {
      case 'critical':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="flex items-center space-x-1">
      {getPriorityIcon()}
      <Badge variant="outline" className={`${getPriorityStyle()} capitalize`}>
        {priority}
      </Badge>
    </div>
  );
};


// Custom Header Component with Menu
const CustomHeaderComponent = (params: any) => {
  const [menuOpen, setMenuOpen] = useState(false);
  
  const onSortAscending = () => {
    params.setSort('asc');
    setMenuOpen(false);
  };

  const onSortDescending = () => {
    params.setSort('desc');
    setMenuOpen(false);
  };

  const onPinColumn = () => {
    const pinned = params.column.getPinned();
    if (pinned) {
      params.api.setColumnsPinned([params.column], null);
    } else {
      params.api.setColumnsPinned([params.column], 'left');
    }
    setMenuOpen(false);
  };

  const onAutoSizeColumn = () => {
    params.api.autoSizeColumns([params.column]);
    setMenuOpen(false);
  };

  const onAutoSizeAllColumns = () => {
    params.api.autoSizeAllColumns();
    setMenuOpen(false);
  };

  const onHideColumn = () => {
    params.api.setColumnsVisible([params.column], false);
    setMenuOpen(false);
  };

  return (
    <div className="flex items-center justify-between w-full">
      <div className="flex items-center space-x-1">
        <span>{params.displayName}</span>
        {params.column.isSortAscending() && <ArrowUp className="h-3 w-3" />}
        {params.column.isSortDescending() && <ArrowDown className="h-3 w-3" />}
        {params.column.getPinned() && <Pin className="h-3 w-3 text-muted-foreground" />}
      </div>
      
      <DropdownMenu open={menuOpen} onOpenChange={setMenuOpen}>
        <DropdownMenuTrigger asChild>
          <button 
            className="h-6 w-6 p-0 ml-1 hover:bg-muted rounded flex items-center justify-center bg-transparent border-0 cursor-pointer"
            onClick={(e) => {
              e.stopPropagation();
              setMenuOpen(!menuOpen);
            }}
          >
            <MoreVertical className="h-3 w-3" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-56">
          {params.column.getColDef().sortable !== false && (
            <>
              <DropdownMenuItem onClick={onSortAscending}>
                <ArrowUp className="h-4 w-4 mr-2" />
                Sort Ascending
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onSortDescending}>
                <ArrowDown className="h-4 w-4 mr-2" />
                Sort Descending
              </DropdownMenuItem>
              <DropdownMenuSeparator />
            </>
          )}
          <DropdownMenuItem onClick={onPinColumn}>
            <Pin className="h-4 w-4 mr-2" />
            {params.column.getPinned() ? 'Unpin Column' : 'Pin Column'}
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={onAutoSizeColumn}>
            <ScanLine className="h-4 w-4 mr-2" />
            Autosize This Column
          </DropdownMenuItem>
          <DropdownMenuItem onClick={onAutoSizeAllColumns}>
            <ScanLine className="h-4 w-4 mr-2" />
            Autosize All Columns
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={onHideColumn}>
            <Eye className="h-4 w-4 mr-2" />
            Hide Column
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};

// Actions cell renderer for personal workbasket functionality
const ActionsCellRenderer: React.FC<any> = (props) => {
  const params = props;
  const [assignmentDialogOpen, setAssignmentDialogOpen] = useState(false);
  const [assignmentType, setAssignmentType] = useState<'escalate' | 'complete' | 'return'>('escalate');
  const [targetUser, setTargetUser] = useState("");
  const [assignmentReason, setAssignmentReason] = useState("");
  
  // Enhanced escalation state
  const [disposition, setDisposition] = useState("");
  const [selectedEscalationReasons, setSelectedEscalationReasons] = useState<string[]>([]);
  const [escalationType, setEscalationType] = useState<'flu-aml' | 'gfc' | 'manager' | 'cancellation'>('flu-aml');
  const [escalationNotes, setEscalationNotes] = useState("");
  const [submittingAction, setSubmittingAction] = useState(false);
  
  // Get user role from params (passed from parent)
  const userRole = params.context?.userRole || 'hra-analyst';
  const record = params.data;
  
  // Escalation reasons
  const escalationReasons = [
    { id: 'gfc_intelligence', label: 'GFC Intelligence flagged', description: 'Global Financial Crimes intelligence indicates concern', requiresManager: true, targetRole: 'gfc' },
    { id: 'risk_drivers_high', label: 'Risk drivers >10', description: 'Total risk CRR drivers exceeds threshold', requiresManager: true, targetRole: 'flu-aml' },
    { id: 'new_risk_factors', label: 'New risk factors ≥5', description: 'Five or more new risk factors since last refresh', requiresManager: true, targetRole: 'flu-aml' },
    { id: 'trms_referral', label: 'TRMS referral required', description: 'Transaction Risk Management System referral needed', requiresManager: true, targetRole: 'flu-aml' },
    { id: 'client_escalation', label: 'Client Escalation Committee', description: 'Case requires client escalation committee review', requiresManager: true, targetRole: 'gfc' },
    { id: 'beneficial_ownership', label: 'Beneficial ownership changes', description: 'Significant changes in beneficial ownership structure', requiresManager: false, targetRole: 'flu-aml' },
    { id: 'address_change', label: 'Address changes', description: 'Significant address or location changes', requiresManager: false, targetRole: 'flu-aml' },
    { id: 'naics_change', label: 'Nature of Business changes', description: 'Changes in business nature or industry classification', requiresManager: false, targetRole: 'flu-aml' },
    { id: 'income_source', label: 'Source of Income changes', description: 'Changes in source of income for individual clients', requiresManager: false, targetRole: 'flu-aml' },
    { id: 'incomplete_info', label: 'Required information incomplete', description: 'Missing required data elements', requiresManager: false, targetRole: 'hra-manager' },
    { id: 'cancellation', label: 'Client cancellation required', description: 'Case requires client relationship cancellation', requiresManager: true, targetRole: 'hra-manager' }
  ];
  
  // Available managers for analyst escalations
  const availableManagers = [
    { id: 'manager1', name: 'David Kim', role: 'HRA Manager', lob: 'All LOBs' },
    { id: 'manager2', name: 'Lisa Chen', role: 'HRA Manager', lob: 'Investment Banking' },
    { id: 'manager3', name: 'Robert Taylor', role: 'HRA Manager', lob: 'Wealth Management' }
  ];

  // Helper functions for escalation
  const getRelevantEscalationReasons = () => {
    return escalationReasons.filter(reason => {
      if (escalationType === 'flu-aml') return reason.targetRole === 'flu-aml';
      if (escalationType === 'gfc') return reason.targetRole === 'gfc';
      if (escalationType === 'manager') return reason.targetRole === 'hra-manager';
      return true;
    });
  };

  const toggleEscalationReason = (reasonId: string) => {
    setSelectedEscalationReasons(prev => 
      prev.includes(reasonId) ? 
      prev.filter(id => id !== reasonId) : 
      [...prev, reasonId]
    );
  };

  const resetEscalationForm = () => {
    setAssignmentDialogOpen(false);
    setTargetUser("");
    setAssignmentReason("");
    setDisposition("");
    setSelectedEscalationReasons([]);
    setEscalationType('flu-aml');
    setEscalationNotes("");
  };

  const handleAction = async () => {
    if (assignmentType === 'return') {
      if (!assignmentReason.trim()) {
        toast.error("Please provide a reason for returning the case");
        return;
      }

      setSubmittingAction(true);
      try {
        const res = await fetch('/api/v1/workflows/return', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-User-Id': params.context?.currentUser ?? ''
          },
          body: JSON.stringify({
            caseId: record.caseId,
            comments: assignmentReason
          }),
          credentials: 'same-origin'
        });

        if (!res.ok) {
          const txt = await res.text().catch(() => res.statusText);
          throw new Error(`Server responded ${res.status}: ${txt}`);
        }

        const wrapper = await res.json();
        const data = wrapper?.data ?? wrapper;
        const message = data?.message ?? 'Case returned';
        toast.success(message);

        // trigger parent refresh
        params.context?.triggerRefresh?.();
        resetEscalationForm();
      } catch (err: any) {
        console.error('Return failed', err);
        toast.error('Unable to return case: ' + (err?.message ?? 'Unknown error'));
      } finally {
        setSubmittingAction(false);
      }

      return;
    } else if (assignmentType === 'complete') {
      toast.success(`Case ${record.caseId} completed successfully`);
      resetEscalationForm();
      return;
    } else if (assignmentType === 'escalate') {
      if (disposition === 'escalate_flu' || disposition === 'escalate_gfc') {
        if (selectedEscalationReasons.length === 0) {
          toast.error("Please select at least one escalation reason");
          return;
        }
        if (!targetUser && userRole === 'hra-analyst') {
          toast.error("Please select a manager to route the escalation through");
          return;
        }
      }

      // Build escalateTo value:
      // - If routed via manager, escalateTo = manager id (targetUser)
      // - Otherwise use escalationType token (e.g. 'flu-aml' or 'gfc')
      const escalateTo = (escalationType === 'manager' && targetUser) ? targetUser : escalationType;

      const payload = {
        caseId: record.caseId,
        escalateTo,
        disposition,
        escalationType,
        escalationReasons: selectedEscalationReasons,
        notes: escalationNotes
      };

      setSubmittingAction(true);
      try {
        const res = await fetch('/api/v1/workflows/escalate', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-User-Id': params.context?.currentUser ?? ''
          },
          body: JSON.stringify(payload),
          credentials: 'same-origin'
        });

        if (!res.ok) {
          const txt = await res.text().catch(() => res.statusText);
          throw new Error(`Server responded ${res.status}: ${txt}`);
        }

        const wrapper = await res.json();
        const data = wrapper?.data ?? wrapper;
        const message = data?.message ?? 'Escalation submitted';
        toast.success(message);
        // If backend returns updated case info, could handle it here. Trigger a refresh on success.
        params.context?.triggerRefresh?.();
        resetEscalationForm();
      } catch (err: any) {
        console.error('Escalation failed', err);
        toast.error('Unable to escalate case: ' + (err?.message ?? 'Unknown error'));
      } finally {
        setSubmittingAction(false);
      }
    }
  };

  const openActionDialog = (type: 'escalate' | 'complete' | 'return') => {
    setAssignmentType(type);
    setAssignmentDialogOpen(true);
  };

  const getAvailableActions = () => {
    const actions = [];
    
    // Always show view details
    actions.push(
      <DropdownMenuItem key="view" onClick={() => toast.info("View Details clicked")}>
        <Eye className="h-4 w-4 mr-2" />
        View Details
      </DropdownMenuItem>
    );

    // Edit case - available for assigned and in-progress cases
    if (record.status === 'assigned' || record.status === 'in-progress') {
      actions.push(
        <DropdownMenuItem key="edit" onClick={() => toast.info("Edit Case clicked")}>
          <Edit className="h-4 w-4 mr-2" />
          Edit Case
        </DropdownMenuItem>
      );
    }

    // Case-specific actions based on status and user role
    if (userRole === 'hra-analyst') {
      if (record.status === 'assigned' || record.status === 'in-progress') {
        actions.push(
          <DropdownMenuItem key="escalate" onClick={() => openActionDialog('escalate')}>
            <ArrowUpCircle className="h-4 w-4 mr-2" />
            Escalate Case
          </DropdownMenuItem>
        );
        
        if (record.status === 'in-progress') {
          actions.push(
            <DropdownMenuItem key="complete" onClick={() => openActionDialog('complete')}>
              <CheckCircle className="h-4 w-4 mr-2" />
              Complete Case
            </DropdownMenuItem>
          );
        }
      }
    } else if (userRole === 'hra-manager' || userRole === 'flu-aml' || userRole === 'gfc') {
      if (record.status === 'assigned' || record.status === 'in-progress') {
        actions.push(
          <DropdownMenuItem key="return" onClick={() => openActionDialog('return')}>
            <RotateCcw className="h-4 w-4 mr-2" />
            Return Case
          </DropdownMenuItem>
        );
      }
    }

    return actions;
  };

  // Get primary action based on role and case status
  const getPrimaryAction = () => {
    // View Only users cannot perform actions
    if (userRole === 'view-only') {
      return null;
    }
    
    if (userRole === 'hrs-analyst' && (record.status === 'assigned' || record.status === 'in-progress')) {
      return (
        <Button 
          variant="outline" 
          size="sm" 
          className="h-7 px-2 text-xs"
          onClick={() => openActionDialog('escalate')}
        >
          <ArrowUpCircle className="h-3 w-3 mr-1" />
          Escalate
        </Button>
      );
    } else if ((userRole === 'hrs-manager' || userRole === 'flu-aml') && 
               (record.status === 'assigned' || record.status === 'in-progress')) {
      return (
        <Button 
          variant="outline" 
          size="sm" 
          className="h-7 px-2 text-xs"
          onClick={() => openActionDialog('return')}
        >
          <RotateCcw className="h-3 w-3 mr-1" />
          Return
        </Button>
      );
    }
    
    return null;
  };

  return (
    <div className="flex items-center space-x-1">
      {/* Primary Action Button */}
      {getPrimaryAction()}

      {/* More Actions Dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-7 w-7 p-0"
          >
            <MoreVertical className="h-3 w-3" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48" sideOffset={5}>
          {getAvailableActions().map((action, index) => (
            <div key={index}>
              {action}
              {index === 1 && <DropdownMenuSeparator />}
            </div>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      <Dialog open={assignmentDialogOpen} onOpenChange={setAssignmentDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {assignmentType === 'escalate' ? 'Case Disposition & Escalation' : 
               assignmentType === 'complete' ? 'Complete Case' : 'Return Case'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Case Information */}
            <div className="p-4 bg-muted/50 rounded-lg">
              <h4 className="font-medium mb-2">Case Details</h4>
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  {record.clientType === 'Individual' ? 
                    <User className="h-4 w-4 text-primary" /> : 
                    <Building className="h-4 w-4 text-primary" />
                  }
                </div>
                <div>
                  <p className="font-medium">{record.caseId}</p>
                  <p className="text-sm text-muted-foreground">{record.clientName}</p>
                  <p className="text-xs text-muted-foreground">
                    Status: {record.status} • Priority: {record.priority}
                  </p>
                </div>
              </div>
            </div>

            {/* Enhanced escalation flow for analysts */}
            {assignmentType === 'escalate' && userRole === 'hra-analyst' ? (
              <>
                <div>
                  <Label htmlFor="disposition">Case Disposition</Label>
                  <Select value={disposition} onValueChange={setDisposition}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select disposition" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="no_factors">No factors impacting decision to retain client</SelectItem>
                      <SelectItem value="escalate_flu">Escalate to FLU AML Representative</SelectItem>
                      <SelectItem value="escalate_gfc">Escalate to GFC</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {(disposition === 'escalate_flu' || disposition === 'escalate_gfc') && (
                  <>
                    <div>
                      <Label htmlFor="escalation-type">Escalation Type</Label>
                      <Select value={escalationType} onValueChange={(value: any) => setEscalationType(value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="flu-aml">FLU AML Representative</SelectItem>
                          <SelectItem value="gfc">GFC Representative</SelectItem>
                          <SelectItem value="manager">Manager Review</SelectItem>
                          <SelectItem value="cancellation">Client Cancellation</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Escalation Reasons</Label>
                      <div className="grid grid-cols-1 gap-2 mt-2 max-h-48 overflow-y-auto">
                        {getRelevantEscalationReasons().map((reason) => (
                          <div key={reason.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                            <input
                              type="checkbox"
                              id={reason.id}
                              checked={selectedEscalationReasons.includes(reason.id)}
                              onChange={() => toggleEscalationReason(reason.id)}
                              className="mt-1"
                            />
                            <div className="flex-1">
                              <Label htmlFor={reason.id} className="font-medium cursor-pointer text-sm">
                                {reason.label}
                              </Label>
                              <p className="text-xs text-muted-foreground mt-1">
                                {reason.description}
                              </p>
                              {reason.requiresManager && (
                                <Badge variant="outline" className="text-xs mt-1">
                                  Requires Manager Approval
                                </Badge>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="target-manager">Route to Manager</Label>
                      <Select value={targetUser} onValueChange={setTargetUser}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select HRA Manager" />
                        </SelectTrigger>
                        <SelectContent>
                          {availableManagers.map((manager) => (
                            <SelectItem key={manager.id} value={manager.id}>
                              {manager.name} - {manager.lob}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground mt-1">
                        Case will be routed to manager for approval before {escalationType === 'flu-aml' ? 'FLU AML' : 'GFC'} escalation
                      </p>
                    </div>
                  </>
                )}

                <div>
                  <Label htmlFor="escalation-notes">Notes</Label>
                  <Textarea
                    id="escalation-notes"
                    placeholder="Add any relevant notes for the escalation..."
                    value={escalationNotes}
                    onChange={(e) => setEscalationNotes(e.target.value)}
                    rows={3}
                  />
                </div>
              </>
            ) : assignmentType === 'return' ? (
              <div>
                <Label htmlFor="return-reason">Return Reason</Label>
                <Textarea
                  id="return-reason"
                  placeholder="Explain why the case is being returned..."
                  value={assignmentReason}
                  onChange={(e) => setAssignmentReason(e.target.value)}
                  rows={3}
                />
              </div>
            ) : assignmentType === 'complete' ? (
              <div>
                <Label htmlFor="completion-notes">Completion Notes</Label>
                <Textarea
                  id="completion-notes"
                  placeholder="Add any notes about case completion..."
                  value={assignmentReason}
                  onChange={(e) => setAssignmentReason(e.target.value)}
                  rows={3}
                />
              </div>
            ) : null}

            {/* Action Buttons */}
            <div className="flex justify-end space-x-2 pt-4 border-t">
              <Button variant="outline" onClick={resetEscalationForm} disabled={submittingAction}>
                Cancel
              </Button>
              <Button onClick={handleAction} disabled={submittingAction}>
                {submittingAction ? 'Submitting...' : (
                  assignmentType === 'escalate' && disposition === 'no_factors' ? (
                    <>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Complete Case
                    </>
                  ) : assignmentType === 'escalate' && disposition === 'escalate_flu' ? (
                    <>
                      <AlertTriangle className="h-4 w-4 mr-2" />
                      Escalate to FLU AML
                    </>
                  ) : assignmentType === 'escalate' && disposition === 'escalate_gfc' ? (
                    <>
                      <Shield className="h-4 w-4 mr-2" />
                      Escalate to GFC
                    </>
                  ) : assignmentType === 'return' ? (
                    <>
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Return Case
                    </>
                  ) : assignmentType === 'complete' ? (
                    <>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Complete Case
                    </>
                  ) : (
                    <>
                      <ArrowRight className="h-4 w-4 mr-2" />
                      Submit
                    </>
                  )
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export function MyWorkbasketTable({ userRole, currentUser, widgetFilter = 'all' }: MyWorkbasketTableProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all-statuses");
  const [priorityFilter, setPriorityFilter] = useState("all-priorities");
  const [lobFilter, setLobFilter] = useState("all-lobs");
  const [gridApi, setGridApi] = useState<GridApi>();
  const [bulkOperationsOpen, setBulkOperationsOpen] = useState(false);
  const [selectedRows, setSelectedRows] = useState<string[]>([]);

  // Replace mock data with server-driven data
  const [serverCases, setServerCases] = useState<WorkItem[]>([]);
  const [loading, setLoading] = useState(false);

  // new state to support "Get Next" call + refresh trigger
  const [getNextLoading, setGetNextLoading] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  // expose refresh helper to child renderers via context param
  const triggerRefresh = () => setRefreshKey(k => k + 1);

  // fetch from backend when component mounts or widgetFilter/currentUser/refreshKey changes
  useEffect(() => {
    let mounted = true;
    const controller = new AbortController();

    const fetchCases = async () => {
      setLoading(true);
      try {
        const params = new URLSearchParams({
          filter: widgetFilter || 'all',
          limit: String(200),
          offset: String(0)
        });

        // Use the same API base as other components (/api/v1/...)
        const url = `/api/v1/workflows/workbasket/my-cases?${params.toString()}`;

        const res = await fetch(url, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            // pass current user to backend (controller supports X-User-Id for dev)
            'X-User-Id': currentUser || ''
          },
          credentials: 'same-origin',
          signal: controller.signal
        });

        if (!res.ok) {
          const txt = await res.text();
          throw new Error(`Server responded ${res.status}: ${txt}`);
        }

        const wrapper = await res.json();
        // controller returns ApiResponse<WorkbasketResponse>
        const payload = wrapper?.data ?? wrapper;
        const items = payload?.items ?? [];

        if (mounted) setServerCases(items);
      } catch (err: any) {
        if ((err as any).name !== "AbortError") {
          console.error('Failed to load workbasket from server', err);
          toast.error('Unable to load My Workbasket from server');
        }
        if (mounted) setServerCases([]);
      } finally {
        if (mounted) setLoading(false);
      }
    };

    fetchCases();
    return () => {
      mounted = false;
      controller.abort();
    };
  }, [widgetFilter, currentUser, refreshKey]);

  // Column definitions for AG-Grid
  const columnDefs: ColDef[] = useMemo(() => [
    {
      field: 'caseId',
      headerName: 'Case ID',
      width: 150,
      pinned: false,
      sortable: true,
      filter: true,
      headerComponent: CustomHeaderComponent,
      cellClass: 'font-mono text-blue-600'
    },
    {
      field: 'clientName',
      headerName: 'Client',
      width: 200,
      sortable: true,
      filter: true,
      headerComponent: CustomHeaderComponent,
      cellRenderer: (params: any) => (
        <div className="flex items-center space-x-2">
          {params.data.clientType === 'Individual' ? 
            <User className="h-4 w-4 text-muted-foreground" /> : 
            <Building className="h-4 w-4 text-muted-foreground" />
          }
          <div>
            <p className="font-medium">{params.value}</p>
            <p className="text-xs text-muted-foreground">{params.data.clientType}</p>
          </div>
        </div>
      )
    },
    {
      field: 'status',
      headerName: 'Status',
      width: 150,
      sortable: false,
      filter: true,
      headerComponent: CustomHeaderComponent,
      cellRenderer: StatusCellRenderer
    },
    {
      field: 'priority',
      headerName: 'Priority',
      width: 130,
      sortable: false,
      filter: true,
      headerComponent: CustomHeaderComponent,
      cellRenderer: PriorityCellRenderer
    },
    {
      field: 'lob',
      headerName: 'LOB',
      width: 150,
      sortable: true,
      filter: true,
      headerComponent: CustomHeaderComponent
    },
    {
      field: 'daysInQueue',
      headerName: 'Days in Queue',
      width: 130,
      sortable: true,
      filter: true,
      headerComponent: CustomHeaderComponent,
      cellRenderer: (params: any) => (
        <span className={`font-medium ${
          params.value > 5 ? 'text-red-600' : 
          params.value > 2 ? 'text-orange-600' : 
          'text-green-600'
        }`}>
          {params.value} days
        </span>
      )
    },
    {
      field: 'dueDate',
      headerName: 'Due Date',
      width: 120,
      sortable: true,
      filter: 'agDateColumnFilter',
      headerComponent: CustomHeaderComponent,
      cellRenderer: (params: any) => (
        <div className="flex items-center space-x-1">
          <Calendar className="h-3 w-3 text-muted-foreground" />
          <span>{params.value}</span>
        </div>
      )
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 160,
      sortable: false,
      filter: false,
      headerComponent: CustomHeaderComponent,
      // pass context including currentUser and refresh helper
      cellRenderer: (props: any) => <ActionsCellRenderer {...props} />,
      pinned: 'right',
      cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'center' }
    }
  ], []);

  // Use shared widget filter function on server-provided rows for additional client-side filtering (search/status/etc)
  const filteredCases = useMemo(() => {
    return serverCases.filter(caseRecord => {
      const matchesSearch = searchTerm === "" || 
        (caseRecord.caseId ?? "").toLowerCase().includes(searchTerm.toLowerCase()) ||
        (caseRecord.clientName ?? "").toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === "all-statuses" || caseRecord.status === statusFilter;
      const matchesPriority = priorityFilter === "all-priorities" || caseRecord.priority === priorityFilter;
      const matchesLob = lobFilter === "all-lobs" || caseRecord.lob === lobFilter;
      const matchesWidget = matchesWidgetFilter(caseRecord, widgetFilter);
      
      return matchesSearch && matchesStatus && matchesPriority && matchesLob && matchesWidget;
    });
  }, [serverCases, searchTerm, statusFilter, priorityFilter, lobFilter, widgetFilter]);

  const onGridReady = useCallback((params: GridReadyEvent) => {
    setGridApi(params.api);
    // provide context values to cell renderers via grid api (so ActionsCellRenderer can access currentUser & triggerRefresh)
    // Not strictly necessary for current approach, but keep available.
  }, []);

  const onExport = () => {
    if (gridApi) {
      gridApi.exportDataAsCsv({
        fileName: 'my-workbasket-export.csv'
      });
    }
  };

  const resetColumns = () => {
    if (gridApi) {
      gridApi.resetColumnState();
    }
  };

  // Implemented: call backend get-next-case and refresh workbasket on success
  const handleGetNextCase = async () => {
    setGetNextLoading(true);
    try {
      const res = await fetch('/api/v1/workflows/get-next-case', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'X-User-Id': currentUser || ''
        },
        credentials: 'same-origin'
      });

      if (!res.ok) {
        const txt = await res.text().catch(() => res.statusText);
        throw new Error(`Server responded ${res.status}: ${txt}`);
      }

      const wrapper = await res.json();
      // ApiResponse<CaseAssignmentResponse>
      const payload = wrapper?.data ?? wrapper;
      const caseId = payload?.caseId ?? payload?.caseID ?? null;
      const message = payload?.message ?? 'Assigned next available case';

      toast.success(message + (caseId ? ` — ${caseId}` : '' ))

      // Trigger a refresh of the workbasket to show the newly assigned case
      setRefreshKey(k => k + 1);
    } catch (err: any) {
      console.error('Failed to get next case', err);
      toast.error('Unable to get next case: ' + (err?.message ?? 'Unknown error'));
    } finally {
      setGetNextLoading(false);
    }
  };

  // Selection change handler
  const onSelectionChanged = () => {
    if (gridApi) {
      const selectedRows = gridApi.getSelectedRows();
      setSelectedRows(selectedRows.map(row => row.caseId));
    }
  };

  // Default column configuration
  const defaultColDef = useMemo(() => ({
    sortable: true,
    filter: true,
    resizable: true,
    minWidth: 100,
    flex: 1
  }), []);

  // Add error boundary
  try {
    return (
      <div className="space-y-6">
        {/* Filters and Actions */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col lg:flex-row gap-4">
              {/* Search and Filters */}
              <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search my cases..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-statuses">All Statuses</SelectItem>
                    <SelectItem value="assigned">Assigned</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="returned">Returned</SelectItem>
                    <SelectItem value="manual-review">Manual Review</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-priorities">All Priorities</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={lobFilter} onValueChange={setLobFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by LOB" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-lobs">All LOBs</SelectItem>
                    <SelectItem value="Investment Banking">Investment Banking</SelectItem>
                    <SelectItem value="Wealth Management">Wealth Management</SelectItem>
                    <SelectItem value="Private Banking">Private Banking</SelectItem>
                    <SelectItem value="Commercial Banking">Commercial Banking</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap lg:flex-nowrap gap-2 lg:shrink-0">
                {userRole === 'hrs-analyst' && (
                  <Button onClick={handleGetNextCase} size="sm" className="whitespace-nowrap" disabled={getNextLoading}>
                    <PlayCircle className="h-4 w-4 mr-2" />
                    {getNextLoading ? 'Assigning...' : 'Get Next'}
                  </Button>
                )}
                <Button 
                  onClick={() => setBulkOperationsOpen(true)} 
                  variant="outline" 
                  size="sm"
                  disabled={selectedRows.length === 0 || userRole === 'view-only'}
                  className="whitespace-nowrap"
                >
                  <UsersRound className="h-4 w-4 mr-2" />
                  Bulk Operations
                  {selectedRows.length > 0 && (
                    <Badge variant="secondary" className="ml-2 px-1 py-0 text-xs">
                      {selectedRows.length}
                    </Badge>
                  )}
                </Button>
                <Button onClick={onExport} variant="outline" size="sm" className="whitespace-nowrap">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AG-Grid Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>My Workbasket ({filteredCases.length} cases)</span>
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm" onClick={resetColumns}>
                  <Settings className="h-4 w-4 mr-2" />
                  Reset Columns
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="ag-theme-alpine" style={{ height: '600px', width: '100%' }}>
              {typeof window !== 'undefined' && (
                <AgGridReact
                  rowData={filteredCases}
                  columnDefs={columnDefs}
                  defaultColDef={defaultColDef}
                  onGridReady={onGridReady}
                  onSelectionChanged={onSelectionChanged}
                  animateRows={true}
                  sortingOrder={['desc', 'asc']}
                  suppressMenuHide={true}
                  enableCellTextSelection={true}
                  ensureDomOrder={true}
                  pagination={true}
                  paginationPageSize={20}
                  rowSelection={{
                    mode: 'multiRow',
                    enableClickSelection: false,
                    copySelectedRows: true,
                    checkboxes: true,
                    headerCheckbox: true
                  }}
                  suppressCellEvents={false}
                  enableBrowserTooltips={true}
                  ensureDomOrder={true}
                  context={{ userRole, currentUser, triggerRefresh }}
                  icons={getAGGridIconsConfig().iconMap}
                />
              )}
              {loading && <div className="p-4">Loading cases...</div>}
            </div>
          </CardContent>
        </Card>

        {/* Bulk Operations Dialog */}
        <BulkOperationsDialog
          open={bulkOperationsOpen}
          onOpenChange={setBulkOperationsOpen}
          userRole={userRole}
          currentUser={currentUser}
          tableType="workbasket"
          selectedCases={selectedRows}
        />
      </div>
    );
  } catch (error) {
    console.error('Error rendering My Workbasket table:', error);
    return (
      <div className="space-y-6">
        <Card>
          <CardContent className="p-8 text-center">
            <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">Unable to Load Workbasket</h3>
            <p className="text-muted-foreground mb-4">
              There was an error loading your workbasket table. Please refresh the page or contact support.
            </p>
            <Button onClick={() => window.location.reload()} variant="outline">
              Refresh Page
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
}