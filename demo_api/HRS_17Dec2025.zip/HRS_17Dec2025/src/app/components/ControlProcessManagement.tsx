import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Card } from './ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  CheckCircle,
  AlertTriangle,
  Shield,
  Briefcase,
  Search,
  Plus,
  Edit2,
  Trash2,
  Filter,
  Calendar,
} from 'lucide-react';

interface ControlProcess {
  id: string;
  name: string;
  owner: string;
  riskCategory: string;
  riskFactor: string;
  riskFactorDescription: string;
  lob: string;
  frequency: string;
  effectiveness: string;
  status: string;
  lastUpdated: string;
}

const mockControlProcesses: ControlProcess[] = [
  {
    id: '1',
    name: 'Enhanced Due Diligence (EDD)',
    owner: 'Compliance Team',
    riskCategory: 'Geography',
    riskFactor: 'High-Risk Jurisdiction',
    riskFactorDescription: 'Annual enhanced due diligence review including beneficial...',
    lob: 'Investment Banking',
    frequency: 'Annual',
    effectiveness: 'High',
    status: 'Active',
    lastUpdated: '5/14/2024',
  },
  {
    id: '2',
    name: 'Transaction Monitoring',
    owner: 'Operations Team',
    riskCategory: 'Product',
    riskFactor: 'Prime Brokerage Services',
    riskFactorDescription: 'Real-time transaction monitoring with enhanced threshold...',
    lob: 'Investment Banking',
    frequency: 'Real-time',
    effectiveness: 'High',
    status: 'Active',
    lastUpdated: '5/31/2024',
  },
  {
    id: '3',
    name: 'Ongoing PEP Monitoring',
    owner: 'AML Team',
    riskCategory: 'Customer Attributes',
    riskFactor: 'PEP Status',
    riskFactorDescription: 'Continuous screening against global PEP databases with...',
    lob: 'Wealth Management',
    frequency: 'Quarterly',
    effectiveness: 'Medium',
    status: 'Active',
    lastUpdated: '4/19/2024',
  },
  {
    id: '4',
    name: 'Intelligence Review Committee',
    owner: 'GFC Team',
    riskCategory: 'Bank Intelligence',
    riskFactor: 'GFC Intelligence',
    riskFactorDescription: 'Monthly review by GFC intelligence team with escalation p...',
    lob: 'All LOBs',
    frequency: 'Monthly',
    effectiveness: 'High',
    status: 'Active',
    lastUpdated: '6/9/2024',
  },
  {
    id: '5',
    name: 'Enhanced Transaction Review',
    owner: 'Commercial Banking AML',
    riskCategory: 'Industry',
    riskFactor: 'High-Risk Industry (Crypto)',
    riskFactorDescription: 'Manual review of all transactions exceeding threshold am...',
    lob: 'Commercial Banking',
    frequency: 'Per Transaction',
    effectiveness: 'Medium',
    status: 'Deprecated',
    lastUpdated: '3/14/2024',
  },
];

interface ControlProcessManagementProps {
  onBack: () => void;
}

export function ControlProcessManagement({ onBack }: ControlProcessManagementProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [lobFilter, setLobFilter] = useState('all-lobs');
  const [categoryFilter, setCategoryFilter] = useState('all-categories');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showAddForm, setShowAddForm] = useState(false);

  const getEffectivenessColor = (effectiveness: string) => {
    const colors: Record<string, string> = {
      High: 'bg-green-100 text-green-700',
      Medium: 'bg-orange-100 text-orange-700',
      Low: 'bg-red-100 text-red-700',
    };
    return colors[effectiveness] || 'bg-gray-100 text-gray-700';
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      Active: 'bg-green-100 text-green-700',
      Deprecated: 'bg-red-100 text-red-700',
      Pending: 'bg-yellow-100 text-yellow-700',
    };
    return colors[status] || 'bg-gray-100 text-gray-700';
  };

  // Filter the control processes
  const filteredProcesses = mockControlProcesses.filter((process) => {
    // Search filter
    const matchesSearch = searchQuery === '' || 
      process.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      process.owner.toLowerCase().includes(searchQuery.toLowerCase()) ||
      process.riskFactor.toLowerCase().includes(searchQuery.toLowerCase());

    // LOB filter
    const matchesLob = lobFilter === 'all-lobs' || 
      process.lob.toLowerCase().includes(lobFilter.replace('-', ' ')) ||
      process.lob === 'All LOBs';

    // Category filter
    const matchesCategory = categoryFilter === 'all-categories' ||
      process.riskCategory.toLowerCase().includes(categoryFilter);

    // Status filter
    const matchesStatus = statusFilter === 'all' ||
      process.status.toLowerCase() === statusFilter.toLowerCase();

    return matchesSearch && matchesLob && matchesCategory && matchesStatus;
  });

  return (
    <div className="bg-white">
      <div className="w-full min-h-screen px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
        {/* Header Section */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h2 className="text-2xl text-blue-900">Control Process Management</h2>
              <p className="text-sm text-gray-600 mt-1">
                Manage control process definitions used in risk mitigant sections
              </p>
            </div>
            <Button 
              className="bg-[#3b4d7a] hover:bg-[#2d3a5c] text-white rounded-md px-4 py-2"
              onClick={() => setShowAddForm(!showAddForm)}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Control Process
            </Button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="p-4 border-l-4 border-l-green-500">
            <div className="flex items-center gap-3">
              <div className="bg-green-100 p-2 rounded-lg">
                <CheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <div className="text-sm text-gray-600">Active Controls</div>
                <div className="text-2xl">4</div>
              </div>
            </div>
          </Card>

          <Card className="p-4 border-l-4 border-l-orange-500">
            <div className="flex items-center gap-3">
              <div className="bg-orange-100 p-2 rounded-lg">
                <AlertTriangle className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <div className="text-sm text-gray-600">Pending Review</div>
                <div className="text-2xl">0</div>
              </div>
            </div>
          </Card>

          <Card className="p-4 border-l-4 border-l-blue-500">
            <div className="flex items-center gap-3">
              <div className="bg-blue-100 p-2 rounded-lg">
                <Shield className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <div className="text-sm text-gray-600">High Effectiveness</div>
                <div className="text-2xl">3</div>
              </div>
            </div>
          </Card>

          <Card className="p-4 border-l-4 border-l-purple-500">
            <div className="flex items-center gap-3">
              <div className="bg-purple-100 p-2 rounded-lg">
                <Briefcase className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <div className="text-sm text-gray-600">Total LOBs</div>
                <div className="text-2xl">4</div>
              </div>
            </div>
          </Card>
        </div>

        {/* Add New Control Process Form */}
        {showAddForm && (
          <div className="bg-white border-2 border-dashed border-gray-300 rounded-lg p-6 mb-6">
            <h3 className="text-blue-900 mb-4">Add New Control Process</h3>
            
            <div className="space-y-4">
              {/* Row 1: Risk Category, Line of Business, Frequency */}
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm text-blue-900 mb-1">
                    Risk Category <span className="text-red-500">*</span>
                  </label>
                  <Select defaultValue="">
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="geography">Geography</SelectItem>
                      <SelectItem value="product">Product</SelectItem>
                      <SelectItem value="customer">Customer Attributes</SelectItem>
                      <SelectItem value="bank">Bank Intelligence</SelectItem>
                      <SelectItem value="industry">Industry</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm text-blue-900 mb-1">
                    Line of Business <span className="text-red-500">*</span>
                  </label>
                  <Select defaultValue="">
                    <SelectTrigger>
                      <SelectValue placeholder="Select LOB" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="investment-banking">Investment Banking</SelectItem>
                      <SelectItem value="wealth-management">Wealth Management</SelectItem>
                      <SelectItem value="commercial-banking">Commercial Banking</SelectItem>
                      <SelectItem value="all-lobs">All LOBs</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm text-blue-900 mb-1">Frequency</label>
                  <Select defaultValue="">
                    <SelectTrigger>
                      <SelectValue placeholder="Select frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="real-time">Real-time</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="annual">Annual</SelectItem>
                      <SelectItem value="per-transaction">Per Transaction</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Row 2: Risk Factor, Control Name */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-blue-900 mb-1">
                    Risk Factor <span className="text-red-500">*</span>
                  </label>
                  <Input placeholder="Enter risk factor" />
                </div>

                <div>
                  <label className="block text-sm text-blue-900 mb-1">
                    Control Name <span className="text-red-500">*</span>
                  </label>
                  <Input placeholder="Enter control name" />
                </div>
              </div>

              {/* Row 3: Description */}
              <div>
                <label className="block text-sm text-blue-900 mb-1">Description</label>
                <textarea
                  placeholder="Describe the control process..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 min-h-[80px]"
                />
              </div>

              {/* Row 4: Process Owner, Effectiveness, Status */}
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm text-blue-900 mb-1">Process Owner</label>
                  <Input placeholder="Enter owner" />
                </div>

                <div>
                  <label className="block text-sm text-blue-900 mb-1">Effectiveness</label>
                  <Select defaultValue="medium">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm text-blue-900 mb-1">Status</label>
                  <Select defaultValue="active">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="deprecated">Deprecated</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-3 pt-2">
                <Button className="bg-[#3b4d7a] hover:bg-[#2d3a5c] text-white">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Process
                </Button>
                <Button 
                  variant="ghost" 
                  className="text-gray-700"
                  onClick={() => setShowAddForm(false)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Search and Filters */}
        <div className="flex items-center gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search control processes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select defaultValue="all-lobs" value={lobFilter} onValueChange={setLobFilter}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all-lobs">All LOBs</SelectItem>
              <SelectItem value="investment-banking">Investment Banking</SelectItem>
              <SelectItem value="wealth-management">Wealth Management</SelectItem>
              <SelectItem value="commercial-banking">Commercial Banking</SelectItem>
            </SelectContent>
          </Select>
          <Select defaultValue="all-categories" value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all-categories">All Categories</SelectItem>
              <SelectItem value="geography">Geography</SelectItem>
              <SelectItem value="product">Product</SelectItem>
              <SelectItem value="customer">Customer Attributes</SelectItem>
              <SelectItem value="bank">Bank Intelligence</SelectItem>
              <SelectItem value="industry">Industry</SelectItem>
            </SelectContent>
          </Select>
          <Select defaultValue="all" value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="deprecated">Deprecated</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Table Section */}
        <div className="bg-white border rounded-lg overflow-hidden">
          <div className="px-4 py-3 border-b bg-gray-50">
            <h3 className="text-blue-900">Control Processes ({filteredProcesses.length} processes)</h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-white border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-sm text-blue-900 whitespace-nowrap">
                    Control Name
                  </th>
                  <th className="px-4 py-3 text-left text-sm text-blue-900 whitespace-nowrap">
                    Risk Category
                  </th>
                  <th className="px-4 py-3 text-left text-sm text-blue-900 whitespace-nowrap">
                    Risk Factor
                  </th>
                  <th className="px-4 py-3 text-left text-sm text-blue-900 whitespace-nowrap">
                    LOB
                  </th>
                  <th className="px-4 py-3 text-left text-sm text-blue-900 whitespace-nowrap">
                    Frequency
                  </th>
                  <th className="px-4 py-3 text-left text-sm text-blue-900 whitespace-nowrap">
                    Effectiveness
                  </th>
                  <th className="px-4 py-3 text-left text-sm text-blue-900 whitespace-nowrap">
                    Status
                  </th>
                  <th className="px-4 py-3 text-left text-sm text-blue-900 whitespace-nowrap">
                    Last Updated
                  </th>
                  <th className="px-4 py-3 text-left text-sm text-blue-900 whitespace-nowrap">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredProcesses.map((process) => (
                  <tr key={process.id} className="hover:bg-gray-50">
                    <td className="px-4 py-4">
                      <div>
                        <div className="text-sm text-blue-600 hover:underline cursor-pointer">
                          {process.name}
                        </div>
                        <div className="text-xs text-gray-500">Owner: {process.owner}</div>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <Badge variant="outline" className="text-blue-700 border-blue-300">
                        {process.riskCategory}
                      </Badge>
                    </td>
                    <td className="px-4 py-4">
                      <div>
                        <div className="text-sm">{process.riskFactor}</div>
                        <div className="text-xs text-gray-500">{process.riskFactorDescription}</div>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-1 text-sm">
                        <Briefcase className="h-3 w-3 text-gray-400" />
                        {process.lob}
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <span className="text-sm">{process.frequency}</span>
                    </td>
                    <td className="px-4 py-4">
                      <Badge variant="secondary" className={getEffectivenessColor(process.effectiveness)}>
                        {process.effectiveness}
                      </Badge>
                    </td>
                    <td className="px-4 py-4">
                      <Badge variant="secondary" className={getStatusColor(process.status)}>
                        {process.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-600">{process.lastUpdated}</td>
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm">
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="px-4 py-3 border-t bg-gray-50 flex items-center justify-between">
            <div className="text-sm text-gray-600">Showing 1 to {filteredProcesses.length} of {filteredProcesses.length} processes</div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled>
                Previous
              </Button>
              <Button variant="outline" size="sm" disabled>
                Next
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}