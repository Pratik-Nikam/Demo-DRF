package com.bofa.aml.hra.service;

import com.bofa.aml.hra.dto.response.WorkItem;
import com.bofa.aml.hra.dto.response.WorkbasketResponse;
import com.bofa.aml.hra.model.CaseEntity;
import com.bofa.aml.hra.repository.CaseRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles("test")
@Transactional
public class WorkflowServiceIntegrationTest {

    @Autowired
    private WorkflowService workflowService;

    @Autowired
    private CaseRepository caseRepository;

    @Test
    void getMyWorkbasket_all_returnsAssignedCasesForUser() {
        WorkbasketResponse resp = workflowService.getMyWorkbasket("Sarah Johnson", "all", 50, 0);

        assertThat(resp).isNotNull();
        assertThat(resp.getItems()).isNotNull();
        assertThat(resp.getTotal()).isGreaterThanOrEqualTo(resp.getItems().size());
        List<String> assigned = resp.getItems().stream()
                .map(WorkItem::getAssignedAnalyst)
                .collect(Collectors.toList());
        assertThat(assigned).allMatch(a -> a != null && a.equals("Sarah Johnson"));
    }

    @Test
    void getMyWorkbasket_active_returnsOnlyAssignedOrInProgress() {
        WorkbasketResponse resp = workflowService.getMyWorkbasket("Sarah Johnson", "active", 50, 0);

        assertThat(resp).isNotNull();
        assertThat(resp.getItems()).isNotNull();
        assertThat(resp.getItems()).allMatch(item ->
                "assigned".equalsIgnoreCase(item.getStatus()) ||
                        "in-progress".equalsIgnoreCase(item.getStatus())
        );
    }

    @Test
    void getMyWorkbasket_escalations_returnsCandidates() {
        WorkbasketResponse resp = workflowService.getMyWorkbasket("Sarah Johnson", "escalations", 50, 0);

        assertThat(resp).isNotNull();
        assertThat(resp.getItems()).isNotNull();
        boolean hasCandidate = resp.getItems().stream().anyMatch(item ->
                (item.getEscalationReason() != null && !item.getEscalationReason().isBlank()) ||
                        item.getManualReviewReasons().stream()
                                .anyMatch(r -> {
                                    String low = r.toLowerCase();
                                    return low.contains("gfc intelligence") ||
                                            low.contains("risk drivers") ||
                                            low.contains("client escalation") ||
                                            low.contains("trms referral");
                                })
        );
        assertThat(hasCandidate).isTrue();
    }

    @Test
    void getMyWorkbasket_completed_returnsFixedDateCompletedCases() {
        LocalDateTime completedAt = LocalDate.of(2024, 6, 27).atTime(10, 0);
        CaseEntity todayCompleted = CaseEntity.builder()
                .caseId("TEST-COMP-" + System.currentTimeMillis())
                .clientId("T-1000")
                .clientName("Integration Test Client")
                .clientType("Corporate")
                .status("completed")
                .priority("low")
                .assignedAnalyst("Sarah Johnson")
                .createdAt(LocalDate.of(2024, 6, 26).atStartOfDay())
                .dueDate(LocalDate.of(2024, 6, 28))
                .completedDate(completedAt)
                .riskRating("Low")
                .manualReviewReasons("[]")
                .jurisdiction("Testland")
                .lob("Investment Banking")
                .build();

        caseRepository.save(todayCompleted);

        WorkbasketResponse resp = workflowService.getMyWorkbasket("Sarah Johnson", "completed", 50, 0);

        assertThat(resp).isNotNull();
        assertThat(resp.getItems()).isNotNull();
        boolean contains = resp.getItems().stream()
                .anyMatch(i -> i.getCaseId().equals(todayCompleted.getCaseId()));
        assertThat(contains).isTrue();
    }
}