package com.bofa.aml.hra.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * WorkItem DTO aligned with frontend WorkQueueRecord shape.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkItem {
    // Business-facing case id (e.g. HRA-2024-0101)
    private String caseId;

    private String clientId;
    private String clientName;
    private String clientType; // Individual|Corporate|Investment|Banking

    private String status; // new|unassigned|assigned|in-progress|escalated|returned|completed|...
    private String priority; // low|medium|high|critical

    // Name or identifier of analyst assigned, "Unassigned" when null
    private String assignedAnalyst;

    // ISO strings for created/due/completed dates (frontend expects displayable strings)
    private String createdDate;
    private String dueDate;
    private String completedDate;

    // Risk rating label (Low|Medium|High)
    private String riskRating;

    // List of reasons (parsed from JSON stored in DB)
    private List<String> manualReviewReasons;

    private String jurisdiction;
    private String lob;

    // Computed on server for convenience
    private Integer daysInQueue;

    // Optional free-text fields
    private String escalationReason;
    private String returnReason;
}