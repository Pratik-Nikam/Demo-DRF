package com.bofa.aml.hra.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

/**
 * Provides the application Clock.
 * If the property 'app.clock.fixed' is set to an RFC3339 instant (e.g. 2024-06-27T00:00:00Z)
 * the Clock will be fixed to that instant (useful for deterministic dev/tests).
 * Otherwise the system default clock is returned.
 */
@Configuration
public class TimeConfig {

    @Bean
    @Primary
    public Clock applicationClock(@Value("${app.clock.fixed:}") String fixedInstant) {
        if (fixedInstant == null || fixedInstant.isBlank()) {
            return Clock.systemDefaultZone();
        }
        Instant instant = Instant.parse(fixedInstant);
        // Use UTC for fixed clocks to avoid local timezone offsets affecting "today"
        return Clock.fixed(instant, ZoneOffset.UTC);
    }
}