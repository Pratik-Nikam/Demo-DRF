package com.bofa.aml.hra.config;

import com.bofa.aml.hra.model.CaseEntity;
import com.bofa.aml.hra.repository.CaseRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Seeds H2 with sample CaseEntity rows derived from the frontend mockWorkQueueCases.
 * Runs only when the cases table is empty.
 */
@Configuration
@RequiredArgsConstructor
@Slf4j
public class DataLoader implements CommandLineRunner {
    private final CaseRepository caseRepository;

    @Override
    public void run(String... args) {
        if (caseRepository.count() > 0) {
            log.debug("DataLoader: cases already exist (count={}), skipping seed.", caseRepository.count());
            return;
        }

        log.debug("DataLoader: seeding sample CaseEntity records for work queue...");

        List<CaseEntity> seeds = List.of(
            CaseEntity.builder()
                .caseId("HRA-2024-0101")
                .clientId("CLT101")
                .clientName("Meridian Capital Group")
                .clientType("Investment")
                .status("new")
                .priority("medium")
                .assignedAnalyst(null)
                .createdAt(LocalDate.parse("2024-06-18").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-30"))
                .riskRating("Medium")
                .manualReviewReasons("[\"New client onboarding\"]")
                .jurisdiction("United States")
                .lob("Investment Banking")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0102")
                .clientId("CLT102")
                .clientName("Atlantic Holdings LLC")
                .clientType("Corporate")
                .status("unassigned")
                .priority("high")
                .assignedAnalyst(null)
                .createdAt(LocalDate.parse("2024-06-17").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-27"))
                .riskRating("High")
                .manualReviewReasons("[\"Risk drivers >5\",\"Complex ownership\"]")
                .jurisdiction("Luxembourg")
                .lob("Wealth Management")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0103")
                .clientId("CLT103")
                .clientName("Global Tech Ventures")
                .clientType("Corporate")
                .status("assigned")
                .priority("critical")
                .assignedAnalyst("Sarah Johnson")
                .createdAt(LocalDate.parse("2024-06-16").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-26"))
                .riskRating("High")
                .manualReviewReasons("[\"GFC Intelligence is Yes\",\"TRMS referrals\"]")
                .jurisdiction("Cayman Islands")
                .lob("Investment Banking")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0104")
                .clientId("CLT104")
                .clientName("Phoenix Investment Trust")
                .clientType("Investment")
                .status("in-progress")
                .priority("medium")
                .assignedAnalyst("Michael Chen")
                .createdAt(LocalDate.parse("2024-06-15").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-25"))
                .riskRating("Medium")
                .manualReviewReasons("[\"Beneficial ownership change\"]")
                .jurisdiction("Singapore")
                .lob("Private Banking")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0105")
                .clientId("CLT105")
                .clientName("European Financial Services")
                .clientType("Banking")
                .status("escalated")
                .priority("critical")
                .assignedAnalyst("Emily Rodriguez")
                .createdAt(LocalDate.parse("2024-06-14").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-24"))
                .riskRating("High")
                .manualReviewReasons("[\"Sanctions screening\",\"PEP status\"]")
                .jurisdiction("Switzerland")
                .escalationReason("GFC Intelligence flagged, requiring specialized review")
                .lob("Commercial Banking")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0106")
                .clientId("CLT106")
                .clientName("Sterling Commodities Ltd")
                .clientType("Corporate")
                .status("returned")
                .priority("high")
                .assignedAnalyst("David Kim")
                .createdAt(LocalDate.parse("2024-06-13").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-23"))
                .riskRating("High")
                .manualReviewReasons("[\"Trade allocation review\"]")
                .jurisdiction("Hong Kong")
                .returnReason("Missing client documentation and verification")
                .lob("Investment Banking")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0107")
                .clientId("CLT107")
                .clientName("North American Mining Corp")
                .clientType("Corporate")
                .status("auto-completed")
                .priority("low")
                .assignedAnalyst("Auto-System")
                .createdAt(LocalDate.parse("2024-06-12").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-22"))
                .completedDate(LocalDate.parse("2024-06-13").atStartOfDay())
                .riskRating("Low")
                .manualReviewReasons("[]")
                .jurisdiction("Canada")
                .lob("Commercial Banking")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0108")
                .clientId("CLT108")
                .clientName("Alexander Petrov")
                .clientType("Individual")
                .status("manual-review")
                .priority("high")
                .assignedAnalyst("Lisa Zhang")
                .createdAt(LocalDate.parse("2024-06-11").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-21"))
                .riskRating("High")
                .manualReviewReasons("[\"High-risk jurisdiction\",\"Income source verification\"]")
                .jurisdiction("Russia")
                .lob("Private Banking")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0109")
                .clientId("CLT109")
                .clientName("Pacific Trade Alliance")
                .clientType("Corporate")
                .status("completed")
                .priority("medium")
                .assignedAnalyst("James Wilson")
                .createdAt(LocalDate.parse("2024-06-08").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-18"))
                .completedDate(LocalDate.parse("2024-06-16").atStartOfDay())
                .riskRating("Medium")
                .manualReviewReasons("[\"Trade finance review\"]")
                .jurisdiction("Australia")
                .lob("Commercial Banking")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0110")
                .clientId("CLT110")
                .clientName("Digital Assets Fund")
                .clientType("Investment")
                .status("abandoned")
                .priority("low")
                .assignedAnalyst("Auto-System")
                .createdAt(LocalDate.parse("2024-06-05").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-15"))
                .riskRating("Medium")
                .manualReviewReasons("[\"Incomplete application\"]")
                .jurisdiction("Malta")
                .lob("Investment Banking")
                .build(),

            // additional entries from workbasket-data to reach ~30 records
            CaseEntity.builder()
                .caseId("HRA-2024-0201")
                .clientId("CLT201")
                .clientName("Global Dynamics Corp")
                .clientType("Corporate")
                .status("assigned")
                .priority("high")
                .assignedAnalyst("Sarah Johnson")
                .createdAt(LocalDate.parse("2024-06-15").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-25"))
                .riskRating("High")
                .manualReviewReasons("[\"GFC Intelligence is Yes\",\"Risk drivers >10\"]")
                .jurisdiction("Cayman Islands")
                .lob("Investment Banking")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0203")
                .clientId("CLT203")
                .clientName("Alexander Petrov")
                .clientType("Individual")
                .status("in-progress")
                .priority("critical")
                .assignedAnalyst("Sarah Johnson")
                .createdAt(LocalDate.parse("2024-06-14").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-24"))
                .riskRating("High")
                .manualReviewReasons("[\"Client escalation\",\"Address change\",\"Income source change\"]")
                .jurisdiction("Switzerland")
                .lob("Private Banking")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0205")
                .clientId("CLT205")
                .clientName("Meridian Investment Group")
                .clientType("Investment")
                .status("manual-review")
                .priority("medium")
                .assignedAnalyst("Sarah Johnson")
                .createdAt(LocalDate.parse("2024-06-13").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-23"))
                .riskRating("Medium")
                .manualReviewReasons("[\"Beneficial ownership structure complexity\"]")
                .jurisdiction("Luxembourg")
                .lob("Wealth Management")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0207")
                .clientId("CLT207")
                .clientName("Pacific Trade Solutions")
                .clientType("Corporate")
                .status("returned")
                .priority("high")
                .assignedAnalyst("Sarah Johnson")
                .createdAt(LocalDate.parse("2024-06-12").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-22"))
                .riskRating("High")
                .manualReviewReasons("[\"Complex trade structure\"]")
                .returnReason("Additional client documentation required")
                .jurisdiction("Singapore")
                .lob("Commercial Banking")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0209")
                .clientId("CLT209")
                .clientName("Sterling Financial Holdings")
                .clientType("Banking")
                .status("assigned")
                .priority("medium")
                .assignedAnalyst("Sarah Johnson")
                .createdAt(LocalDate.parse("2024-06-11").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-21"))
                .riskRating("Medium")
                .manualReviewReasons("[\"New product risk assessment\"]")
                .jurisdiction("United Kingdom")
                .lob("Investment Banking")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0213")
                .clientId("CLT213")
                .clientName("Alpine Holdings Ltd")
                .clientType("Corporate")
                .status("completed")
                .priority("medium")
                .assignedAnalyst("Sarah Johnson")
                .createdAt(LocalDate.parse("2024-06-05").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-15"))
                .completedDate(LocalDate.parse("2024-10-06").atStartOfDay())
                .riskRating("Medium")
                .manualReviewReasons("[\"Standard assessment completed\"]")
                .jurisdiction("Switzerland")
                .lob("Private Banking")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0217")
                .clientId("CLT217")
                .clientName("Quantum Investments")
                .clientType("Investment")
                .status("manual-review")
                .priority("critical")
                .assignedAnalyst("Sarah Johnson")
                .createdAt(LocalDate.parse("2024-06-16").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-26"))
                .riskRating("High")
                .manualReviewReasons("[\"GFC Intelligence flagged\",\"Risk drivers >10\",\"Client escalation\"]")
                .jurisdiction("Cayman Islands")
                .lob("Investment Banking")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0223")
                .clientId("CLT223")
                .clientName("Titan Manufacturing Inc")
                .clientType("Corporate")
                .status("assigned")
                .priority("medium")
                .assignedAnalyst("Sarah Johnson")
                .createdAt(LocalDate.parse("2024-06-17").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-27"))
                .riskRating("Medium")
                .manualReviewReasons("[\"Standard assessment required\"]")
                .jurisdiction("Canada")
                .lob("Commercial Banking")
                .build(),

            CaseEntity.builder()
                .caseId("HRA-2024-0225")
                .clientId("CLT225")
                .clientName("Elena Rodriguez")
                .clientType("Individual")
                .status("in-progress")
                .priority("high")
                .assignedAnalyst("Sarah Johnson")
                .createdAt(LocalDate.parse("2024-06-16").atStartOfDay())
                .dueDate(LocalDate.parse("2024-06-26"))
                .riskRating("High")
                .manualReviewReasons("[\"Source of Income changes\",\"Address changes\"]")
                .jurisdiction("Spain")
                .lob("Private Banking")
                .build()
        );

        caseRepository.saveAll(seeds);
        log.debug("DataLoader: seeded {} case records.", seeds.size());
    }
}