package com.bofa.aml.hra.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Persisted JPA entity for case records used by workflow APIs.
 * - Primary key `id` is generated if not provided (UUID string).
 * - `caseId` is the business-facing identifier (e.g. HRA-2024-0101).
 * - `manualReviewReasons` is stored as TEXT (JSON array or CSV) to keep schema simple for now.
 */
@Entity
@Table(name = "cases")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CaseEntity {

    @Id
    @Column(length = 36)
    private String id;

    @Column(name = "case_id", unique = true, nullable = false)
    private String caseId;

    @Column(name = "client_id", nullable = false)
    private String clientId;

    @Column(name = "client_name")
    private String clientName;

    @Column(name = "client_type")
    private String clientType; // e.g. Individual|Corporate|Investment|Banking

    @Column(name = "status")
    private String status; // e.g. new, unassigned, assigned, in-progress, escalated, returned, completed

    @Column(name = "priority")
    private String priority; // low|medium|high|critical

    @Column(name = "assigned_analyst")
    private String assignedAnalyst;

    @Column(name = "lob")
    private String lob;

    @Column(name = "risk_rating")
    private String riskRating; // Low|Medium|High

    @Column(name = "manual_review_reasons", columnDefinition = "TEXT")
    private String manualReviewReasons; // JSON array or CSV string

    @Column(name = "jurisdiction")
    private String jurisdiction;

    @Column(name = "escalation_reason", columnDefinition = "TEXT")
    private String escalationReason;

    @Column(name = "return_reason", columnDefinition = "TEXT")
    private String returnReason;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "due_date")
    private LocalDate dueDate;

    @Column(name = "completed_date")
    private LocalDateTime completedDate;

    @PrePersist
    public void prePersist() {
        if (this.id == null || this.id.isEmpty()) {
            this.id = UUID.randomUUID().toString();
        }
        if (this.createdAt == null) {
            this.createdAt = LocalDateTime.now();
        }
        // Ensure a business caseId exists if not provided (keeps test data simpler)
        if (this.caseId == null || this.caseId.isEmpty()) {
            this.caseId = "HRA-" + this.id.substring(0, 8).toUpperCase();
        }
    }
}