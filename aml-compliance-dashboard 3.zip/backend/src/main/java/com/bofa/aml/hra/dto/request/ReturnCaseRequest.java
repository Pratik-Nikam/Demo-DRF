package com.bofa.aml.hra.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReturnCaseRequest {
    @NotBlank(message = "Case ID is required")
    private String caseId;

    @NotBlank(message = "Return comments are required")
    private String comments;
}