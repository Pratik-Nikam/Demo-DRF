package com.bofa.aml.hra.dto.request;

public class RiskSummaryRequest {
    // placeholder
}