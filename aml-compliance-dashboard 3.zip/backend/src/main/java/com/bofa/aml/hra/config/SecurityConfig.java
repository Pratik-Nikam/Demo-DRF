package com.bofa.aml.hra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // disable CSRF for simplicity in dev (adjust for production)
            .csrf(csrf -> csrf.disable())

            // allow frames so H2 console works
            .headers(headers -> headers.frameOptions(frameOptions -> frameOptions.disable()))

            // permit H2 console + swagger, authenticate other endpoints
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/h2-console/**", "/h2-console/**", "/api/v1/api-docs/**", "/swagger-ui/**").permitAll()
                .anyRequest().authenticated()
            )

            // keep a simple auth method for dev (adjust in prod)
            .httpBasic();

        return http.build();
    }
}