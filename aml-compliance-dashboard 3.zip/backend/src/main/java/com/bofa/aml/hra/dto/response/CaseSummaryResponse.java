package com.bofa.aml.hra.dto.response;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CaseSummaryResponse {
    private String id;
    private String clientId;
    private String clientName;
    private String assignedAnalyst;
    private String status;
    private String lob;
    private String createdAt; // ISO string for frontend
}