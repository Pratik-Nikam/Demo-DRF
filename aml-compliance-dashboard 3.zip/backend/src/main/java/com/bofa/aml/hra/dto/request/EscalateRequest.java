package com.bofa.aml.hra.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Request DTO for escalations.
 * Only caseId is required; reason/notes are optional to support the My Workbasket UI.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EscalateRequest {

    @NotBlank(message = "caseId is required")
    private String caseId;

    /**
     * Target for escalation. Can be a role token (e.g. "flu-aml", "gfc") or a manager id.
     */
    private String escalateTo;

    /**
     * Disposition token from UI (optional).
     */
    private String disposition;

    /**
     * Escalation type token from UI (optional).
     */
    private String escalationType;

    /**
     * Optional list of selected escalation reasons from UI.
     */
    private List<String> escalationReasons;

    /**
     * Optional free-text notes provided by user.
     */
    private String notes;
}