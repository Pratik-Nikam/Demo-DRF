package com.bofa.aml.hra.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DispositionRequest {
    @NotBlank(message = "Case ID is required")
    private String caseId;

    @NotBlank(message = "Disposition is required")
    private String disposition; // e.g. "cleared", "escalated", "no-action"

    private String comments;
}