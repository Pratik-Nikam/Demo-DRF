package com.bofa.aml.hra.repository;

import com.bofa.aml.hra.model.CaseEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface CaseRepository extends JpaRepository<CaseEntity, String> {

    /**
     * Filtered pageable query. Treats null or empty params as no-filter for that field.
     */
    @Query("SELECT c FROM CaseEntity c " +
           "WHERE (:lob IS NULL OR :lob = '' OR c.lob = :lob) " +
           "AND (:status IS NULL OR :status = '' OR c.status = :status) " +
           "AND (:assignedAnalyst IS NULL OR :assignedAnalyst = '' OR c.assignedAnalyst = :assignedAnalyst)")
    Page<CaseEntity> findFiltered(@Param("lob") String lob,
                                  @Param("status") String status,
                                  @Param("assignedAnalyst") String assignedAnalyst,
                                  Pageable pageable);

    /**
     * Find unassigned cases for a given LOB.
     */
    @Query("SELECT c FROM CaseEntity c WHERE c.lob = :lob AND (c.status = 'unassigned' OR c.assignedAnalyst IS NULL)")
    List<CaseEntity> findUnassignedByLob(@Param("lob") String lob);

    /**
     * Simple finder by assigned analyst (list).
     */
    List<CaseEntity> findByAssignedAnalyst(String assignedAnalyst);

    /**
     * Paged finder by assigned analyst (for workbasket paging).
     */
    Page<CaseEntity> findByAssignedAnalyst(@Param("assignedAnalyst") String assignedAnalyst, Pageable pageable);

    /**
     * Paged finder by assigned analyst and single status (returned, etc).
     */
    Page<CaseEntity> findByAssignedAnalystAndStatus(@Param("assignedAnalyst") String assignedAnalyst,
                                                    @Param("status") String status,
                                                    Pageable pageable);

    /**
     * Paged finder by assigned analyst and multiple statuses (active states).
     */
    Page<CaseEntity> findByAssignedAnalystAndStatusIn(@Param("assignedAnalyst") String assignedAnalyst,
                                                      @Param("statuses") List<String> statuses,
                                                      Pageable pageable);

    /**
     * Escalation candidates for an analyst: explicit escalationReason OR manualReviewReasons containing key flags.
     * Keys should be supplied in lowercase (caller should LOWER-case them).
     */
    @Query("SELECT c FROM CaseEntity c WHERE c.assignedAnalyst = :assignedAnalyst AND (" +
           "(c.escalationReason IS NOT NULL AND c.escalationReason <> '') OR " +
           "LOWER(c.manualReviewReasons) LIKE CONCAT('%', :kw1, '%') OR " +
           "LOWER(c.manualReviewReasons) LIKE CONCAT('%', :kw2, '%') OR " +
           "LOWER(c.manualReviewReasons) LIKE CONCAT('%', :kw3, '%') OR " +
           "LOWER(c.manualReviewReasons) LIKE CONCAT('%', :kw4, '%'))")
    Page<CaseEntity> findEscalationCandidates(@Param("assignedAnalyst") String assignedAnalyst,
                                              @Param("kw1") String kw1,
                                              @Param("kw2") String kw2,
                                              @Param("kw3") String kw3,
                                              @Param("kw4") String kw4,
                                              Pageable pageable);

    /**
     * Completed cases for an analyst within a datetime range (use startOfDay / endOfDay for "today").
     */
    @Query("SELECT c FROM CaseEntity c WHERE c.assignedAnalyst = :assignedAnalyst AND c.status = 'completed' " +
           "AND c.completedDate >= :startOfDay AND c.completedDate < :endOfDay")
    Page<CaseEntity> findCompletedToday(@Param("assignedAnalyst") String assignedAnalyst,
                                        @Param("startOfDay") LocalDateTime startOfDay,
                                        @Param("endOfDay") LocalDateTime endOfDay,
                                        Pageable pageable);

    /**
     * Simple finder by status.
     */
    List<CaseEntity> findByStatus(String status);

    /**
     * Full-text-ish search across notable fields (case-insensitive).
     * Use for quick search box; the caller should pass lowercase search term.
     */
    @Query("SELECT c FROM CaseEntity c " +
           "WHERE (LOWER(c.caseId) LIKE CONCAT('%', :q, '%') " +
           "   OR LOWER(c.clientName) LIKE CONCAT('%', :q, '%') " +
           "   OR LOWER(c.clientId) LIKE CONCAT('%', :q, '%'))")
    Page<CaseEntity> searchByText(@Param("q") String q, Pageable pageable);

    /**
     * FIFO selection of the oldest unassigned case(s).
     * Returns at most the number requested by pageable (use size=1 to get one).
     */
    @Query("SELECT c FROM CaseEntity c WHERE c.assignedAnalyst IS NULL OR c.status = 'unassigned' ORDER BY c.createdAt ASC")
    List<CaseEntity> findNextUnassigned(Pageable pageable);

    /**
     * Lookup by business case id (e.g. HRA-2024-0101).
     */
    Optional<CaseEntity> findByCaseId(String caseId);
}