import { useState, lazy, Suspense } from "react";
import { DashboardHeader } from "./components/dashboard-header";
import { DashboardSidebar } from "./components/dashboard-sidebar";

// Lazy load heavy components
const DashboardMain = lazy(() => import("./components/dashboard-main").then(m => ({ default: m.DashboardMain })));
const WorkflowsPage = lazy(() => import("./components/workflows-page").then(m => ({ default: m.WorkflowsPage })));
const RiskAssessmentPage = lazy(() => import("./components/risk-assessment-page").then(m => ({ default: m.RiskAssessmentPage })));
const ControlProcessManagementPage = lazy(() => import("./components/control-process-management-page").then(m => ({ default: m.ControlProcessManagementPage })));
const ReportsPage = lazy(() => import("./components/reports-page").then(m => ({ default: m.ReportsPage })));
const SettingsApiDocumentation = lazy(() => import("./components/settings-api-documentation").then(m => ({ default: m.SettingsApiDocumentation })));

export type UserRole = 'hrs-analyst' | 'hrs-manager' | 'flu-aml' | 'view-only';

export default function App() {
  const [currentPage, setCurrentPage] = useState("workflows");
  const [userRole, setUserRole] = useState<UserRole>('hrs-analyst');

  const renderPage = () => {
    switch (currentPage) {
      case "dashboard":
        return <DashboardMain userRole={userRole} onNavigateToWorkQueue={() => setCurrentPage("workflows")} />;
      case "cases":
        return <CaseCreationPage userRole={userRole} />;
      case "workflows":
        return <WorkflowsPage userRole={userRole} />;
      case "risk-assessment":
        return <RiskAssessmentPage userRole={userRole} />;
      case "control-management":
        return <ControlProcessManagementPage userRole={userRole} />;
      case "reports":
        return <ReportsPage userRole={userRole} />;
      case "settings":
        return <SettingsApiDocumentation />;
      default:
        return <DashboardMain userRole={userRole} onNavigateToWorkQueue={() => setCurrentPage("workflows")} />;
    }
  };

  return (
    <div className="min-h-screen bg-background font-[Roboto]">
      <DashboardHeader userRole={userRole} onRoleChange={setUserRole} />
      
      <div className="flex">
        <DashboardSidebar currentPage={currentPage} onPageChange={setCurrentPage} />
        
        <main className="flex-1 p-6 bg-muted/30">
          <div className="max-w-7xl mx-auto">
            <Suspense fallback={
              <div className="flex items-center justify-center h-96">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-900 mx-auto mb-4"></div>
                  <p className="text-muted-foreground">Loading...</p>
                </div>
              </div>
            }>
              {renderPage()}
            </Suspense>
          </div>
        </main>
      </div>
    </div>
  );
}