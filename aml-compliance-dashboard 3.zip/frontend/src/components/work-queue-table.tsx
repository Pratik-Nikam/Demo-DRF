import { useState, useMemo, useCallback, useEffect } from "react";
import { AgGridReact } from "ag-grid-react@32.2.2";
import type { ColDef, GridApi, GridReadyEvent } from "ag-grid-community@32.2.2";
import { getAGGridIconsConfig } from "./ag-grid-icons";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { BulkOperationsDialog } from "./bulk-operations-dialog";
import { toast } from "sonner@2.0.3";
import { 
  Search, 
  Filter, 
  Eye, 
  Edit, 
  RotateCcw,
  Download,
  AlertTriangle,
  CheckCircle,
  Clock,
  User,
  Building,
  Calendar,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  MoreVertical,
  Pin,
  PinOff,
  ScanLine,
  Settings,
  UserCheck,
  ArrowUpCircle,
  Activity,
  UserPlus,
  ArrowRight,
  Shield,
  PlayCircle,
  UsersRound
} from "lucide-react";

// AG-Grid styles are imported globally in globals.css

interface WorkQueueRecord {
  caseId: string;
  clientId: string;
  clientName: string;
  clientType: 'Individual' | 'Corporate' | 'Investment' | 'Banking';
  status: 'new' | 'unassigned' | 'assigned' | 'in-progress' | 'escalated' | 'returned' | 'auto-completed' | 'manual-review' | 'completed' | 'reopened' | 'abandoned' | 'rejected';
  priority: 'low' | 'medium' | 'high' | 'critical';
  assignedAnalyst: string;
  createdDate: string;
  dueDate: string;
  completedDate?: string;
  riskRating: 'Low' | 'Medium' | 'High';
  manualReviewReasons: string[];
  jurisdiction: string;
  lob: string;
  daysInQueue: number;
  escalationReason?: string;
  returnReason?: string;
}

interface WorkQueueTableProps {
  userRole: 'hrs-analyst' | 'hrs-manager' | 'flu-aml' | 'view-only';
  currentUser: any;
}

// Custom cell renderers
const StatusCellRenderer = (params: any) => {
  const status = params.value;
  const getStatusStyle = () => {
    switch (status) {
      case 'new':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'unassigned':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'assigned':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'in-progress':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'escalated':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'returned':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'auto-completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'manual-review':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'reopened':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'abandoned':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'rejected':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'new':
        return <Clock className="h-3 w-3" />;
      case 'unassigned':
        return <Clock className="h-3 w-3" />;
      case 'assigned':
        return <UserCheck className="h-3 w-3" />;
      case 'in-progress':
        return <Activity className="h-3 w-3" />;
      case 'escalated':
        return <ArrowUpCircle className="h-3 w-3" />;
      case 'returned':
        return <RotateCcw className="h-3 w-3" />;
      case 'auto-completed':
        return <CheckCircle className="h-3 w-3" />;
      case 'manual-review':
        return <AlertTriangle className="h-3 w-3" />;
      case 'completed':
        return <CheckCircle className="h-3 w-3" />;
      case 'reopened':
        return <RotateCcw className="h-3 w-3" />;
      case 'abandoned':
        return <Clock className="h-3 w-3" />;
      case 'rejected':
        return <AlertTriangle className="h-3 w-3" />;
      default:
        return <Clock className="h-3 w-3" />;
    }
  };

  return (
    <Badge variant="outline" className={`${getStatusStyle()} capitalize flex items-center space-x-1`}>
      {getStatusIcon()}
      <span>{status.replace('-', ' ')}</span>
    </Badge>
  );
};

const PriorityCellRenderer = (params: any) => {
  const priority = params.value;
  const getPriorityIcon = () => {
    switch (priority) {
      case 'critical':
        return <AlertTriangle className="h-3 w-3 text-red-600" />;
      case 'high':
        return <AlertTriangle className="h-3 w-3 text-orange-600" />;
      case 'medium':
        return <Clock className="h-3 w-3 text-yellow-600" />;
      case 'low':
        return <CheckCircle className="h-3 w-3 text-green-600" />;
      default:
        return null;
    }
  };

  const getPriorityStyle = () => {
    switch (priority) {
      case 'critical':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="flex items-center space-x-1">
      {getPriorityIcon()}
      <Badge variant="outline" className={`${getPriorityStyle()} capitalize`}>
        {priority}
      </Badge>
    </div>
  );
};

const ActionsCellRenderer: React.FC<any> = (props) => {
  const params = props;
  console.log("Work Queue ActionsCellRenderer rendered for case:", params.data?.caseId);
  
  const [assignmentDialogOpen, setAssignmentDialogOpen] = useState(false);
  const [assignmentType, setAssignmentType] = useState<'assign' | 'reassign' | 'escalate' | 'return'>('assign');
  const [targetUser, setTargetUser] = useState("");
  const [assignmentReason, setAssignmentReason] = useState("");
  
  // Enhanced escalation state
  const [disposition, setDisposition] = useState("");
  const [selectedEscalationReasons, setSelectedEscalationReasons] = useState<string[]>([]);
  const [escalationType, setEscalationType] = useState<'flu-aml' | 'gfc' | 'manager' | 'cancellation'>('flu-aml');
  const [escalationNotes, setEscalationNotes] = useState("");
  const [submittingAction, setSubmittingAction] = useState(false);
  
  // Get user role from params (passed from parent)
  const userRole = params.context?.userRole || 'hra-analyst';
  const currentUser = params.context?.currentUser ?? '';
  const triggerRefresh = params.context?.triggerRefresh;
  const record = params.data;
  
  // Escalation reasons from escalation routing
  const escalationReasons = [
    { id: 'gfc_intelligence', label: 'GFC Intelligence flagged', description: 'Global Financial Crimes intelligence indicates concern', requiresManager: true, targetRole: 'gfc' },
    { id: 'risk_drivers_high', label: 'Risk drivers >10', description: 'Total risk CRR drivers exceeds threshold', requiresManager: true, targetRole: 'flu-aml' },
    { id: 'new_risk_factors', label: 'New risk factors ≥5', description: 'Five or more new risk factors since last refresh', requiresManager: true, targetRole: 'flu-aml' },
    { id: 'trms_referral', label: 'TRMS referral required', description: 'Transaction Risk Management System referral needed', requiresManager: true, targetRole: 'flu-aml' },
    { id: 'client_escalation', label: 'Client Escalation Committee', description: 'Case requires client escalation committee review', requiresManager: true, targetRole: 'gfc' },
    { id: 'beneficial_ownership', label: 'Beneficial ownership changes', description: 'Significant changes in beneficial ownership structure', requiresManager: false, targetRole: 'flu-aml' },
    { id: 'address_change', label: 'Address changes', description: 'Significant address or location changes', requiresManager: false, targetRole: 'flu-aml' },
    { id: 'naics_change', label: 'Nature of Business changes', description: 'Changes in business nature or industry classification', requiresManager: false, targetRole: 'flu-aml' },
    { id: 'income_source', label: 'Source of Income changes', description: 'Changes in source of income for individual clients', requiresManager: false, targetRole: 'flu-aml' },
    { id: 'incomplete_info', label: 'Required information incomplete', description: 'Missing required data elements', requiresManager: false, targetRole: 'hra-manager' },
    { id: 'cancellation', label: 'Client cancellation required', description: 'Case requires client relationship cancellation', requiresManager: true, targetRole: 'hra-manager' }
  ];
  
  // Available managers for analyst escalations
  const availableManagers = [
    { id: 'manager1', name: 'David Kim', role: 'HRA Manager', lob: 'All LOBs' },
    { id: 'manager2', name: 'Lisa Chen', role: 'HRA Manager', lob: 'Investment Banking' },
    { id: 'manager3', name: 'Robert Taylor', role: 'HRA Manager', lob: 'Wealth Management' }
  ];
  
  // Available users based on role
  const getAvailableUsers = () => {
    // Normalize role strings: the app sometimes passes 'hrs-...' vs 'hra-...' variants.
    const raw = (userRole || '').toString();
    const role = raw.startsWith('hrs-') ? raw.replace('hrs-', 'hra-') : raw;

    if (role === 'hra-analyst') {
      return [
        { id: 'manager1', name: 'David Kim', role: 'HRA Manager', lob: 'All LOBs', activeCase: 5, capacity: 10 }
      ];
    } else if (role === 'hra-manager') {
      return [
        { id: 'analyst1', name: 'Sarah Johnson', role: 'HRA Analyst', lob: 'Investment Banking', activeCase: 12, capacity: 20 },
        { id: 'analyst2', name: 'Michael Chen', role: 'HRA Analyst', lob: 'Wealth Management', activeCase: 8, capacity: 20 },
        { id: 'analyst3', name: 'Emily Rodriguez', role: 'HRA Analyst', lob: 'Private Banking', activeCase: 15, capacity: 20 },
        { id: 'flu1', name: 'Lisa Wang', role: 'FLU AML', lob: 'All LOBs', activeCase: 8, capacity: 15 },
        { id: 'gfc1', name: 'Robert Martinez', role: 'GFC', lob: 'All LOBs', activeCase: 12, capacity: 20 }
      ];
    } else if (role === 'flu-aml') {
      return [
        { id: 'analyst1', name: 'Sarah Johnson', role: 'HRA Analyst', lob: 'Investment Banking', activeCase: 12, capacity: 20 },
        { id: 'manager1', name: 'David Kim', role: 'HRA Manager', lob: 'All LOBs', activeCase: 5, capacity: 10 }
      ];
    } else if (role === 'gfc') {
      return [
        { id: 'analyst1', name: 'Sarah Johnson', role: 'HRA Analyst', lob: 'Investment Banking', activeCase: 12, capacity: 20 },
        { id: 'manager1', name: 'David Kim', role: 'HRA Manager', lob: 'All LOBs', activeCase: 5, capacity: 10 },
        { id: 'flu1', name: 'Lisa Wang', role: 'FLU AML', lob: 'All LOBs', activeCase: 8, capacity: 15 }
      ];
    }
    // Fallback: return an empty list if role not matched
    return [];
  };

  // Helper functions for escalation
  const getRelevantEscalationReasons = () => {
    return escalationReasons.filter(reason => {
      if (escalationType === 'flu-aml') return reason.targetRole === 'flu-aml';
      if (escalationType === 'gfc') return reason.targetRole === 'gfc';
      if (escalationType === 'manager') return reason.targetRole === 'hra-manager';
      return true;
    });
  };

  const toggleEscalationReason = (reasonId: string) => {
    setSelectedEscalationReasons(prev => 
      prev.includes(reasonId) ? 
      prev.filter(id => id !== reasonId) : 
      [...prev, reasonId]
    );
  };

  const resetEscalationForm = () => {
    setAssignmentDialogOpen(false);
    setTargetUser("");
    setAssignmentReason("");
    setDisposition("");
    setSelectedEscalationReasons([]);
    setEscalationType('flu-aml');
    setEscalationNotes("");
  };

  const availableUsers = getAvailableUsers();
  
  const handleAssignment = async () => {
    // RETURN flow: call backend return endpoint
    if (assignmentType === 'return') {
      if (!assignmentReason.trim()) {
        toast.error("Please provide a reason for returning the case");
        return;
      }

      setSubmittingAction(true);
      try {
        const res = await fetch('/api/v1/workflows/return', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-User-Id': currentUser || ''
          },
          body: JSON.stringify({
            caseId: record.caseId,
            comments: assignmentReason
          }),
          credentials: 'same-origin'
        });

        if (!res.ok) {
          const txt = await res.text().catch(() => res.statusText);
          throw new Error(`Server responded ${res.status}: ${txt}`);
        }

        const wrapper = await res.json();
        const data = wrapper?.data ?? wrapper;
        const message = data?.message ?? 'Case returned';
        toast.success(message);

        // Refresh parent table
        triggerRefresh?.();
        resetEscalationForm();
      } catch (err: any) {
        console.error('Return failed', err);
        toast.error('Unable to return case: ' + (err?.message ?? 'Unknown error'));
      } finally {
        setSubmittingAction(false);
      }
      return;
    }

    // For escalate, assign/reassign flows (unchanged)...
    if (assignmentType === 'escalate') {
      // validation similar to MyWorkbasket
      if ((disposition === 'escalate_flu' || disposition === 'escalate_gfc') && selectedEscalationReasons.length === 0) {
        toast.error("Please select at least one escalation reason");
        return;
      }
      if ((disposition === 'escalate_flu' || disposition === 'escalate_gfc') && !targetUser && userRole === 'hra-analyst') {
        toast.error("Please select a manager to route the escalation through");
        return;
      }

      // Prefer selected user's display name when available; otherwise fall back to escalationType token.
      let explicitTargetName = "";
      if (targetUser && targetUser.trim().length > 0) {
        const manager = availableManagers.find(m => m.id === targetUser);
        const user = availableUsers.find(u => u.id === targetUser);
        explicitTargetName = manager?.name ?? user?.name ?? targetUser;
      }
      const escalateTo = explicitTargetName || escalationType || 'Manager';

      const payload = {
        caseId: record.caseId,
        escalateTo,
        disposition,
        escalationType,
        escalationReasons: selectedEscalationReasons,
        notes: escalationNotes
      };

      setSubmittingAction(true);
      try {
        const res = await fetch('/api/v1/workflows/escalate', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-User-Id': currentUser || ''
          },
          body: JSON.stringify(payload),
          credentials: 'same-origin'
        });

        if (!res.ok) {
          const txt = await res.text().catch(() => res.statusText);
          throw new Error(`Server responded ${res.status}: ${txt}`);
        }

        const wrapper = await res.json();
        const data = wrapper?.data ?? wrapper;
        const message = data?.message ?? 'Escalation submitted';
        toast.success(message);

        // trigger parent refresh if provided
        triggerRefresh?.();
        resetEscalationForm();
      } catch (err: any) {
        console.error('Escalation failed', err);
        toast.error('Unable to escalate case: ' + (err?.message ?? 'Unknown error'));
      } finally {
        setSubmittingAction(false);
      }

      return;
    }

    // assign / reassign local mock behavior
    if (!targetUser) {
      toast.error("Please select a user to assign the case to");
      return;
    }
    const user = availableUsers.find(u => u.id === targetUser);
    toast.success(`Case ${record.caseId} ${assignmentType} to ${user?.name}`);
    resetEscalationForm();
  };

  const openAssignmentDialog = (type: 'assign' | 'reassign' | 'escalate' | 'return') => {
    setAssignmentType(type);
    setAssignmentDialogOpen(true);
  };

  const getAvailableActions = () => {
    const actions = [];
    
    // Always show view details
    actions.push(
      <DropdownMenuItem key="view">
        <Eye className="h-4 w-4 mr-2" />
        View Details
      </DropdownMenuItem>
    );

    // Show assignment actions based on status and role
    if (record.status === 'unassigned' && (userRole === 'hrs-manager' || userRole === 'flu-aml')) {
      actions.unshift(
        <DropdownMenuItem key="assign" onClick={() => openAssignmentDialog('assign')}>
          <UserCheck className="h-4 w-4 mr-2" />
          Assign Case
        </DropdownMenuItem>
      );
    }

    if ((record.status === 'assigned' || record.status === 'in-progress') && (userRole === 'hrs-manager' || userRole === 'flu-aml')) {
      actions.unshift(
        <DropdownMenuItem key="reassign" onClick={() => openAssignmentDialog('reassign')}>
          <UserCheck className="h-4 w-4 mr-2" />
          Reassign Case
        </DropdownMenuItem>
      );
    }

    if (userRole === 'hrs-analyst' && (record.status === 'assigned' || record.status === 'in-progress')) {
      actions.unshift(
        <DropdownMenuItem key="escalate" onClick={() => openAssignmentDialog('escalate')}>
          <ArrowUpCircle className="h-4 w-4 mr-2" />
          Escalate Case
        </DropdownMenuItem>
      );
    }

    if ((userRole === 'flu-aml') && (record.status === 'assigned' || record.status === 'in-progress')) {
      actions.unshift(
        <DropdownMenuItem key="return" onClick={() => openAssignmentDialog('return')}>
          <RotateCcw className="h-4 w-4 mr-2" />
          Return to HRA
        </DropdownMenuItem>
      );
    }

    return actions;
  };

  // Get primary action based on role and case status
  const getPrimaryAction = () => {
    // View Only users cannot perform actions
    if (userRole === 'view-only') {
      return null;
    }
    
    if (record.status === 'unassigned' && (userRole === 'hrs-manager' || userRole === 'flu-aml')) {
      return (
        <Button 
          variant="outline" 
          size="sm" 
          className="h-7 px-2 text-xs"
          onClick={() => openAssignmentDialog('assign')}
        >
          <UserCheck className="h-3 w-3 mr-1" />
          Assign
        </Button>
      );
    }
    
    if ((record.status === 'assigned' || record.status === 'in-progress')) {
      if (userRole === 'hrs-analyst') {
        return (
          <Button 
            variant="outline" 
            size="sm" 
            className="h-7 px-2 text-xs"
            onClick={() => openAssignmentDialog('escalate')}
          >
            <ArrowUpCircle className="h-3 w-3 mr-1" />
            Escalate
          </Button>
        );
      } else if (userRole === 'hrs-manager') {
        return (
          <Button 
            variant="outline" 
            size="sm" 
            className="h-7 px-2 text-xs"
            onClick={() => openAssignmentDialog('reassign')}
          >
            <UserCheck className="h-3 w-3 mr-1" />
            Reassign
          </Button>
        );
      } else if (userRole === 'flu-aml') {
        return (
          <Button 
            variant="outline" 
            size="sm" 
            className="h-7 px-2 text-xs"
            onClick={() => openAssignmentDialog('return')}
          >
            <RotateCcw className="h-3 w-3 mr-1" />
            Return
          </Button>
        );
      }
    }
    
    return null;
  };

  return (
    <div className="flex items-center space-x-1">
      {/* Primary Assignment Action Button */}
      {getPrimaryAction()}

      {/* More Actions Dropdown */}
      <div className="relative z-10">
        <DropdownMenu 
          onOpenChange={(open) => {
            console.log("Work Queue Dropdown state changed:", open);
            if (open) {
              console.log("Dropdown opened for case:", record.caseId);
            }
          }}
        >
          <DropdownMenuTrigger asChild>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-7 w-7 p-0"
              onMouseDown={(e) => {
                console.log("Work Queue Button mouse down");
                e.stopPropagation();
              }}
              onPointerDown={(e) => {
                console.log("Work Queue Button pointer down");
              }}
            >
              <MoreVertical className="h-3 w-3" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent 
            align="end" 
            className="w-48"
            sideOffset={5}
          >
            {getAvailableActions().map((action, index) => (
              <div key={index}>
                {action}
                {index === getAvailableActions().length - 2 && <DropdownMenuSeparator />}
              </div>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <Dialog open={assignmentDialogOpen} onOpenChange={setAssignmentDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {assignmentType === 'assign' ? 'Assign Case' :
               assignmentType === 'reassign' ? 'Reassign Case' : 
               assignmentType === 'escalate' ? 'Case Disposition & Escalation' : 'Return Case'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Case Information */}
            <div className="p-4 bg-muted/50 rounded-lg">
              <h4 className="font-medium mb-2">Case Details</h4>
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Building className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="font-medium">{record.caseId}</p>
                  <p className="text-sm text-muted-foreground">{record.clientName}</p>
                  <p className="text-xs text-muted-foreground">
                    Status: {record.status} • Priority: {record.priority}
                  </p>
                </div>
              </div>
            </div>

            {/* Enhanced escalation flow for analysts and managers, and reassign flow for managers */}
            {((assignmentType === 'escalate' && (userRole === 'hra-analyst' || userRole === 'hra-manager')) || 
              (assignmentType === 'reassign' && userRole === 'hra-manager')) ? (
              <>
                {/* Disposition Selection */}
                <div>
                  <Label htmlFor="disposition">Case Disposition</Label>
                  <Select value={disposition} onValueChange={setDisposition}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select disposition" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="no_factors">No factors impacting decision to retain client</SelectItem>
                      <SelectItem value="escalate_flu">Escalate to FLU AML Representative</SelectItem>
                      <SelectItem value="escalate_gfc">Escalate to GFC Representative</SelectItem>
                      {userRole === 'hra-manager' && (
                        <SelectItem value="return_analyst">Return to HRA Analyst for corrections</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>

                {/* Escalation Type - only show when escalating */}
                {(disposition === 'escalate_flu' || disposition === 'escalate_gfc') && (
                  <div>
                    <Label htmlFor="escalation-type">Escalation Type</Label>
                    <Select value={escalationType} onValueChange={(value: any) => setEscalationType(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="flu-aml">FLU AML Representative</SelectItem>
                        <SelectItem value="gfc">GFC Representative</SelectItem>
                        <SelectItem value="manager">Manager Review</SelectItem>
                        <SelectItem value="cancellation">Client Cancellation</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Escalation Reasons - only show when escalating */}
                {(disposition === 'escalate_flu' || disposition === 'escalate_gfc') && (
                  <div>
                    <Label>Escalation Reasons</Label>
                    <div className="grid grid-cols-1 gap-2 mt-2 max-h-48 overflow-y-auto">
                      {getRelevantEscalationReasons().map((reason) => (
                        <div key={reason.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                          <input
                            type="checkbox"
                            id={reason.id}
                            checked={selectedEscalationReasons.includes(reason.id)}
                            onChange={() => toggleEscalationReason(reason.id)}
                            className="mt-1"
                          />
                          <div className="flex-1">
                            <Label htmlFor={reason.id} className="font-medium cursor-pointer text-sm">
                              {reason.label}
                            </Label>
                            <p className="text-xs text-muted-foreground mt-1">
                              {reason.description}
                            </p>
                            {reason.requiresManager && (
                              <Badge variant="outline" className="text-xs mt-1">
                                Requires Manager Approval
                              </Badge>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Manager Selection for analysts */}
                {userRole === 'hra-analyst' && (disposition === 'escalate_flu' || disposition === 'escalate_gfc') && (
                  <div>
                    <Label htmlFor="target-manager">Route to Manager</Label>
                    <Select value={targetUser} onValueChange={setTargetUser}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select HRA Manager" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableManagers.map((manager) => (
                          <SelectItem key={manager.id} value={manager.id}>
                            {manager.name} - {manager.lob}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground mt-1">
                      Case will be routed to manager for approval before {escalationType === 'flu-aml' ? 'FLU AML' : 'GFC'} escalation
                    </p>
                  </div>
                )}

                {/* Notes */}
                <div>
                  <Label htmlFor="escalation-notes">Notes</Label>
                  <Textarea
                    id="escalation-notes"
                    placeholder="Add any relevant notes for the escalation..."
                    value={escalationNotes}
                    onChange={(e) => setEscalationNotes(e.target.value)}
                    rows={3}
                  />
                </div>
              </>
            ) : assignmentType === 'return' ? (
              <div>
                <Label htmlFor="return-reason">Return Reason</Label>
                <Textarea
                  id="return-reason"
                  placeholder="Explain why the case is being returned..."
                  value={assignmentReason}
                  onChange={(e) => setAssignmentReason(e.target.value)}
                  rows={3}
                />
              </div>
            ) : (
              <div>
                <Label htmlFor="target-user">
                  {assignmentType === 'escalate' ? 'Escalate To' : 
                   assignmentType === 'assign' ? 'Assign To' : 'Reassign To'}
                </Label>
                <Select value={targetUser} onValueChange={setTargetUser}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select user" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableUsers.map((user) => (
                      <SelectItem key={user.id} value={user.id}>
                        {user.name} - {user.role} ({user.activeCase}/{user.capacity})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex justify-end space-x-2 pt-4 border-t">
              <Button variant="outline" onClick={resetEscalationForm} disabled={submittingAction}>
                Cancel
              </Button>
              <Button onClick={handleAssignment} disabled={submittingAction}>
                {submittingAction ? 'Submitting...' : (
                  (assignmentType === 'escalate' || assignmentType === 'reassign') && disposition === 'no_factors' ? (
                    <>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Complete Case
                    </>
                  ) : (assignmentType === 'escalate' || assignmentType === 'reassign') && disposition === 'escalate_flu' ? (
                    <>
                      <AlertTriangle className="h-4 w-4 mr-2" />
                      Escalate to FLU AML
                    </>
                  ) : (assignmentType === 'escalate' || assignmentType === 'reassign') && disposition === 'escalate_gfc' ? (
                    <>
                      <Shield className="h-4 w-4 mr-2" />
                      Escalate to GFC
                    </>
                  ) : (assignmentType === 'escalate' || assignmentType === 'reassign') && disposition === 'return_analyst' ? (
                    <>
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Return to HRA Analyst
                    </>
                  ) : assignmentType === 'return' ? (
                    <>
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Return Case
                    </>
                  ) : (
                    <>
                      <ArrowRight className="h-4 w-4 mr-2" />
                      {assignmentType === 'escalate' ? 'Escalate' : 
                       assignmentType === 'assign' ? 'Assign' : 'Reassign'}
                    </>
                  )
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Custom Header Component with Menu
const CustomHeaderComponent = (params: any) => {
  const [menuOpen, setMenuOpen] = useState(false);
  
  const onSortAscending = () => {
    params.setSort('asc');
    setMenuOpen(false);
  };

  const onSortDescending = () => {
    params.setSort('desc');
    setMenuOpen(false);
  };

  const onPinColumn = () => {
    const pinned = params.column.getPinned();
    if (pinned) {
      params.api.setColumnsPinned([params.column], null);
    } else {
      params.api.setColumnsPinned([params.column], 'left');
    }
    setMenuOpen(false);
  };

  const onAutoSizeColumn = () => {
    params.api.autoSizeColumns([params.column]);
    setMenuOpen(false);
  };

  const onAutoSizeAllColumns = () => {
    params.api.autoSizeAllColumns();
    setMenuOpen(false);
  };

  const onHideColumn = () => {
    params.api.setColumnsVisible([params.column], false);
    setMenuOpen(false);
  };

  return (
    <div className="flex items-center justify-between w-full">
      <div className="flex items-center space-x-1">
        <span>{params.displayName}</span>
        {params.column.isSortAscending() && <ArrowUp className="h-3 w-3" />}
        {params.column.isSortDescending() && <ArrowDown className="h-3 w-3" />}
        {params.column.getPinned() && <Pin className="h-3 w-3 text-muted-foreground" />}
      </div>
      
      <DropdownMenu open={menuOpen} onOpenChange={setMenuOpen}>
        <DropdownMenuTrigger asChild>
          <button 
            className="h-6 w-6 p-0 ml-1 hover:bg-muted rounded flex items-center justify-center bg-transparent border-0 cursor-pointer"
            onClick={(e) => {
              e.stopPropagation();
              setMenuOpen(!menuOpen);
            }}
          >
            <MoreVertical className="h-3 w-3" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-56">
          {params.column.getColDef().sortable !== false && (
            <>
              <DropdownMenuItem onClick={onSortAscending}>
                <ArrowUp className="h-4 w-4 mr-2" />
                Sort Ascending
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onSortDescending}>
                <ArrowDown className="h-4 w-4 mr-2" />
                Sort Descending
              </DropdownMenuItem>
              <DropdownMenuSeparator />
            </>
          )}
          <DropdownMenuItem onClick={onPinColumn}>
            <Pin className="h-4 w-4 mr-2" />
            {params.column.getPinned() ? 'Unpin Column' : 'Pin Column'}
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={onAutoSizeColumn}>
            <ScanLine className="h-4 w-4 mr-2" />
            Autosize This Column
          </DropdownMenuItem>
          <DropdownMenuItem onClick={onAutoSizeAllColumns}>
            <ScanLine className="h-4 w-4 mr-2" />
            Autosize All Columns
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={onHideColumn}>
            <Eye className="h-4 w-4 mr-2" />
            Hide Column
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};

export function WorkQueueTable({ userRole, currentUser }: WorkQueueTableProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all-statuses");
  const [priorityFilter, setPriorityFilter] = useState("all-priorities");
  const [lobFilter, setLobFilter] = useState("all-lobs");
  const [gridApi, setGridApi] = useState<GridApi>();
  const [bulkOperationsOpen, setBulkOperationsOpen] = useState(false);
  const [selectedRows, setSelectedRows] = useState<string[]>([]);
  const [rowData, setRowData] = useState<WorkQueueRecord[]>([]);
  const [loading, setLoading] = useState(false);

  // refresh helper used by child renderers to reload queue after actions
  const [refreshKey, setRefreshKey] = useState(0);
  const triggerRefresh = () => setRefreshKey(k => k + 1);

  // Fetch work-queue from backend when lobFilter or refreshKey changes (or on mount)
  useEffect(() => {
    const controller = new AbortController();
    const fetchQueue = async () => {
      setLoading(true);
      try {
        const params = new URLSearchParams();
        const lobParam = lobFilter === "all-lobs" ? "" : lobFilter;
        if (lobParam) params.append("lob", lobParam);
        params.append("limit", "200");
        params.append("offset", "0");

        const res = await fetch(`/api/v1/workflows/work-queue?${params.toString()}`, {
          method: "GET",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal
        });

        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const payload = await res.json();
        // ApiResponse wrapper expected: { data: { items: [...] } } or fallback to direct shape
        const items = payload?.data?.items ?? payload?.items ?? [];

        const mapped: WorkQueueRecord[] = items.map((it: any) => {
          const createdIso = it.createdDate ?? it.createdAt ?? it.created_at;
          const dueIso = it.dueDate ?? it.due_date ?? it.dueDate;
          const completedIso = it.completedDate ?? it.completed_date ?? it.completedDate;

          const createdDt = createdIso ? new Date(createdIso) : null;
          const days = it.daysInQueue != null
            ? it.daysInQueue
            : createdDt
              ? Math.max(0, Math.floor((Date.now() - createdDt.getTime()) / (24 * 3600 * 1000)))
              : 0;

          // Normalize manualReviewReasons: accept array or JSON string, fallback empty array
          let manualReasons: string[] = [];
          try {
            if (Array.isArray(it.manualReviewReasons)) {
              manualReasons = it.manualReviewReasons;
            } else if (it.manualReviewReasons) {
              manualReasons = typeof it.manualReviewReasons === "string"
                ? JSON.parse(it.manualReviewReasons)
                : Array.isArray(it.manualReviewReasons) ? it.manualReviewReasons : [];
            }
          } catch (e) {
            // fallback: split comma-separated string
            manualReasons = String(it.manualReviewReasons || "").split(",").map((s: string) => s.trim()).filter(Boolean);
          }

          return {
            caseId: it.caseId ?? it.id ?? "",
            clientId: it.clientId ?? it.client_id ?? "",
            clientName: it.clientName ?? it.client_name ?? "",
            clientType: (it.clientType ?? it.client_type ?? "Corporate") as any,
            status: (it.status ?? "unassigned") as any,
            priority: (it.priority ?? "medium") as any,
            assignedAnalyst: it.assignedAnalyst ?? it.assigned_to ?? it.assignedTo ?? "Unassigned",
            createdDate: createdIso ? String(createdIso).split("T")[0] : "",
            dueDate: dueIso ? (typeof dueIso === "string" ? dueIso.split("T")[0] : String(dueIso)) : "",
            completedDate: completedIso ? (typeof completedIso === "string" ? completedIso.split("T")[0] : String(completedIso)) : undefined,
            riskRating: (it.riskRating ?? it.risk_rating ?? "Medium") as any,
            manualReviewReasons: manualReasons,
            jurisdiction: it.jurisdiction ?? "Unknown",
            lob: it.lob ?? "Investment Banking",
            daysInQueue: days,
            escalationReason: it.escalationReason ?? it.escalation_reason,
            returnReason: it.returnReason ?? it.return_reason
          };
        });

        setRowData(mapped);
      } catch (err) {
        if ((err as any).name !== "AbortError") {
          console.error("Failed to load work queue", err);
          toast.error("Unable to load work queue from server");
        }
      } finally {
        setLoading(false);
      }
    };

    fetchQueue();
    return () => controller.abort();
  }, [lobFilter, refreshKey]);

  // Column definitions for AG-Grid
  const columnDefs: ColDef[] = useMemo(() => [
    {
      field: 'caseId',
      headerName: 'Case ID',
      width: 150,
      pinned: false,
      sortable: true,
      filter: true,
      headerComponent: CustomHeaderComponent,
      cellClass: 'font-mono text-blue-600'
    },
    {
      field: 'clientName',
      headerName: 'Client',
      width: 200,
      sortable: true,
      filter: true,
      headerComponent: CustomHeaderComponent,
      cellRenderer: (params: any) => (
        <div className="flex items-center space-x-2">
          {params.data.clientType === 'Individual' ? 
            <User className="h-4 w-4 text-muted-foreground" /> : 
            <Building className="h-4 w-4 text-muted-foreground" />
          }
          <div>
            <p className="font-medium">{params.value}</p>
            <p className="text-xs text-muted-foreground">{params.data.clientType}</p>
          </div>
        </div>
      )
    },
    {
      field: 'status',
      headerName: 'Status',
      width: 150,
      sortable: false,
      filter: true,
      headerComponent: CustomHeaderComponent,
      cellRenderer: StatusCellRenderer
    },
    {
      field: 'priority',
      headerName: 'Priority',
      width: 130,
      sortable: false,
      filter: true,
      headerComponent: CustomHeaderComponent,
      cellRenderer: PriorityCellRenderer
    },
    {
      field: 'assignedAnalyst',
      headerName: 'Assigned To',
      width: 150,
      sortable: true,
      filter: true,
      headerComponent: CustomHeaderComponent,
      cellRenderer: (params: any) => (
        <div className="flex items-center space-x-2">
          <User className="h-4 w-4 text-muted-foreground" />
          <span>{params.value === 'Unassigned' ? 'Unassigned' : params.value}</span>
        </div>
      )
    },
    {
      field: 'lob',
      headerName: 'LOB',
      width: 150,
      sortable: true,
      filter: true,
      headerComponent: CustomHeaderComponent
    },
    {
      field: 'daysInQueue',
      headerName: 'Days in Queue',
      width: 130,
      sortable: true,
      filter: true,
      headerComponent: CustomHeaderComponent,
      cellRenderer: (params: any) => (
        <span className={`font-medium ${
          params.value > 5 ? 'text-red-600' : 
          params.value > 2 ? 'text-orange-600' : 
          'text-green-600'
        }`}>
          {params.value} days
        </span>
      )
    },
    {
      field: 'dueDate',
      headerName: 'Due Date',
      width: 120,
      sortable: true,
      filter: 'agDateColumnFilter',
      headerComponent: CustomHeaderComponent,
      cellRenderer: (params: any) => (
        <div className="flex items-center space-x-1">
          <Calendar className="h-3 w-3 text-muted-foreground" />
          <span>{params.value}</span>
        </div>
      )
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 160,
      sortable: false,
      filter: false,
      headerComponent: CustomHeaderComponent,
      cellRenderer: ActionsCellRenderer,
      pinned: 'right',
      cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'center' }
    }
  ], []);

  // Filter the data based on search and filters
  const filteredCases = useMemo(() => {
    return rowData.filter(caseRecord => {
      const matchesSearch = searchTerm === "" || 
        caseRecord.caseId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseRecord.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseRecord.assignedAnalyst.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === "all-statuses" || caseRecord.status === statusFilter;
      const matchesPriority = priorityFilter === "all-priorities" || caseRecord.priority === priorityFilter;
      const matchesLob = lobFilter === "all-lobs" || caseRecord.lob === lobFilter;
      
      return matchesSearch && matchesStatus && matchesPriority && matchesLob;
    });
  }, [rowData, searchTerm, statusFilter, priorityFilter, lobFilter]);

  const onGridReady = useCallback((params: GridReadyEvent) => {
    setGridApi(params.api);
  }, []);

  const onSelectionChanged = () => {
    if (gridApi) {
      const selectedRows = gridApi.getSelectedRows();
      setSelectedRows(selectedRows.map(row => row.caseId));
    }
  };

  const onExport = () => {
    if (gridApi) {
      gridApi.exportDataAsCsv({
        fileName: 'work-queue-export.csv'
      });
    }
  };

  const resetColumns = () => {
    if (gridApi) {
      gridApi.resetColumnState();
    }
  };

  // Default column configuration
  const defaultColDef = useMemo(() => ({
    sortable: true,
    filter: true,
    resizable: true,
    minWidth: 100,
    flex: 1
  }), []);

  // UI rendering
  try {
    return (
      <div className="space-y-6">
        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search cases..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-statuses">All Statuses</SelectItem>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="unassigned">Unassigned</SelectItem>
                  <SelectItem value="assigned">Assigned</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="escalated">Escalated</SelectItem>
                  <SelectItem value="returned">Returned</SelectItem>
                  <SelectItem value="auto-completed">Auto Completed</SelectItem>
                  <SelectItem value="manual-review">Manual Review</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="abandoned">Abandoned</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>

              <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-priorities">All Priorities</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>

              <Select value={lobFilter} onValueChange={setLobFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by LOB" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-lobs">All LOBs</SelectItem>
                  <SelectItem value="Investment Banking">Investment Banking</SelectItem>
                  <SelectItem value="Wealth Management">Wealth Management</SelectItem>
                  <SelectItem value="Private Banking">Private Banking</SelectItem>
                  <SelectItem value="Commercial Banking">Commercial Banking</SelectItem>
                </SelectContent>
              </Select>

              <Button 
                onClick={() => setBulkOperationsOpen(true)} 
                variant="outline" 
                size="sm"
                disabled={selectedRows.length === 0 || userRole === 'view-only'}
              >
                <UsersRound className="h-4 w-4 mr-2" />
                Bulk Operations
                {selectedRows.length > 0 && (
                  <Badge variant="secondary" className="ml-2 px-1 py-0 text-xs">
                    {selectedRows.length}
                  </Badge>
                )}
              </Button>
              <Button onClick={onExport} variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* AG-Grid Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Work Queue ({filteredCases.length} cases){loading ? " — loading..." : ""}</span>
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm" onClick={resetColumns}>
                  <Settings className="h-4 w-4 mr-2" />
                  Reset Columns
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="ag-theme-alpine" style={{ height: '600px', width: '100%' }}>
              {typeof window !== 'undefined' && (
                <AgGridReact
                  rowData={filteredCases}
                  columnDefs={columnDefs}
                  defaultColDef={defaultColDef}
                  onGridReady={onGridReady}
                  onSelectionChanged={onSelectionChanged}
                  animateRows={true}
                  sortingOrder={['desc', 'asc']}
                  suppressMenuHide={true}
                  enableCellTextSelection={true}
                  ensureDomOrder={true}
                  pagination={true}
                  paginationPageSize={20}
                  rowSelection={{
                    mode: 'multiRow',
                    enableClickSelection: false,
                    copySelectedRows: true,
                    checkboxes: true,
                    headerCheckbox: true
                  }}
                  suppressCellEvents={false}
                  enableBrowserTooltips={true}
                  context={{ userRole, currentUser, triggerRefresh }}
                  icons={getAGGridIconsConfig().iconMap}
                />
              )}
            </div>
          </CardContent>
        </Card>

        {/* Bulk Operations Dialog */}
        <BulkOperationsDialog
          open={bulkOperationsOpen}
          onOpenChange={setBulkOperationsOpen}
          userRole={userRole}
          currentUser={currentUser}
          tableType="workqueue"
          selectedCases={selectedRows}
        />
      </div>
    );
  } catch (error) {
    console.error('Error rendering Work Queue table:', error);
    return (
      <div className="space-y-6">
        <Card>
          <CardContent className="p-8 text-center">
            <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">Unable to Load Work Queue</h3>
            <p className="text-muted-foreground mb-4">
              There was an error loading the work queue table. Please refresh the page or contact support.
            </p>
            <Button onClick={() => window.location.reload()} variant="outline">
              Refresh Page
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
}