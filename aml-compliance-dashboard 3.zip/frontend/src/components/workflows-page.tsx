import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";

    
import { WorkbasketManagement } from "./workbasket-management";
import { WorkbasketFilter } from "./workbasket-data";
import { 
  Users, 
  ArrowUpCircle,
  RotateCcw,
  AlertTriangle,
  Clock,
  CheckCircle
} from "lucide-react";

interface WorkflowsPageProps {
  userRole: 'hrs-analyst' | 'hrs-manager' | 'flu-aml' | 'view-only';
}

interface WidgetNumbers {
  active: number;
  escalations: number;
  completed: number;
  returned: number;
}

export function WorkflowsPage({ userRole }: WorkflowsPageProps) {
  const [activeTab, setActiveTab] = useState("workbasket");
  const [widgetFilter, setWidgetFilter] = useState<WorkbasketFilter>('all');

  // Mock current user data
  const currentUser = {
    name: "Sarah Johnson",
    role: userRole,
    roleDisplay: {
      'hrs-analyst': 'HRS Analyst',
      'hrs-manager': 'HRS Manager', 
      'flu-aml': 'FLU AML Representative',
      'view-only': 'View Only'
    }[userRole],
    lob: "Investment Banking"
  };

  const handleWidgetClick = (filterType: WorkbasketFilter) => {
    setWidgetFilter(filterType);
  };

  // Fetch widget numbers by re-using the existing workbasket endpoint per-filter.
  const [widgetNumbers, setWidgetNumbers] = useState<WidgetNumbers>({
    active: 0,
    escalations: 0,
    completed: 0,
    returned: 0
  });
  const [countsLoading, setCountsLoading] = useState(false);

  useEffect(() => {
    let mounted = true;
    const controller = new AbortController();

    const fetchCounts = async () => {
      setCountsLoading(true);
      try {
        const filters: { key: keyof WidgetNumbers; filter: string }[] = [
          { key: 'active', filter: 'active' },
          { key: 'escalations', filter: 'escalations' },
          { key: 'completed', filter: 'completed' },
          { key: 'returned', filter: 'returned' }
        ];

        const calls = filters.map(f =>
          fetch(`/api/v1/workflows/workbasket/my-cases?filter=${encodeURIComponent(f.filter)}&limit=1&offset=0`, {
            method: 'GET',
            headers: {
              'Accept': 'application/json',
              'X-User-Id': currentUser.name || ''
            },
            credentials: 'same-origin',
            signal: controller.signal
          })
        );

        const responses = await Promise.all(calls);

        for (const r of responses) {
          if (!r.ok) {
            const txt = await r.text().catch(() => r.statusText);
            throw new Error(`Server responded ${r.status}: ${txt}`);
          }
        }

        const bodies = await Promise.all(responses.map(r => r.json()));

        const counts: WidgetNumbers = { active: 0, escalations: 0, completed: 0, returned: 0 };
        bodies.forEach((body, idx) => {
          const payload = body?.data ?? body ?? {};
          const total = Number(payload?.total ?? payload?.items?.length ?? 0);
          const key = filters[idx].key;
          counts[key] = isNaN(total) ? 0 : total;
        });

        if (mounted) setWidgetNumbers(counts);
      } catch (err: any) {
        if (err.name !== "AbortError") {
          console.error("Failed to load widget counts via workbasket endpoints", err);
        }
        if (mounted) {
          setWidgetNumbers({ active: 0, escalations: 0, completed: 0, returned: 0 });
        }
      } finally {
        if (mounted) setCountsLoading(false);
      }
    };

    fetchCounts();
    return () => {
      mounted = false;
      controller.abort();
    };
  }, [currentUser.name]);

  return (
    <div className="space-y-6">
      {/* Workflow Action Widgets */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card 
          className={`cursor-pointer hover:shadow-md transition-shadow ${
            widgetFilter === 'active' ? 'ring-2 ring-primary bg-primary/5' : ''
          }`}
          onClick={() => handleWidgetClick('active')}
        >
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Clock className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">My Active Cases</p>
                <p className="font-medium text-xl">{countsLoading ? "�" : widgetNumbers.active}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card 
          className={`cursor-pointer hover:shadow-md transition-shadow ${
            widgetFilter === 'escalations' ? 'ring-2 ring-primary bg-primary/5' : ''
          }`}
          onClick={() => handleWidgetClick('escalations')}
        >
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <ArrowUpCircle className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Pending Escalations</p>
                <p className="font-medium text-xl">{countsLoading ? "�" : widgetNumbers.escalations}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card 
          className={`cursor-pointer hover:shadow-md transition-shadow ${
            widgetFilter === 'completed' ? 'ring-2 ring-primary bg-primary/5' : ''
          }`}
          onClick={() => handleWidgetClick('completed')}
        >
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <CheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Completed Today</p>
                <p className="font-medium text-xl">{countsLoading ? "�" : widgetNumbers.completed}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card 
          className={`cursor-pointer hover:shadow-md transition-shadow ${
            widgetFilter === 'returned' ? 'ring-2 ring-primary bg-primary/5' : ''
          }`}
          onClick={() => handleWidgetClick('returned')}
        >
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <RotateCcw className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Returned Cases</p>
                <p className="font-medium text-xl">{countsLoading ? "�" : widgetNumbers.returned}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Filter Indicator */}
      {widgetFilter !== 'all' && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-900">
                  Filtering by: {
                    widgetFilter === 'active' ? 'Active Cases (assigned & in-progress)' :
                    widgetFilter === 'escalations' ? 'Cases requiring escalation' :
                    widgetFilter === 'completed' ? 'Cases completed today' :
                    'Returned Cases'
                  }
                </span>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => handleWidgetClick('all')}
                className="text-blue-700 border-blue-300 hover:bg-blue-100"
              >
                Clear Filter
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Workbasket Management - now the main content */}
      {/* Pass the analyst id/name string (backend expects X-User-Id header) */}
      <WorkbasketManagement 
        userRole={userRole} 
        currentUser={currentUser.name} 
        widgetFilter={widgetFilter}
      />
    </div>
  );
}