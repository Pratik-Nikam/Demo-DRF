import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { OperationalReportingDashboard } from "./operational-reporting-dashboard";
import { SpiPerformanceReporting } from "./spi-performance-reporting";
import { HraReportsTable } from "./hra-reports-table";
import { 
  BarChart3,
  Download,
  FileText,
  Calendar as CalendarIcon,
  Filter,
  Search,
  TrendingUp,
  Users,
  Clock,
  AlertTriangle,
  Shield,
  Building
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner@2.0.3";

interface ReportsPageProps {
  userRole: 'hra-analyst' | 'hra-manager' | 'flu-aml' | 'gfc';
}

export function ReportsPage({ userRole }: ReportsPageProps) {
  const [activeTab, setActiveTab] = useState("operational");
  const [selectedLob, setSelectedLob] = useState("all-lobs");
  const [dateRange, setDateRange] = useState({
    from: new Date(2024, 5, 1), // June 1, 2024
    to: new Date()
  });
  const [searchTerm, setSearchTerm] = useState("");

  // Mock current user data with LOB entitlements
  const currentUser = {
    name: "Sarah Johnson",
    role: userRole,
    lob: "Investment Banking",
    entitlements: userRole === 'flu-aml' ? ["Investment Banking"] : ["Investment Banking", "Wealth Management", "Commercial Banking", "Global Markets"]
  };

  // Available LOBs based on user entitlements
  const availableLobs = [
    "Investment Banking",
    "Wealth Management", 
    "Commercial Banking",
    "Global Markets",
    "Private Banking"
  ].filter(lob => 
    userRole !== 'flu-aml' || currentUser.entitlements.includes(lob)
  );

  const handleExportToExcel = (reportType: string) => {
    toast.success(`Exporting ${reportType} report to Excel...`);
    // In real implementation, this would trigger the actual Excel export
  };

  const getAccessibleLobs = () => {
    if (userRole === 'flu-aml') {
      return currentUser.entitlements;
    }
    return availableLobs;
  };

  // Mock summary statistics based on filters
  const getSummaryStats = () => {
    const accessibleLobs = getAccessibleLobs();
    const lobFilter = selectedLob === "all-lobs" ? accessibleLobs : [selectedLob];
    
    // Mock data that would be filtered by LOB and date range
    return {
      totalCases: lobFilter.length * 45,
      completedCases: lobFilter.length * 32,
      pendingCases: lobFilter.length * 13,
      avgProcessingTime: "4.2 days",
      escalationRate: "18.5%",
      autoCloseRate: "62.3%"
    };
  };

  const stats = getSummaryStats();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-medium text-primary">HRS Reports & Analytics</h2>
          <p className="text-muted-foreground">
            Comprehensive reporting for High Risk Summary operations performance and case management
          </p>
        </div>
      </div>

      {/* Access Control Notice for FLU AML */}
      {userRole === 'flu-aml' && (
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <Building className="h-5 w-5 text-blue-600 mt-0.5" />
              <div>
                <p className="font-medium text-blue-800">FLU AML Access Control</p>
                <p className="text-sm text-blue-700 mt-1">
                  Your access is limited to <strong>{currentUser.lob}</strong> data only. 
                  You can view operational reports and case data for your assigned Line of Business.
                </p>
                <p className="text-xs text-blue-600 mt-2">
                  Entitled LOBs: {currentUser.entitlements.join(", ")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Global Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label htmlFor="lob-filter">Line of Business</Label>
              <Select value={selectedLob} onValueChange={setSelectedLob}>
                <SelectTrigger>
                  <SelectValue placeholder="Select LOB" />
                </SelectTrigger>
                <SelectContent>
                  {userRole !== 'flu-aml' && <SelectItem value="all-lobs">All LOBs</SelectItem>}
                  {getAccessibleLobs().map(lob => (
                    <SelectItem key={lob} value={lob}>{lob}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Date Range</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dateRange.from ? (
                      dateRange.to ? (
                        <>
                          {format(dateRange.from, "LLL dd, y")} -{" "}
                          {format(dateRange.to, "LLL dd, y")}
                        </>
                      ) : (
                        format(dateRange.from, "LLL dd, y")
                      )
                    ) : (
                      <span>Pick a date range</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    initialFocus
                    mode="range"
                    defaultMonth={dateRange.from}
                    selected={{ from: dateRange.from!, to: dateRange.to! }}
                    onSelect={(range) => {
                      if (range?.from && range?.to) {
                        setDateRange({ from: range.from, to: range.to });
                      }
                    }}
                    numberOfMonths={2}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label htmlFor="search">Search Cases</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="Client name, case ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Export Options</Label>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={() => handleExportToExcel('Operational')}>
                  <Download className="h-4 w-4 mr-2" />
                  Excel
                </Button>
                <Button variant="outline" size="sm">
                  <FileText className="h-4 w-4 mr-2" />
                  PDF
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <FileText className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Cases</p>
                <p className="font-medium">{stats.totalCases}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <TrendingUp className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Completed</p>
                <p className="font-medium">{stats.completedCases}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Clock className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Pending</p>
                <p className="font-medium">{stats.pendingCases}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <BarChart3 className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Avg Time</p>
                <p className="font-medium">{stats.avgProcessingTime}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <AlertTriangle className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Escalation Rate</p>
                <p className="font-medium">{stats.escalationRate}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gray-100 rounded-lg">
                <Shield className="h-5 w-5 text-gray-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Auto-Close Rate</p>
                <p className="font-medium">{stats.autoCloseRate}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Report Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="operational" className="flex items-center space-x-2">
            <BarChart3 className="h-4 w-4" />
            <span>Operational Reporting</span>
          </TabsTrigger>
          <TabsTrigger value="spi-performance" className="flex items-center space-x-2">
            <TrendingUp className="h-4 w-4" />
            <span>SPI/Process Performance</span>
          </TabsTrigger>
          <TabsTrigger value="case-details" className="flex items-center space-x-2">
            <FileText className="h-4 w-4" />
            <span>Case Details</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="operational" className="space-y-6">
          <OperationalReportingDashboard 
            userRole={userRole}
            selectedLob={selectedLob}
            dateRange={dateRange}
            availableLobs={getAccessibleLobs()}
            onExport={handleExportToExcel}
          />
        </TabsContent>

        <TabsContent value="spi-performance" className="space-y-6">
          <SpiPerformanceReporting 
            userRole={userRole}
            selectedLob={selectedLob}
            dateRange={dateRange}
            availableLobs={getAccessibleLobs()}
            onExport={handleExportToExcel}
          />
        </TabsContent>

        <TabsContent value="case-details" className="space-y-6">
          <HraReportsTable 
            userRole={userRole}
            selectedLob={selectedLob}
            dateRange={dateRange}
            searchTerm={searchTerm}
            availableLobs={getAccessibleLobs()}
            onExport={handleExportToExcel}
          />
        </TabsContent>
      </Tabs>

      {/* Database Integration Notice */}
      <Card className="border-green-200 bg-green-50">
        <CardContent className="p-4">
          <div className="flex items-start space-x-3">
            <Shield className="h-5 w-5 text-green-600 mt-0.5" />
            <div>
              <p className="font-medium text-green-800">Data Integration & Reporting Database</p>
              <p className="text-sm text-green-700 mt-1">
                All HRA attributes captured in the user interface are automatically submitted to the reporting database as information is saved. 
                This enables real-time operational reporting and downstream data feeds for SPI/process performance analytics.
              </p>
              <div className="mt-3 text-xs text-green-600">
                <p><strong>On-Tool Reporting:</strong> Available to all users with LOB-based entitlements</p>
                <p><strong>Off-Tool Reporting:</strong> Data feeds downstream for comprehensive analysis</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}