import { RiskOverviewCards } from "./risk-overview-cards";
import { WorkflowDashboard } from "./workflow-dashboard";
import { TeamCapacityWidget } from "./team-capacity-widget";

interface DashboardMainProps {
  userRole: 'hrs-analyst' | 'hrs-manager' | 'flu-aml' | 'view-only';
  onNavigateToWorkQueue?: () => void;
}

export function DashboardMain({ userRole, onNavigateToWorkQueue }: DashboardMainProps) {
  const currentUser = {
    name: "Sarah Johnson",
    role: userRole,
    roleDisplay: {
      'hrs-analyst': 'HRS Analyst',
      'hrs-manager': 'HRS Manager', 
      'flu-aml': 'FLU AML Representative',
      'view-only': 'View Only'
    }[userRole],
    lob: "Investment Banking"
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-medium text-primary">AML High Risk Summary Dashboard</h2>
        <p className="text-muted-foreground">Monitor risk analytics and workflow activities across all HRS processes</p>
      </div>
      
      {/* Keep the original risk overview cards */}
      <RiskOverviewCards />
      
      {/* Add workflow dashboard widgets */}
      <WorkflowDashboard userRole={userRole} currentUser={currentUser} onNavigate={onNavigateToWorkQueue} />
      
      {/* Team Capacity Overview - Manager and above only */}
      <TeamCapacityWidget userRole={userRole} />
    </div>
  );
}