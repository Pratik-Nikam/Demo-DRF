
  # AML Compliance Dashboard

  This is a code bundle for AML Compliance Dashboard. The original project is available at https://www.figma.com/design/vsnePMLSL7vrPN8DtuyARl/AML-Compliance-Dashboard.
  
  # Prequeisites for local development

  - Node.js
	- latest release
  - Java 
	- Java JDK 17
	  - AdoptOpenJDK recommended
  - Docker
	- Docker Desktop (Mac/Windows) or
	- Rancher Desktop with WSL2 backend (Windows)

  # Local Development Setup Instructions Without Docker
  1. Clone the repository to your local machine.
  2. Ensure you have the prerequisites installed.
  3. Open a terminal and navigate to the backend project directory.
  4. Run `mvn spring-boot:run` to start the backend server. The backend server will start on `http://localhost:8080`.
  5. Open another terminal and navigate to the frontend project directory.
  6. Run `npm install` to install the frontend dependencies.
  7. Run `npm run dev` to start the frontend development server. The frontend server will start on `http://localhost:3000`.
  8. Access the application at `http://localhost:3000` in your web browser.'
  9. To stop the servers, press `Ctrl + C` in both terminal windows.

  # Local Development Setup Instructions With Docker
  1. Clone the repository to your local machine.
  2. Ensure you have the prerequisites installed.
  3. Open a terminal and navigate to the project directory.
  4. Run 'docker-compose up --build' to build and start the services.
  5. Access the application at 'http://localhost:3000' in your web browser.
  6. To stop the services, run 'docker-compose down' in the terminal.


  ## Technologies Used
  - Frontend: React, TypeScript, Tailwind CSS
  - Backend: Java Spring Boot
  